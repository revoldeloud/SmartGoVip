import { useState, useEffect } from 'react';
import { Header } from '@/components/layout/Header';
import { PageLayout } from '@/components/layout/PageLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useOrders } from '@/hooks/useOrders';
import { useClients } from '@/hooks/useClients';
import { formatCurrency, formatDate } from '@/utils/formatters';
import { printOrder, printReceipt, printInvoice } from '@/utils/print';
import { toast } from 'sonner';

type ReportType = 'orders' | 'budgets' | 'clients' | 'financial' | '';
type Period = 'today' | 'week' | 'month' | 'quarter' | 'year' | 'custom' | '';

const Reports = () => {
  const { orders } = useOrders();
  const { clients } = useClients();
  const [reportType, setReportType] = useState<ReportType>('');
  const [period, setPeriod] = useState<Period>('month');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [generatedReport, setGeneratedReport] = useState<any>(null);

  const filterByPeriod = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    
    switch (period) {
      case 'today':
        return date.toDateString() === now.toDateString();
      case 'week':
        const weekAgo = new Date(now);
        weekAgo.setDate(now.getDate() - 7);
        return date >= weekAgo;
      case 'month':
        const monthAgo = new Date(now);
        monthAgo.setMonth(now.getMonth() - 1);
        return date >= monthAgo;
      case 'quarter':
        const quarterAgo = new Date(now);
        quarterAgo.setMonth(now.getMonth() - 3);
        return date >= quarterAgo;
      case 'year':
        const yearAgo = new Date(now);
        yearAgo.setFullYear(now.getFullYear() - 1);
        return date >= yearAgo;
      case 'custom':
        if (!startDate || !endDate) return true;
        return date >= new Date(startDate) && date <= new Date(endDate);
      default:
        return true;
    }
  };

  const generateReport = () => {
    if (!reportType) {
      return;
    }

    let reportData: any = {};

    switch (reportType) {
      case 'orders':
        const filteredOrders = orders.filter(
          (order) => order.type === 'os' && filterByPeriod(order.updatedAt)
        );
        const deliveredOrders = filteredOrders.filter((o) => o.status === 'delivered');
        const pendingOrders = filteredOrders.filter(
          (o) => o.status !== 'delivered' && o.status !== 'cancelled'
        );
        const cancelledOrders = filteredOrders.filter((o) => o.status === 'cancelled');

        reportData = {
          type: 'Ordens de Serviço',
          items: filteredOrders,
          total: filteredOrders.length,
          delivered: deliveredOrders.length,
          pending: pendingOrders.length,
          cancelled: cancelledOrders.length,
          revenue: deliveredOrders.reduce((sum, order) => sum + order.finalPrice, 0),
          pendingRevenue: pendingOrders.reduce((sum, order) => sum + order.finalPrice, 0),
        };
        break;

      case 'budgets':
        const filteredBudgets = orders.filter(
          (order) => order.type === 'budget' && filterByPeriod(order.createdAt)
        );
        reportData = {
          type: 'Orçamentos',
          items: filteredBudgets,
          total: filteredBudgets.length,
          totalValue: filteredBudgets.reduce((sum, order) => sum + order.finalPrice, 0),
          avgValue: filteredBudgets.length > 0
            ? filteredBudgets.reduce((sum, order) => sum + order.finalPrice, 0) / filteredBudgets.length
            : 0,
        };
        break;

      case 'clients':
        const filteredClients = clients.filter((client) =>
          filterByPeriod(client.createdAt)
        );
        reportData = {
          type: 'Clientes',
          items: filteredClients,
          total: filteredClients.length,
          withOrders: filteredClients.filter((client) =>
            orders.some((order) => order.clientName === client.name)
          ).length,
        };
        break;

      case 'financial':
        const financialOrders = orders.filter((order) =>
          filterByPeriod(order.updatedAt)
        );
        const revenue = financialOrders
          .filter((o) => o.status === 'delivered')
          .reduce((sum, order) => sum + order.finalPrice, 0);
        const pending = financialOrders
          .filter((o) => o.status !== 'delivered' && o.status !== 'cancelled')
          .reduce((sum, order) => sum + order.finalPrice, 0);
        
        reportData = {
          type: 'Financeiro',
          revenue,
          pending,
          total: revenue + pending,
          ordersDelivered: financialOrders.filter((o) => o.status === 'delivered').length,
          ordersPending: financialOrders.filter(
            (o) => o.status !== 'delivered' && o.status !== 'cancelled'
          ).length,
        };
        break;
    }

    setGeneratedReport(reportData);
  };

  // Gerar relatório automaticamente ao mudar filtros
  useEffect(() => {
    if (reportType && period) {
      if (period === 'custom' && (!startDate || !endDate)) {
        setGeneratedReport(null);
        return;
      }
      generateReport();
    }
  }, [reportType, period, startDate, endDate, orders, clients]);

  const getPeriodLabel = () => {
    const labels = {
      today: 'Hoje',
      week: 'Última Semana',
      month: 'Último Mês',
      quarter: 'Último Trimestre',
      year: 'Último Ano',
      custom: 'Personalizado',
    };
    return labels[period as keyof typeof labels] || '';
  };

  return (
    <>
      <Header title="Relatórios" subtitle="Análises e relatórios gerenciais" />
      <PageLayout>
        <Card className="p-6 mb-6">
          <h3 className="text-lg font-semibold mb-4">🔍 Filtros de Relatório</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <Label>Tipo de Relatório</Label>
              <Select
                value={reportType}
                onValueChange={(value: ReportType) => {
                  setReportType(value);
                  setGeneratedReport(null);
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="orders">Ordens de Serviço</SelectItem>
                  <SelectItem value="budgets">Orçamentos</SelectItem>
                  <SelectItem value="clients">Clientes</SelectItem>
                  <SelectItem value="financial">Financeiro</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Período</Label>
              <Select
                value={period}
                onValueChange={(value: Period) => {
                  setPeriod(value);
                  setGeneratedReport(null);
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o período" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">Hoje</SelectItem>
                  <SelectItem value="week">Última Semana</SelectItem>
                  <SelectItem value="month">Último Mês</SelectItem>
                  <SelectItem value="quarter">Último Trimestre</SelectItem>
                  <SelectItem value="year">Último Ano</SelectItem>
                  <SelectItem value="custom">Personalizado</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Button onClick={generateReport} className="w-full" disabled={!reportType}>
                🔄 Atualizar Relatório
              </Button>
            </div>
          </div>

          {period === 'custom' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Data Inicial</Label>
                <Input
                  type="date"
                  value={startDate}
                  onChange={(e) => {
                    setStartDate(e.target.value);
                    setGeneratedReport(null);
                  }}
                />
              </div>
              <div>
                <Label>Data Final</Label>
                <Input
                  type="date"
                  value={endDate}
                  onChange={(e) => {
                    setEndDate(e.target.value);
                    setGeneratedReport(null);
                  }}
                />
              </div>
            </div>
          )}
        </Card>

        {generatedReport && (
          <Card className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold">📄 Relatório: {generatedReport.type}</h3>
              <div className="text-sm text-muted-foreground">Período: {getPeriodLabel()}</div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              {reportType === 'orders' && (
                <>
                  <Card className="p-4 bg-primary/5">
                    <div className="text-sm text-muted-foreground mb-1">Total de Ordens</div>
                    <div className="text-3xl font-bold">{generatedReport.total}</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      ✅ {generatedReport.delivered} entregues
                    </div>
                  </Card>
                  <Card className="p-4 bg-success/5">
                    <div className="text-sm text-muted-foreground mb-1">Receita Recebida</div>
                    <div className="text-3xl font-bold">{formatCurrency(generatedReport.revenue)}</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      De ordens entregues
                    </div>
                  </Card>
                  <Card className="p-4 bg-yellow-500/5">
                    <div className="text-sm text-muted-foreground mb-1">Pendente</div>
                    <div className="text-3xl font-bold">{formatCurrency(generatedReport.pendingRevenue)}</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      ⏳ {generatedReport.pending} em andamento
                    </div>
                  </Card>
                  <Card className="p-4 bg-blue-500/5">
                    <div className="text-sm text-muted-foreground mb-1">Ticket Médio</div>
                    <div className="text-3xl font-bold">
                      {formatCurrency(generatedReport.delivered > 0 ? generatedReport.revenue / generatedReport.delivered : 0)}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      Das ordens entregues
                    </div>
                  </Card>
                </>
              )}

              {reportType === 'budgets' && (
                <>
                  <Card className="p-4 bg-primary/5">
                    <div className="text-sm text-muted-foreground mb-1">Total de Orçamentos</div>
                    <div className="text-3xl font-bold">{generatedReport.total}</div>
                  </Card>
                  <Card className="p-4 bg-success/5">
                    <div className="text-sm text-muted-foreground mb-1">Valor Total</div>
                    <div className="text-3xl font-bold">{formatCurrency(generatedReport.totalValue)}</div>
                  </Card>
                  <Card className="p-4 bg-blue-500/5">
                    <div className="text-sm text-muted-foreground mb-1">Valor Médio</div>
                    <div className="text-3xl font-bold">{formatCurrency(generatedReport.avgValue)}</div>
                  </Card>
                </>
              )}

              {reportType === 'clients' && (
                <>
                  <Card className="p-4 bg-primary/5">
                    <div className="text-sm text-muted-foreground mb-1">Total de Clientes</div>
                    <div className="text-3xl font-bold">{generatedReport.total}</div>
                  </Card>
                  <Card className="p-4 bg-success/5">
                    <div className="text-sm text-muted-foreground mb-1">Com Ordens</div>
                    <div className="text-3xl font-bold">{generatedReport.withOrders}</div>
                  </Card>
                  <Card className="p-4 bg-blue-500/5">
                    <div className="text-sm text-muted-foreground mb-1">Taxa de Conversão</div>
                    <div className="text-3xl font-bold">
                      {generatedReport.total > 0
                        ? Math.round((generatedReport.withOrders / generatedReport.total) * 100)
                        : 0}%
                    </div>
                  </Card>
                </>
              )}

              {reportType === 'financial' && (
                <>
                  <Card className="p-4 bg-success/5">
                    <div className="text-sm text-muted-foreground mb-1">Receita Recebida</div>
                    <div className="text-3xl font-bold">{formatCurrency(generatedReport.revenue)}</div>
                  </Card>
                  <Card className="p-4 bg-yellow-500/5">
                    <div className="text-sm text-muted-foreground mb-1">Receita Pendente</div>
                    <div className="text-3xl font-bold">{formatCurrency(generatedReport.pending)}</div>
                  </Card>
                  <Card className="p-4 bg-primary/5">
                    <div className="text-sm text-muted-foreground mb-1">Total</div>
                    <div className="text-3xl font-bold">{formatCurrency(generatedReport.total)}</div>
                  </Card>
                </>
              )}
            </div>

            {(reportType === 'orders' || reportType === 'budgets') && generatedReport.items && (
              <div className="space-y-3">
                <h4 className="font-semibold text-lg mb-3">Detalhes</h4>
                {generatedReport.items.map((order: any) => (
                  <div key={order.id} className="bg-muted/50 p-4 rounded-lg border">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h5 className="font-semibold">{order.clientName}</h5>
                        <p className="text-sm text-muted-foreground">
                          {order.model} • {order.service}
                        </p>
                        <p className="text-xs font-medium mt-1">
                          Status: {order.status === 'delivered' ? '✅ Entregue' : 
                                  order.status === 'ready' ? '🟢 Pronto' :
                                  order.status === 'in_progress' ? '🔵 Em Progresso' :
                                  order.status === 'waiting_parts' ? '⏳ Aguardando Peças' :
                                  order.status === 'pending' ? '🟡 Pendente' :
                                  order.status === 'cancelled' ? '❌ Cancelado' : order.status}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="font-bold">{formatCurrency(order.finalPrice)}</div>
                        <div className="text-xs text-muted-foreground">{formatDate(order.createdAt)}</div>
                      </div>
                    </div>
                    <div className="flex gap-2 mt-3">
                      <Button size="sm" variant="outline" onClick={() => printOrder(order)}>
                        🖨️ OS
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => printReceipt(order)}>
                        🧾 Recibo
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => printInvoice(order)}>
                        📄 Nota
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {reportType === 'clients' && generatedReport.items && (
              <div className="space-y-3">
                <h4 className="font-semibold text-lg mb-3">Lista de Clientes</h4>
                {generatedReport.items.map((client: any) => (
                  <div key={client.id} className="bg-muted/50 p-4 rounded-lg border">
                    <div className="flex justify-between items-start">
                      <div>
                        <h5 className="font-semibold">{client.name}</h5>
                        <p className="text-sm text-muted-foreground">
                          📱 {client.phone}
                          {client.email && ` • ${client.email}`}
                        </p>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Cadastrado em {formatDate(client.createdAt)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {reportType === 'financial' && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="p-4">
                    <h5 className="font-semibold mb-2">Ordens Entregues</h5>
                    <div className="text-2xl font-bold text-success">
                      {generatedReport.ordersDelivered}
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">
                      Receita: {formatCurrency(generatedReport.revenue)}
                    </div>
                  </Card>
                  <Card className="p-4">
                    <h5 className="font-semibold mb-2">Ordens Pendentes</h5>
                    <div className="text-2xl font-bold text-yellow-600">
                      {generatedReport.ordersPending}
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">
                      A Receber: {formatCurrency(generatedReport.pending)}
                    </div>
                  </Card>
                </div>
              </div>
            )}
          </Card>
        )}

        {!generatedReport && (
          <Card className="p-12 text-center">
            <div className="text-6xl mb-4">📊</div>
            <h3 className="text-xl font-semibold mb-2">Selecione os filtros e gere um relatório</h3>
            <p className="text-muted-foreground">
              Escolha o tipo de relatório e o período desejado para visualizar as análises
            </p>
          </Card>
        )}
      </PageLayout>
    </>
  );
};

export default Reports;
