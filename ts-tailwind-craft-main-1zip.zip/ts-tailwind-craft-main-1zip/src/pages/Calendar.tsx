import { useState } from 'react';
import { Header } from '@/components/layout/Header';
import { PageLayout } from '@/components/layout/PageLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { EventModal } from '@/components/calendar/EventModal';
import { useEvents } from '@/hooks/useEvents';
import { formatDate } from '@/utils/formatters';

const CalendarPage = () => {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [eventModalOpen, setEventModalOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const { events, addEvent, deleteEvent } = useEvents();

  const todayEvents = events.filter(
    (event) => event.date === (date?.toISOString().split('T')[0] || new Date().toISOString().split('T')[0])
  );

  const getEventTypeIcon = (type: string) => {
    const icons = {
      consulta: '🔍',
      entrega: '📦',
      retirada: '📤',
      orcamento: '💰',
      outro: '📌',
    };
    return icons[type as keyof typeof icons] || '📌';
  };

  return (
    <>
      <Header
        title="Agenda"
        subtitle="Gerenciamento de agendamentos e eventos"
        actions={
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setHistoryOpen(true)}>
              📜 Ver Histórico
            </Button>
            <Button onClick={() => setEventModalOpen(true)}>➕ Novo Evento</Button>
          </div>
        }
      />
      <PageLayout>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="p-6 lg:col-span-2">
            <h3 className="text-lg font-semibold mb-4">
              📅 Eventos - {date ? formatDate(date.toISOString()) : 'Hoje'}
            </h3>
            <div className="space-y-3">
              {todayEvents.length === 0 ? (
                <p className="text-muted-foreground">Nenhum evento agendado para esta data</p>
              ) : (
                todayEvents.map((event) => (
                  <div
                    key={event.id}
                    className="bg-muted/50 p-4 rounded-lg border-l-4 border-primary"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h4 className="font-semibold">
                          {getEventTypeIcon(event.type)} {event.title}
                        </h4>
                        {event.time && (
                          <p className="text-sm text-muted-foreground">🕐 {event.time}</p>
                        )}
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          if (confirm('Deseja excluir este evento?')) {
                            deleteEvent(event.id);
                          }
                        }}
                      >
                        🗑️
                      </Button>
                    </div>
                    {event.client && (
                      <p className="text-sm">
                        <strong>Cliente:</strong> {event.client}
                      </p>
                    )}
                    {event.description && (
                      <p className="text-sm text-muted-foreground mt-2">{event.description}</p>
                    )}
                  </div>
                ))
              )}
            </div>
          </Card>
          
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Calendário</h3>
            <Calendar
              mode="single"
              selected={date}
              onSelect={setDate}
              className="rounded-md border"
            />
          </Card>
        </div>

        {historyOpen && (
          <Card className="p-6 mt-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">📜 Histórico de Eventos</h3>
              <Button variant="ghost" size="sm" onClick={() => setHistoryOpen(false)}>
                ✕ Fechar
              </Button>
            </div>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {events.length === 0 ? (
                <p className="text-muted-foreground">Nenhum evento cadastrado</p>
              ) : (
                events
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                  .map((event) => (
                    <div
                      key={event.id}
                      className="bg-muted/50 p-3 rounded-lg flex justify-between items-center"
                    >
                      <div>
                        <p className="font-semibold">
                          {getEventTypeIcon(event.type)} {event.title}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          📅 {formatDate(event.date)} {event.time && `• 🕐 ${event.time}`}
                        </p>
                        {event.client && (
                          <p className="text-sm">Cliente: {event.client}</p>
                        )}
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          if (confirm('Deseja excluir este evento?')) {
                            deleteEvent(event.id);
                          }
                        }}
                      >
                        🗑️
                      </Button>
                    </div>
                  ))
              )}
            </div>
          </Card>
        )}
      </PageLayout>

      <EventModal
        open={eventModalOpen}
        onOpenChange={setEventModalOpen}
        onSave={addEvent}
        selectedDate={date}
      />
    </>
  );
};

export default CalendarPage;
