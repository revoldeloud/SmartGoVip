import { useState } from 'react';
import { Header } from '@/components/layout/Header';
import { PageLayout } from '@/components/layout/PageLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useClients } from '@/hooks/useClients';
import { formatDate } from '@/utils/formatters';
import { ClientModal } from '@/components/clients/ClientModal';
import { Client } from '@/types';

const Clients = () => {
  const { clients, addClient, updateClient, deleteClient } = useClients();
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editClient, setEditClient] = useState<Client | null>(null);

  const filteredClients = clients.filter((client) =>
    client.name.toLowerCase().includes(search.toLowerCase()) ||
    client.phone.includes(search) ||
    client.email?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <>
      <Header
        title="Clientes"
        subtitle={`${filteredClients.length} clientes cadastrados`}
        actions={
          <>
            <Button onClick={() => { setEditClient(null); setModalOpen(true); }}>
              ➕ Novo Cliente
            </Button>
            <Button variant="outline">📊 Exportar Lista</Button>
          </>
        }
      />
      <PageLayout>
        <Card className="p-6">
          <Input
            type="search"
            placeholder="🔍 Buscar clientes..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="mb-6"
          />

          {filteredClients.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              Nenhum cliente encontrado
            </p>
          ) : (
            <div className="space-y-4">
              {filteredClients.map((client) => (
                <div
                  key={client.id}
                  className="bg-muted/50 p-4 rounded-lg border-l-4 border-primary"
                >
                  <h4 className="font-semibold text-lg mb-2">{client.name}</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mb-3 text-sm">
                    <p>📱 {client.phone}</p>
                    {client.email && <p>📧 {client.email}</p>}
                    {client.address && <p>📍 {client.address}</p>}
                    <p>📅 Cliente desde {formatDate(client.createdAt)}</p>
                  </div>
                  {client.notes && (
                    <p className="text-sm text-muted-foreground mb-3">
                      💬 {client.notes}
                    </p>
                  )}
                  <div className="flex flex-wrap gap-2">
                    <Button variant="outline" size="sm">
                      👁️ Ver Histórico
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => { setEditClient(client); setModalOpen(true); }}
                    >
                      ✏️ Editar
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => {
                        if (confirm('Deseja realmente excluir este cliente?')) {
                          deleteClient(client.id);
                        }
                      }}
                    >
                      🗑️ Excluir
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </PageLayout>

      <ClientModal
        client={editClient}
        open={modalOpen}
        onOpenChange={setModalOpen}
        onSave={addClient}
        onUpdate={updateClient}
      />
    </>
  );
};

export default Clients;
