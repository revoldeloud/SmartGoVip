import { useState } from 'react';
import { Header } from '@/components/layout/Header';
import { PageLayout } from '@/components/layout/PageLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useOrders } from '@/hooks/useOrders';
import { formatCurrency, formatDate, getStatusLabel, getStatusColor } from '@/utils/formatters';
import { useNavigate } from 'react-router-dom';
import { OrderViewModal } from '@/components/orders/OrderViewModal';
import { OrderEditModal } from '@/components/orders/OrderEditModal';
import { ServiceOrder } from '@/types';
import { printOrder } from '@/utils/print';
import { sendToWhatsApp } from '@/utils/whatsapp';
import { toast } from 'sonner';

const Budgets = () => {
  const navigate = useNavigate();
  const { orders, updateOrder, deleteOrder } = useOrders();
  const [search, setSearch] = useState('');
  const [viewOrder, setViewOrder] = useState<ServiceOrder | null>(null);
  const [editOrder, setEditOrder] = useState<ServiceOrder | null>(null);

  const filteredOrders = orders.filter(
    (order) =>
      order.type === 'budget' &&
      (order.clientName.toLowerCase().includes(search.toLowerCase()) ||
        order.model.toLowerCase().includes(search.toLowerCase()) ||
        order.phone.includes(search))
  );

  const handleExportExcel = () => {
    if (filteredOrders.length === 0) {
      toast.error('Nenhum orçamento para exportar');
      return;
    }

    const csvContent = [
      ['Cliente', 'Telefone', 'Modelo', 'Serviço', 'Status', 'Valor', 'Data'].join(','),
      ...filteredOrders.map(order =>
        [
          order.clientName,
          order.phone,
          order.model,
          order.service,
          getStatusLabel(order.status),
          order.finalPrice.toFixed(2),
          formatDate(order.createdAt)
        ].join(',')
      )
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `orcamentos_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    toast.success('Arquivo exportado com sucesso!');
  };

  const handlePrintAll = () => {
    if (filteredOrders.length === 0) {
      toast.error('Nenhum orçamento para imprimir');
      return;
    }
    filteredOrders.forEach(order => printOrder(order));
    toast.success(`${filteredOrders.length} orçamentos enviados para impressão!`);
  };

  return (
    <>
      <Header
        title="Orçamentos"
        subtitle={`${filteredOrders.length} orçamentos encontrados`}
        actions={
          <Button onClick={() => navigate('/novo')}>➕ Novo Orçamento</Button>
        }
      />
      <PageLayout>
        <Card className="p-6">
          <Input
            type="search"
            placeholder="🔍 Buscar por cliente, modelo, serviço, telefone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="mb-6"
          />

          <div className="flex gap-2 mb-6">
            <Button variant="outline" onClick={handleExportExcel}>📊 Exportar Excel</Button>
            <Button variant="outline" onClick={handlePrintAll}>🖨️ Imprimir Todos</Button>
          </div>

          {filteredOrders.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              Nenhum orçamento encontrado
            </p>
          ) : (
            <div className="space-y-4">
              {filteredOrders.map((order) => (
                <div
                  key={order.id}
                  className="bg-muted/50 p-4 rounded-lg border-l-4 border-primary"
                >
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h4 className="font-semibold text-lg">{order.clientName}</h4>
                      <p className="text-sm text-muted-foreground">
                        📱 {order.phone}
                      </p>
                    </div>
                    <span
                      className={`text-xs px-3 py-1 rounded-full font-semibold ${getStatusColor(
                        order.status
                      )}`}
                    >
                      {getStatusLabel(order.status)}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mb-3 text-sm">
                    <p>
                      <strong>Modelo:</strong> {order.model}
                    </p>
                    <p>
                      <strong>Serviço:</strong> {order.service}
                    </p>
                    <p>
                      <strong>Valor:</strong> {formatCurrency(order.finalPrice)}
                    </p>
                    <p>
                      <strong>Data:</strong> {formatDate(order.createdAt)}
                    </p>
                  </div>

                  {order.observations && (
                    <p className="text-sm text-muted-foreground mb-3">
                      💬 {order.observations}
                    </p>
                  )}

                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setViewOrder(order)}
                    >
                      👁️ Ver
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setEditOrder(order)}
                    >
                      ✏️ Editar
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => printOrder(order)}
                    >
                      🖨️ Imprimir
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-green-600 hover:bg-green-700 text-white"
                      onClick={() => sendToWhatsApp(order)}
                    >
                      📱 WhatsApp
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => {
                        if (confirm('Deseja realmente excluir este orçamento?')) {
                          deleteOrder(order.id);
                        }
                      }}
                    >
                      🗑️ Excluir
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </PageLayout>

      <OrderViewModal
        order={viewOrder}
        open={!!viewOrder}
        onOpenChange={(open) => !open && setViewOrder(null)}
      />
      <OrderEditModal
        order={editOrder}
        open={!!editOrder}
        onOpenChange={(open) => !open && setEditOrder(null)}
        onSave={updateOrder}
      />
    </>
  );
};

export default Budgets;
