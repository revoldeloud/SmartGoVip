import { useState } from 'react';
import { Header } from '@/components/layout/Header';
import { PageLayout } from '@/components/layout/PageLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { StockModal } from '@/components/stock/StockModal';
import { useStock } from '@/hooks/useStock';
import { StockItem } from '@/types';
import { formatCurrency } from '@/utils/formatters';
import { toast } from 'sonner';

const Stock = () => {
  const { stock, addItem, updateItem, deleteItem, updateQuantity } = useStock();
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<StockItem | null>(null);

  const filteredStock = stock.filter(
    (item) =>
      item.name.toLowerCase().includes(search.toLowerCase()) ||
      item.category.toLowerCase().includes(search.toLowerCase())
  );

  const handleSave = (data: Omit<StockItem, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (editingItem) {
      updateItem(editingItem.id, data);
    } else {
      addItem(data);
    }
    setEditingItem(null);
  };

  const handleEdit = (item: StockItem) => {
    setEditingItem(item);
    setModalOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Tem certeza que deseja excluir este item?')) {
      deleteItem(id);
    }
  };

  const handleAddStock = (item: StockItem) => {
    const quantity = prompt(`Adicionar quantas unidades de "${item.name}"?`);
    if (quantity && !isNaN(Number(quantity))) {
      updateQuantity(item.id, item.quantity + Number(quantity));
      toast.success('Estoque atualizado!');
    }
  };

  const handleRemoveStock = (item: StockItem) => {
    const quantity = prompt(`Remover quantas unidades de "${item.name}"?`);
    if (quantity && !isNaN(Number(quantity))) {
      const newQuantity = item.quantity - Number(quantity);
      if (newQuantity < 0) {
        toast.error('Quantidade insuficiente em estoque!');
        return;
      }
      updateQuantity(item.id, newQuantity);
      toast.success('Estoque atualizado!');
    }
  };

  const getCategoryIcon = (category: string) => {
    const icons = {
      tela: '📱',
      bateria: '🔋',
      camera: '📷',
      conector: '🔌',
      outro: '🔧',
    };
    return icons[category as keyof typeof icons] || '📦';
  };

  const getStockStatus = (item: StockItem) => {
    if (item.quantity === 0) {
      return <Badge variant="destructive">Sem Estoque</Badge>;
    }
    if (item.quantity <= item.minQuantity) {
      return <Badge className="bg-yellow-500">Estoque Baixo</Badge>;
    }
    return <Badge className="bg-green-500">OK</Badge>;
  };

  const lowStockItems = stock.filter(
    (item) => item.quantity <= item.minQuantity && item.quantity > 0
  );
  const outOfStockItems = stock.filter((item) => item.quantity === 0);

  return (
    <>
      <Header
        title="Estoque"
        subtitle="Gerenciamento de peças e materiais"
        actions={
          <Button onClick={() => { setEditingItem(null); setModalOpen(true); }}>
            ➕ Nova Peça
          </Button>
        }
      />
      <PageLayout>
        {(lowStockItems.length > 0 || outOfStockItems.length > 0) && (
          <Card className="p-4 mb-6 bg-yellow-50 border-yellow-200">
            <div className="flex items-start gap-2">
              <span className="text-2xl">⚠️</span>
              <div>
                <h3 className="font-semibold">Alertas de Estoque</h3>
                {outOfStockItems.length > 0 && (
                  <p className="text-sm text-muted-foreground">
                    {outOfStockItems.length} item(ns) sem estoque
                  </p>
                )}
                {lowStockItems.length > 0 && (
                  <p className="text-sm text-muted-foreground">
                    {lowStockItems.length} item(ns) com estoque baixo
                  </p>
                )}
              </div>
            </div>
          </Card>
        )}

        <Card className="p-6 mb-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <Input
              placeholder="🔍 Buscar por nome ou categoria..."
              className="flex-1"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4">📦 Itens em Estoque</h3>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Item</TableHead>
                  <TableHead>Categoria</TableHead>
                  <TableHead>Quantidade</TableHead>
                  <TableHead>Custo</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStock.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                      {search ? 'Nenhum item encontrado' : 'Nenhum item cadastrado no estoque'}
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredStock.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell>
                        <span className="flex items-center gap-2">
                          {getCategoryIcon(item.category)}
                          <span className="capitalize">{item.category}</span>
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold">{item.quantity}</span>
                          <span className="text-xs text-muted-foreground">
                            (mín: {item.minQuantity})
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>{formatCurrency(item.cost)}</TableCell>
                      <TableCell>{getStockStatus(item)}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleAddStock(item)}
                            title="Adicionar ao estoque"
                          >
                            ➕
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleRemoveStock(item)}
                            title="Remover do estoque"
                          >
                            ➖
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEdit(item)}
                          >
                            ✏️
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleDelete(item.id)}
                          >
                            🗑️
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </Card>
      </PageLayout>

      <StockModal
        open={modalOpen}
        onOpenChange={(open) => {
          setModalOpen(open);
          if (!open) setEditingItem(null);
        }}
        onSave={handleSave}
        item={editingItem}
      />
    </>
  );
};

export default Stock;
