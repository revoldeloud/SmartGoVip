import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Header } from '@/components/layout/Header';
import { PageLayout } from '@/components/layout/PageLayout';
import { StatCard } from '@/components/dashboard/StatCard';
import { ChartCard } from '@/components/dashboard/ChartCard';
import { MobileHomeGrid } from '@/components/layout/Sidebar';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { QuickOrderModal } from '@/components/orders/QuickOrderModal';
import { EntryType } from '@/types';
import { useOrders } from '@/hooks/useOrders';
import { useClients } from '@/hooks/useClients';
import { formatCurrency, formatDate, getStatusLabel, getStatusColor } from '@/utils/formatters';
import { DashboardStats } from '@/types';
import { Doughnut } from 'react-chartjs-2';
import { toast } from 'sonner';
import { getOrders, saveOrders } from '@/utils/storage';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

const Dashboard = () => {
  const navigate = useNavigate();
  const { orders, addOrder } = useOrders();
  const { clients } = useClients();
  const [quickOrderOpen, setQuickOrderOpen] = useState(false);
  const [quickOrderType, setQuickOrderType] = useState<EntryType>('os');
  const [stats, setStats] = useState<DashboardStats>({
    today: 0,
    clients: 0,
    pending: 0,
    in_progress: 0,
    ready: 0,
    total: 0,
    profit: 0,
  });

  useEffect(() => {
    calculateStats();
  }, [orders, clients]);

  const calculateStats = () => {
    const today = new Date().toISOString().split('T')[0];
    const todayOrders = orders.filter(o => o.createdAt.startsWith(today));
    
    const pending = orders.filter(o => o.status === 'pending').length;
    const in_progress = orders.filter(o => o.status === 'in_progress').length;
    const ready = orders.filter(o => o.status === 'ready').length;
    
    const profit = orders
      .filter(o => o.status === 'delivered')
      .reduce((sum, o) => sum + o.finalPrice, 0);

    setStats({
      today: todayOrders.length,
      clients: clients.length,
      pending,
      in_progress,
      ready,
      total: orders.length,
      profit,
    });
  };

  const statusChartData = {
    labels: ['Pendente', 'Em Andamento', 'Pronto'],
    datasets: [
      {
        data: [stats.pending, stats.in_progress, stats.ready],
        backgroundColor: ['#f59e0b', '#3b82f6', '#10b981'],
        borderWidth: 0,
        borderRadius: 4,
      },
    ],
  };

  const chartOptions = {
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          color: 'rgba(255, 255, 255, 0.7)',
          padding: 20,
          font: {
            size: 12,
          },
        },
      },
    },
  };

  const recentOrders = orders.slice(0, 5);

  const handleBackup = () => {
    const data = {
      orders: getOrders(),
      clients,
      timestamp: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `backup-smartgo-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Backup realizado com sucesso!');
  };

  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e: any) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
          try {
            const data = JSON.parse(event.target?.result as string);
            if (data.orders) {
              saveOrders(data.orders);
              toast.success('Dados importados com sucesso! Recarregue a página.');
            }
          } catch (error) {
            toast.error('Erro ao importar arquivo');
          }
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  return (
    <>
      {/* Mobile Home Grid */}
      <MobileHomeGrid />

      {/* Desktop Dashboard */}
      <div className="hidden md:block">
        <Header
          title="Dashboard"
          subtitle="Resumo rápido do sistema"
          actions={
            <>
              <Button variant="outline" onClick={handleBackup} className="bg-white/5 border-white/10 hover:bg-white/10">
                💾 Backup
              </Button>
              <Button variant="outline" onClick={handleImport} className="bg-white/5 border-white/10 hover:bg-white/10">
                📤 Importar
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button className="futuristic-btn text-white">➕ OS Rápida</Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48 glass-card border-white/10">
                  <DropdownMenuItem 
                    onClick={() => {
                      setQuickOrderType('os');
                      setQuickOrderOpen(true);
                    }}
                    className="hover:bg-white/10 cursor-pointer"
                  >
                    📋 Ordem de Serviço
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={() => {
                      setQuickOrderType('budget');
                      setQuickOrderOpen(true);
                    }}
                    className="hover:bg-white/10 cursor-pointer"
                  >
                    💰 Orçamento
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          }
        />
        <PageLayout>
          {/* Welcome Card */}
          <div className="glass-card p-6 mb-6 relative overflow-hidden">
            <div className="relative z-10">
              <h2 className="text-xl font-semibold mb-2 flex items-center gap-2">
                <span className="text-2xl">👋</span>
                Bem-vindo(a) ao SmartGO v4.0
              </h2>
              <p className="text-muted-foreground">
                Sistema completo de gestão para assistência técnica. Agora com
                agenda, estoque e relatórios avançados.
              </p>
            </div>
            <div className="absolute -right-10 -top-10 w-40 h-40 bg-gradient-to-br from-cyan-500/20 to-purple-600/20 rounded-full blur-3xl" />
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 mb-6">
            <StatCard label="Serviços Hoje" value={stats.today} />
            <StatCard label="Clientes Ativos" value={stats.clients} />
            <StatCard
              label="Pendentes"
              value={stats.pending}
              icon="⏳"
              variant="warning"
            />
            <StatCard
              label="Em Andamento"
              value={stats.in_progress}
              icon="🔧"
              variant="info"
            />
            <StatCard
              label="Prontos"
              value={stats.ready}
              icon="✅"
              variant="success"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <StatCard label="Total de Serviços" value={stats.total} />
            <StatCard
              label="Lucro Total (Entregues)"
              value={formatCurrency(stats.profit)}
              variant="success"
            />
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
            <ChartCard title="Serviços por Status">
              <Doughnut data={statusChartData} options={chartOptions} />
            </ChartCard>
            <ChartCard title="Receita Mensal">
              <div className="flex items-center justify-center h-full text-muted-foreground">
                <div className="text-center">
                  <div className="text-4xl mb-2">📊</div>
                  <p>Gráfico de receita em desenvolvimento</p>
                </div>
              </div>
            </ChartCard>
          </div>

          {/* Recent Orders */}
          <div className="glass-card p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <span className="w-1 h-6 bg-gradient-to-b from-cyan-400 to-purple-500 rounded-full" />
              Ordens Recentes
            </h3>
            {recentOrders.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <div className="text-4xl mb-2">📋</div>
                <p>Nenhuma ordem encontrada</p>
              </div>
            ) : (
              <div className="space-y-3">
                {recentOrders.map((order) => (
                  <div
                    key={order.id}
                    className="bg-white/5 p-4 rounded-xl border border-white/10 hover:border-primary/30 transition-all duration-300 hover:bg-white/10"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-semibold">{order.clientName}</h4>
                      <span
                        className={`text-xs px-3 py-1 rounded-full font-semibold ${getStatusColor(
                          order.status
                        )}`}
                      >
                        {getStatusLabel(order.status)}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {order.model} • {order.service}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      <span className="text-primary font-medium">{formatCurrency(order.finalPrice)}</span> • {formatDate(order.createdAt)}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </PageLayout>
      </div>

      <QuickOrderModal
        open={quickOrderOpen}
        onOpenChange={setQuickOrderOpen}
        type={quickOrderType}
        onSave={(orderData) => {
          addOrder(orderData);
          navigate(quickOrderType === 'os' ? '/ordens' : '/orcamentos');
        }}
      />
    </>
  );
};

export default Dashboard;
