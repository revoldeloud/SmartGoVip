import { useState, useEffect } from 'react';
import { Header } from '@/components/layout/Header';
import { PageLayout } from '@/components/layout/PageLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ClientAutocomplete } from '@/components/clients/ClientAutocomplete';
import { ProductAutocomplete } from '@/components/stock/ProductAutocomplete';
import { ModelAutocomplete } from '@/components/orders/ModelAutocomplete';
import { PhotoGallery } from '@/components/orders/PhotoGallery';
import { StockItem } from '@/types';
import { useOrders } from '@/hooks/useOrders';
import { EntryType, OrderStatus, Client } from '@/types';
import { useNavigate, useLocation } from 'react-router-dom';
import { toast } from 'sonner';

const NewOrder = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { addOrder } = useOrders();
  
  const [formData, setFormData] = useState({
    type: 'os' as EntryType,
    status: 'pending' as OrderStatus,
    clientName: '',
    phone: '',
    email: '',
    address: '',
    model: '',
    imei: '',
    service: 'Troca de tela',
    defect: '',
    screenType: 'incell',
    observations: '',
    calcMode: 'auto',
    servicePrice: 0,
    partsPrice: 50,
    finalPrice: 0,
    warranty: 90,
    deadline: '',
    beforePhotos: [] as string[],
  });

  // Pre-fill form if coming from problem database
  useEffect(() => {
    const state = location.state as any;
    if (state?.prefill) {
      setFormData(prev => ({
        ...prev,
        ...state.prefill
      }));
      
      if (state.fromProblem) {
        toast.success('Orçamento pré-preenchido com dados do problema!');
      }
    }
  }, [location.state]);

  const handleClientSelect = (client: Client) => {
    setFormData({
      ...formData,
      clientName: client.name,
      phone: client.phone,
      email: client.email || '',
      address: client.address || '',
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.clientName || !formData.phone || !formData.model) {
      alert('Preencha os campos obrigatórios');
      return;
    }

    addOrder({
      type: formData.type,
      status: formData.status,
      clientName: formData.clientName,
      phone: formData.phone,
      email: formData.email,
      address: formData.address,
      model: formData.model,
      imei: formData.imei,
      service: formData.service,
      defect: formData.defect,
      screenType: formData.screenType,
      observations: formData.observations,
      servicePrice: formData.servicePrice,
      partsPrice: formData.partsPrice,
      finalPrice: formData.finalPrice,
      warranty: formData.warranty,
      deadline: formData.deadline,
      beforePhotos: formData.beforePhotos,
    });

    navigate(formData.type === 'os' ? '/ordens' : '/orcamentos');
  };

  const calculatePrice = () => {
    if (formData.calcMode === 'auto') {
      const final = formData.partsPrice * 2 + 70;
      setFormData({ ...formData, finalPrice: final });
    } else {
      const final = formData.servicePrice + formData.partsPrice;
      setFormData({ ...formData, finalPrice: final });
    }
  };

  return (
    <>
      <Header
        title="Novo"
        subtitle="Criar Ordem de Serviço / Orçamento"
      />
      <PageLayout>
        <Card className="p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Tipo</Label>
                <Select
                  value={formData.type}
                  onValueChange={(value: EntryType) =>
                    setFormData({ ...formData, type: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="os">📋 Ordem de Serviço</SelectItem>
                    <SelectItem value="budget">🧾 Orçamento</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Status</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value: OrderStatus) =>
                    setFormData({ ...formData, status: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">⏳ Pendente</SelectItem>
                    <SelectItem value="in_progress">🔧 Em Andamento</SelectItem>
                    <SelectItem value="waiting_parts">⏸️ Aguardando Peças</SelectItem>
                    <SelectItem value="ready">✅ Pronto</SelectItem>
                    <SelectItem value="delivered">📦 Entregue</SelectItem>
                    <SelectItem value="cancelled">❌ Cancelado</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <ClientAutocomplete
                  value={formData.clientName}
                  onChange={(value) => setFormData({ ...formData, clientName: value })}
                  onClientSelect={handleClientSelect}
                  required
                />
              </div>

              <div>
                <Label>Telefone *</Label>
                <Input
                  value={formData.phone}
                  onChange={(e) =>
                    setFormData({ ...formData, phone: e.target.value })
                  }
                  placeholder="(73) 9xxxx-xxxx"
                  required
                />
              </div>

              <div>
                <Label>E-mail</Label>
                <Input
                  type="email"
                  value={formData.email}
                  onChange={(e) =>
                    setFormData({ ...formData, email: e.target.value })
                  }
                  placeholder="cliente@email.com"
                />
              </div>

              <div>
                <Label>Endereço</Label>
                <Input
                  value={formData.address}
                  onChange={(e) =>
                    setFormData({ ...formData, address: e.target.value })
                  }
                  placeholder="Rua, nº, Bairro"
                />
              </div>

              <div className="md:col-span-2">
                <ProductAutocomplete
                  value={formData.service}
                  onChange={(value) => setFormData({ ...formData, service: value })}
                  onProductSelect={(product: StockItem) => {
                    setFormData({
                      ...formData,
                      service: product.name,
                      partsPrice: product.cost,
                    });
                  }}
                  label="Serviço / Produto"
                  placeholder="Digite o serviço ou escolha um produto do estoque..."
                  required
                />
              </div>

              <div>
                <ModelAutocomplete
                  value={formData.model}
                  onChange={(value) => setFormData({ ...formData, model: value })}
                  required
                />
              </div>

              <div>
                <Label>IMEI / Serial</Label>
                <Input
                  value={formData.imei}
                  onChange={(e) =>
                    setFormData({ ...formData, imei: e.target.value })
                  }
                  placeholder="Número do IMEI"
                />
              </div>

              <div>
                <Label>IMEI / Serial</Label>
                <Input
                  value={formData.imei}
                  onChange={(e) =>
                    setFormData({ ...formData, imei: e.target.value })
                  }
                  placeholder="Número do IMEI"
                />
              </div>

              <div className="md:col-span-2">
                <Label>Defeito Relatado</Label>
                <Textarea
                  value={formData.defect}
                  onChange={(e) =>
                    setFormData({ ...formData, defect: e.target.value })
                  }
                  placeholder="Descreva o problema relatado pelo cliente..."
                  rows={2}
                />
              </div>

              <div className="md:col-span-2">
                <Label>Observações</Label>
                <Textarea
                  value={formData.observations}
                  onChange={(e) =>
                    setFormData({ ...formData, observations: e.target.value })
                  }
                  placeholder="Detalhes adicionais, observações importantes..."
                  rows={2}
                />
              </div>

              <div>
                <Label>Valor do Serviço (R$)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.servicePrice}
                  onChange={(e) =>
                    setFormData({ ...formData, servicePrice: parseFloat(e.target.value) || 0 })
                  }
                />
              </div>

              <div>
                <Label>Valor das Peças (R$)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.partsPrice}
                  onChange={(e) =>
                    setFormData({ ...formData, partsPrice: parseFloat(e.target.value) || 0 })
                  }
                />
              </div>

              <div>
                <Label>Valor final (R$)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.finalPrice}
                  onChange={(e) =>
                    setFormData({ ...formData, finalPrice: parseFloat(e.target.value) || 0 })
                  }
                />
              </div>

              <div>
                <Label>Garantia (dias)</Label>
                <Input
                  type="number"
                  value={formData.warranty}
                  onChange={(e) =>
                    setFormData({ ...formData, warranty: parseInt(e.target.value) || 0 })
                  }
                />
              </div>

              <div className="md:col-span-2 space-y-2">
                <div className="flex items-center gap-2">
                  <span className="bg-red-500/10 text-red-600 px-3 py-1 rounded-md text-sm font-medium border border-red-500/20">
                    📸 ANTES - Condição de Entrada
                  </span>
                  <span className="text-xs text-muted-foreground">(opcional)</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Fotografe o estado atual do aparelho ao receber do cliente
                </p>
                <PhotoGallery
                  photos={formData.beforePhotos}
                  onPhotosChange={(photos) => setFormData({ ...formData, beforePhotos: photos })}
                />
              </div>
            </div>

            <div className="flex gap-3">
              <Button type="button" variant="outline" onClick={calculatePrice}>
                🧮 Calcular
              </Button>
              <Button type="submit">💾 Salvar</Button>
              <Button
                type="button"
                variant="ghost"
                onClick={() => navigate('/ordens')}
              >
                ❌ Cancelar
              </Button>
            </div>
          </form>
        </Card>
      </PageLayout>
    </>
  );
};

export default NewOrder;
