import { useState } from 'react';
import { Header } from '@/components/layout/Header';
import { PageLayout } from '@/components/layout/PageLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PhoneModal } from '@/components/phones/PhoneModal';
import { usePhones } from '@/hooks/usePhones';
import { Phone } from '@/types';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

const Phones = () => {
  const { phones, addPhone, updatePhone, deletePhone } = usePhones();
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedPhone, setSelectedPhone] = useState<Phone | undefined>();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [phoneToDelete, setPhoneToDelete] = useState<Phone | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const handleAdd = () => {
    setSelectedPhone(undefined);
    setModalOpen(true);
  };

  const handleEdit = (phone: Phone) => {
    setSelectedPhone(phone);
    setModalOpen(true);
  };

  const handleDeleteClick = (phone: Phone) => {
    setPhoneToDelete(phone);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = () => {
    if (phoneToDelete) {
      deletePhone(phoneToDelete.id);
      setPhoneToDelete(null);
    }
    setDeleteDialogOpen(false);
  };

  const filteredPhones = phones.filter(
    (phone) =>
      phone.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
      phone.model.toLowerCase().includes(searchTerm.toLowerCase()) ||
      phone.ram.toLowerCase().includes(searchTerm.toLowerCase()) ||
      phone.storage.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <>
      <Header
        title="Celulares"
        subtitle="Gerenciar modelos de celulares"
        actions={
          <Button onClick={handleAdd}>
            ➕ Novo Celular
          </Button>
        }
      />
      <PageLayout>
        <Card className="p-6">
          <div className="mb-6">
            <Input
              placeholder="🔍 Buscar por marca, modelo, RAM ou armazenamento..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-md"
            />
          </div>

          {filteredPhones.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <div className="text-6xl mb-4">📱</div>
              <p className="text-lg">Nenhum celular cadastrado</p>
              <Button onClick={handleAdd} className="mt-4">
                ➕ Adicionar primeiro celular
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredPhones.map((phone) => (
                <Card key={phone.id} className="p-4">
                  <div className="flex items-center gap-4">
                    {/* Phone Image */}
                    <div className="flex-shrink-0">
                      {phone.frontPhoto ? (
                        <img
                          src={phone.frontPhoto}
                          alt={`${phone.brand} ${phone.model}`}
                          className="w-20 h-28 object-cover rounded border"
                        />
                      ) : (
                        <div className="w-20 h-28 bg-muted rounded border flex items-center justify-center">
                          <span className="text-xs text-muted-foreground">Sem foto</span>
                        </div>
                      )}
                    </div>

                    {/* Phone Info */}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-lg truncate">
                        <span className="text-muted-foreground">{phone.brand}</span> {phone.model}
                      </h3>
                      
                      {/* Specs with Icons */}
                      <div className="flex flex-wrap gap-4 mt-3">
                        <div className="flex flex-col items-center gap-1 min-w-[70px]">
                          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                            <svg className="w-5 h-5 text-primary" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M17,19H7V5H17M17,1H7C5.89,1 5,1.89 5,3V21A2,2 0 0,0 7,23H17A2,2 0 0,0 19,21V3C19,1.89 18.1,1 17,1Z" />
                            </svg>
                          </div>
                          <span className="text-xs text-muted-foreground">RAM</span>
                          <span className="text-xs font-medium">{phone.ram}</span>
                        </div>

                        <div className="flex flex-col items-center gap-1 min-w-[70px]">
                          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                            <svg className="w-5 h-5 text-primary" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M6,2H18A2,2 0 0,1 20,4V20A2,2 0 0,1 18,22H6A2,2 0 0,1 4,20V4A2,2 0 0,1 6,2M12,4A6,6 0 0,0 6,10C6,13.31 8.69,16 12.1,16L11.22,13.77C10.23,13.4 9.5,12.56 9.5,11.5A2.5,2.5 0 0,1 12,9A2.5,2.5 0 0,1 14.5,11.5C14.5,12.56 13.77,13.4 12.78,13.77L13.66,16C17.03,16 18,13.31 18,10A6,6 0 0,0 12,4Z" />
                            </svg>
                          </div>
                          <span className="text-xs text-muted-foreground">Storage</span>
                          <span className="text-xs font-medium">{phone.storage}</span>
                        </div>

                        {phone.backPhoto && (
                          <div className="flex flex-col items-center gap-1 min-w-[70px]">
                            <div className="w-10 h-10 rounded-full bg-muted overflow-hidden border">
                              <img
                                src={phone.backPhoto}
                                alt="Verso"
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <span className="text-xs text-muted-foreground">Verso</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex flex-col gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEdit(phone)}
                      >
                        ✏️
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteClick(phone)}
                      >
                        🗑️
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </Card>
      </PageLayout>

      <PhoneModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        phone={selectedPhone}
        onSave={addPhone}
        onUpdate={updatePhone}
      />

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir o celular{' '}
              <strong>
                {phoneToDelete?.brand} {phoneToDelete?.model}
              </strong>
              ? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm}>
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default Phones;
