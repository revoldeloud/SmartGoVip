import { useState, useEffect } from 'react';
import { Header } from '@/components/layout/Header';
import { PageLayout } from '@/components/layout/PageLayout';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { RefreshCw, Search, Wrench, BookOpen, Zap } from 'lucide-react';
import { getAllProblems, getProblemsByCategory, searchProblems } from '@/data/phoneProblems';
import { PhoneProblem } from '@/types';
import { getRepairGuides, clearCache } from '@/services/ifixitApi';
import { IFixitGuide } from '@/types/ifixit';
import { GuideCard } from '@/components/solutions/GuideCard';
import { GuideModal } from '@/components/solutions/GuideModal';
import { ProblemDetailCard } from '@/components/solutions/ProblemDetailCard';
import { DiagnosticAnalytics } from '@/components/solutions/DiagnosticAnalytics';
import { DiagnosticHistoryList } from '@/components/solutions/DiagnosticHistoryList';

// Popular phone models database
const popularPhones = [
  // iPhone
  { brand: 'Apple', model: 'iPhone 15 Pro Max' },
  { brand: 'Apple', model: 'iPhone 15 Pro' },
  { brand: 'Apple', model: 'iPhone 15' },
  { brand: 'Apple', model: 'iPhone 14 Pro Max' },
  { brand: 'Apple', model: 'iPhone 14 Pro' },
  { brand: 'Apple', model: 'iPhone 14' },
  { brand: 'Apple', model: 'iPhone 13 Pro' },
  { brand: 'Apple', model: 'iPhone 13' },
  { brand: 'Apple', model: 'iPhone 12 Pro' },
  { brand: 'Apple', model: 'iPhone 12' },
  { brand: 'Apple', model: 'iPhone 11' },
  { brand: 'Apple', model: 'iPhone SE' },
  
  // Samsung Galaxy
  { brand: 'Samsung', model: 'Galaxy S24 Ultra' },
  { brand: 'Samsung', model: 'Galaxy S23 Ultra' },
  { brand: 'Samsung', model: 'Galaxy S22 Ultra' },
  { brand: 'Samsung', model: 'Galaxy A54' },
  { brand: 'Samsung', model: 'Galaxy A34' },
  
  // Xiaomi
  { brand: 'Xiaomi', model: 'Redmi Note 13 Pro' },
  { brand: 'Xiaomi', model: 'Redmi Note 12 Pro' },
  { brand: 'Xiaomi', model: 'Poco X6 Pro' },
  
  // Motorola
  { brand: 'Motorola', model: 'Moto G84' },
  { brand: 'Motorola', model: 'Edge 40' },
];

const Solutions = () => {
  const [mainTab, setMainTab] = useState<'guides' | 'analytics' | 'history'>('guides');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBrand, setSelectedBrand] = useState<string>('');
  const [selectedModel, setSelectedModel] = useState<string>('');
  const [showPhoneSuggestions, setShowPhoneSuggestions] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState<PhoneProblem['category'] | 'all'>('all');
  const [problemSearchTerm, setProblemSearchTerm] = useState('');
  
  // iFixit states
  const [loading, setLoading] = useState(false);
  const [ifixitGuides, setIfixitGuides] = useState<IFixitGuide[]>([]);
  const [selectedGuide, setSelectedGuide] = useState<IFixitGuide | null>(null);
  const [guideModalOpen, setGuideModalOpen] = useState(false);

  // Get filtered problems
  const filteredProblems = (() => {
    let problems = categoryFilter === 'all' ? getAllProblems() : getProblemsByCategory(categoryFilter);
    
    if (problemSearchTerm) {
      const query = problemSearchTerm.toLowerCase();
      problems = problems.filter(p =>
        p.title.toLowerCase().includes(query) ||
        p.summary.toLowerCase().includes(query) ||
        p.symptoms.some(s => s.toLowerCase().includes(query)) ||
        p.detailedSymptoms.some(s => s.toLowerCase().includes(query))
      );
    }
    
    return problems;
  })();

  // Filtered phones for autocomplete
  const filteredPhones = popularPhones.filter(
    (phone) =>
      phone.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
      phone.model.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSelectPhone = (phone: typeof popularPhones[0]) => {
    setSearchTerm(`${phone.brand} ${phone.model}`);
    setSelectedBrand(phone.brand);
    setSelectedModel(phone.model);
    setShowPhoneSuggestions(false);
  };

  // Fetch iFixit guides when phone is selected
  useEffect(() => {
    const fetchGuides = async () => {
      if (!selectedBrand || !selectedModel) {
        setIfixitGuides([]);
        return;
      }

      setLoading(true);
      try {
        const guides = await getRepairGuides(selectedBrand, selectedModel);
        setIfixitGuides(guides);
      } catch (error) {
        console.error('Erro ao buscar guias:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchGuides();
  }, [selectedBrand, selectedModel]);

  const handleRefreshGuides = async () => {
    if (!selectedBrand || !selectedModel) return;
    
    const cacheKey = `${selectedBrand}-${selectedModel}`.toLowerCase();
    clearCache(cacheKey);
    
    setLoading(true);
    try {
      const guides = await getRepairGuides(selectedBrand, selectedModel, true);
      setIfixitGuides(guides);
    } catch (error) {
      console.error('Erro ao atualizar guias:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleGuideClick = (guide: IFixitGuide) => {
    setSelectedGuide(guide);
    setGuideModalOpen(true);
  };

  return (
    <>
      <Header
        title="Soluções de Problemas"
        subtitle="Base de conhecimento técnico para diagnóstico e reparo profissional"
      />
      <PageLayout>
        <Tabs value={mainTab} onValueChange={(v) => setMainTab(v as any)} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="guides">🔧 Guias de Reparo</TabsTrigger>
            <TabsTrigger value="analytics">📊 Analytics</TabsTrigger>
            <TabsTrigger value="history">📋 Histórico</TabsTrigger>
          </TabsList>

          {/* Guides Tab */}
          <TabsContent value="guides" className="space-y-6">
          {/* Quick Access Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="p-4 hover:shadow-lg transition-shadow cursor-pointer">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <Wrench className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Guias Profissionais</h3>
                  <p className="text-sm text-muted-foreground">{getAllProblems().length} problemas catalogados</p>
                </div>
              </div>
            </Card>
            
            <Card className="p-4 hover:shadow-lg transition-shadow cursor-pointer">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-green-500/10 rounded-lg">
                  <BookOpen className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold">Guias iFixit</h3>
                  <p className="text-sm text-muted-foreground">Buscar por modelo</p>
                </div>
              </div>
            </Card>
            
            <Card className="p-4 hover:shadow-lg transition-shadow cursor-pointer">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-orange-500/10 rounded-lg">
                  <Zap className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <h3 className="font-semibold">Diagnóstico Rápido</h3>
                  <p className="text-sm text-muted-foreground">Buscar por sintoma</p>
                </div>
              </div>
            </Card>
          </div>

          {/* Phone Model Search for iFixit Guides */}
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">🔍 Buscar Guias de Reparo por Modelo</h3>
            <div className="relative">
              <Input
                placeholder="Digite marca ou modelo (ex: iPhone 14, Galaxy S23)..."
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setShowPhoneSuggestions(true);
                }}
                onFocus={() => setShowPhoneSuggestions(true)}
                className="text-base"
              />
              
              {/* Autocomplete suggestions */}
              {showPhoneSuggestions && searchTerm && filteredPhones.length > 0 && (
                <Card className="absolute z-10 w-full mt-1 max-h-64 overflow-y-auto shadow-lg">
                  <div className="p-2">
                    {filteredPhones.slice(0, 10).map((phone, index) => (
                      <button
                        key={index}
                        onClick={() => handleSelectPhone(phone)}
                        className="w-full text-left px-3 py-2 rounded hover:bg-muted transition-colors"
                      >
                        <span className="font-medium">
                          {phone.brand} {phone.model}
                        </span>
                      </button>
                    ))}
                  </div>
                </Card>
              )}
            </div>
            
            {selectedBrand && selectedModel && (
              <div className="mt-3 flex items-center justify-between">
                <Badge className="text-sm bg-primary">
                  📱 {selectedBrand} {selectedModel}
                </Badge>
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleRefreshGuides}
                    disabled={loading}
                  >
                    <RefreshCw className={`w-4 h-4 mr-1 ${loading ? 'animate-spin' : ''}`} />
                    Atualizar
                  </Button>
                  <button
                    onClick={() => {
                      setSelectedBrand('');
                      setSelectedModel('');
                      setSearchTerm('');
                    }}
                    className="text-xs text-muted-foreground hover:text-foreground"
                  >
                    ✕ Limpar
                  </button>
                </div>
              </div>
            )}

            {/* iFixit Guides Display */}
            {selectedBrand && selectedModel && (
              <div className="mt-6">
                <h3 className="text-xl font-bold mb-4">
                  🔧 Guias do iFixit
                </h3>
                
                {loading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <Skeleton key={i} className="h-32 w-full" />
                    ))}
                  </div>
                ) : ifixitGuides.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {ifixitGuides.map((guide) => (
                      <GuideCard
                        key={guide.guideid}
                        guide={guide}
                        onViewDetails={handleGuideClick}
                      />
                    ))}
                  </div>
                ) : (
                  <Card className="p-6 text-center">
                    <p className="text-muted-foreground">
                      Nenhum guia profissional encontrado para este modelo no iFixit.
                    </p>
                  </Card>
                )}
              </div>
            )}
          </Card>

          {/* Professional Problems Database */}
          <Card className="p-6">
            <div className="mb-6">
              <h3 className="text-2xl font-bold mb-2">📚 Base Técnica de Problemas</h3>
              <p className="text-muted-foreground">
                Problemas catalogados com sintomas, causas, diagnóstico e soluções profissionais
              </p>
            </div>

            {/* Search Problems */}
            <div className="mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por problema, sintoma ou causa..."
                  value={problemSearchTerm}
                  onChange={(e) => setProblemSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Category Tabs */}
            <Tabs value={categoryFilter} onValueChange={(v) => setCategoryFilter(v as any)} className="w-full">
              <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8 mb-6">
                <TabsTrigger value="all">Todos</TabsTrigger>
                <TabsTrigger value="display">Display</TabsTrigger>
                <TabsTrigger value="battery">Bateria</TabsTrigger>
                <TabsTrigger value="charging">Carregamento</TabsTrigger>
                <TabsTrigger value="camera">Câmera</TabsTrigger>
                <TabsTrigger value="network">Rede</TabsTrigger>
                <TabsTrigger value="audio">Áudio</TabsTrigger>
                <TabsTrigger value="software">Software</TabsTrigger>
              </TabsList>

              <TabsContent value={categoryFilter} className="space-y-4">
                {filteredProblems.length > 0 ? (
                  filteredProblems.map((problem) => (
                  <ProblemDetailCard 
                    key={problem.id} 
                    problem={problem}
                    phoneModel={selectedModel || undefined}
                  />
                  ))
                ) : (
                  <Card className="p-8 text-center">
                    <p className="text-muted-foreground">
                      Nenhum problema encontrado com os filtros atuais.
                    </p>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics">
            <DiagnosticAnalytics />
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history">
            <DiagnosticHistoryList />
          </TabsContent>
        </Tabs>

        {/* Guide Modal */}
        <GuideModal
          guide={selectedGuide}
          open={guideModalOpen}
          onOpenChange={setGuideModalOpen}
        />
      </PageLayout>
    </>
  );
};

export default Solutions;
