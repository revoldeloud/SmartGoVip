import { Header } from '@/components/layout/Header';
import { PageLayout } from '@/components/layout/PageLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { StatCard } from '@/components/dashboard/StatCard';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

const Financial = () => {
  return (
    <>
      <Header
        title="Financeiro"
        subtitle="Controle de receitas, despesas e fluxo de caixa"
        actions={
          <>
            <Button variant="outline">📊 Relatório</Button>
            <Button>➕ Lançamento</Button>
          </>
        }
      />
      <PageLayout>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatCard label="Receitas do Mês" value="R$ 0,00" variant="success" />
          <StatCard label="Despesas do Mês" value="R$ 0,00" variant="warning" />
          <StatCard label="Saldo Atual" value="R$ 0,00" variant="info" />
          <StatCard label="A Receber" value="R$ 0,00" />
        </div>

        <Card className="p-6">
          <Tabs defaultValue="receitas">
            <TabsList className="mb-4">
              <TabsTrigger value="receitas">💰 Receitas</TabsTrigger>
              <TabsTrigger value="despesas">💸 Despesas</TabsTrigger>
              <TabsTrigger value="fluxo">📈 Fluxo de Caixa</TabsTrigger>
            </TabsList>
            
            <TabsContent value="receitas">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data</TableHead>
                      <TableHead>Descrição</TableHead>
                      <TableHead>Categoria</TableHead>
                      <TableHead>Valor</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell colSpan={5} className="text-center text-muted-foreground">
                        Nenhuma receita registrada
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="despesas">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data</TableHead>
                      <TableHead>Descrição</TableHead>
                      <TableHead>Categoria</TableHead>
                      <TableHead>Valor</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell colSpan={5} className="text-center text-muted-foreground">
                        Nenhuma despesa registrada
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="fluxo">
              <div className="flex items-center justify-center h-64 text-muted-foreground">
                Gráfico de fluxo de caixa em desenvolvimento
              </div>
            </TabsContent>
          </Tabs>
        </Card>
      </PageLayout>
    </>
  );
};

export default Financial;
