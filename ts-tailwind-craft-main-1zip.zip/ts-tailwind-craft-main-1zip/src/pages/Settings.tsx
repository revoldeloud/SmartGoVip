import { useState, useEffect } from 'react';
import { Header } from '@/components/layout/Header';
import { PageLayout } from '@/components/layout/PageLayout';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { getConfig, saveConfig, getSettings, saveSettings } from '@/utils/storage';
import { toast } from 'sonner';
import { useTheme } from 'next-themes';
import { Save } from 'lucide-react';

const Settings = () => {
  const { theme, setTheme } = useTheme();
  
  const [config, setConfig] = useState({
    companyName: '',
    cnpj: '',
    whatsapp: '',
    email: '',
    address: '',
    defaultWarranty: 90,
    pixKey: '' as string | undefined,
    pixKeyType: 'phone' as 'cpf' | 'cnpj' | 'email' | 'phone' | 'random' | undefined,
    messageTemplates: {
      serviceReport: '' as string | undefined,
      paymentRequest: '' as string | undefined,
      paymentReceipt: '' as string | undefined,
    },
  });

  const [settings, setSettings] = useState({
    darkMode: false,
    autoNumbering: true,
    deleteConfirmation: true,
    autoPrint: false,
    notifyBudgets: true,
    notifyReady: true,
    notifyLowStock: true,
    autoBackup: false,
  });

  useEffect(() => {
    const savedConfig = getConfig();
    const savedSettings = getSettings();
    setConfig({
      ...savedConfig,
      pixKey: savedConfig.pixKey || '',
      pixKeyType: savedConfig.pixKeyType || 'phone',
      messageTemplates: {
        serviceReport: savedConfig.messageTemplates?.serviceReport || '',
        paymentRequest: savedConfig.messageTemplates?.paymentRequest || '',
        paymentReceipt: savedConfig.messageTemplates?.paymentReceipt || '',
      },
    });
    setSettings(savedSettings);
    
    // Sincronizar tema com configuração salva
    if (savedSettings.darkMode) {
      setTheme('dark');
    } else {
      setTheme('light');
    }
  }, [setTheme]);

  const handleSaveConfig = () => {
    try {
      saveConfig(config);
      saveSettings(settings);
      toast.success('Configurações salvas com sucesso!');
    } catch (error) {
      toast.error('Erro ao salvar configurações');
    }
  };

  const handleDarkModeToggle = (checked: boolean) => {
    setSettings({ ...settings, darkMode: checked });
    setTheme(checked ? 'dark' : 'light');
  };

  const handleBackup = () => {
    try {
      const data = {
        config: getConfig(),
        orders: localStorage.getItem('deveresty_orders'),
        clients: localStorage.getItem('deveresty_clients'),
        stock: localStorage.getItem('deveresty_stock'),
        events: localStorage.getItem('events_data'),
      };
      
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `backup-deveresty-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
      
      toast.success('Backup criado com sucesso!');
    } catch (error) {
      toast.error('Erro ao criar backup');
    }
  };

  const handleRestore = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
          try {
            const data = JSON.parse(event.target?.result as string);
            
            if (data.config) saveConfig(data.config);
            if (data.orders) localStorage.setItem('deveresty_orders', data.orders);
            if (data.clients) localStorage.setItem('deveresty_clients', data.clients);
            if (data.stock) localStorage.setItem('deveresty_stock', data.stock);
            if (data.events) localStorage.setItem('events_data', data.events);
            
            toast.success('Backup restaurado com sucesso!');
            window.location.reload();
          } catch (error) {
            toast.error('Erro ao restaurar backup');
          }
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  return (
    <>
      <Header
        title="Configurações"
        subtitle="Personalização e configurações do sistema"
        actions={
          <Button onClick={handleSaveConfig}>💾 Salvar Alterações</Button>
        }
      />
      <PageLayout>
        <Tabs defaultValue="empresa">
          <TabsList className="mb-6">
            <TabsTrigger value="empresa">🏢 Empresa</TabsTrigger>
            <TabsTrigger value="sistema">⚙️ Sistema</TabsTrigger>
            <TabsTrigger value="mensagens">💬 Mensagens</TabsTrigger>
            <TabsTrigger value="notificacoes">🔔 Notificações</TabsTrigger>
            <TabsTrigger value="backup">💾 Backup</TabsTrigger>
          </TabsList>

          <TabsContent value="empresa">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Dados da Empresa</h3>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="company-name">Nome da Empresa</Label>
                  <Input 
                    id="company-name" 
                    value={config.companyName}
                    onChange={(e) => setConfig({ ...config, companyName: e.target.value })}
                    placeholder="Deveresty" 
                  />
                </div>
                <div>
                  <Label htmlFor="cnpj">CNPJ</Label>
                  <Input 
                    id="cnpj" 
                    value={config.cnpj}
                    onChange={(e) => setConfig({ ...config, cnpj: e.target.value })}
                    placeholder="00.000.000/0000-00" 
                  />
                </div>
                <div>
                  <Label htmlFor="phone">WhatsApp</Label>
                  <Input 
                    id="phone" 
                    value={config.whatsapp}
                    onChange={(e) => setConfig({ ...config, whatsapp: e.target.value })}
                    placeholder="(00) 00000-0000" 
                  />
                </div>
                <div>
                  <Label htmlFor="email">E-mail</Label>
                  <Input 
                    id="email" 
                    type="email" 
                    value={config.email}
                    onChange={(e) => setConfig({ ...config, email: e.target.value })}
                    placeholder="contato@empresa.com" 
                  />
                </div>
                <div>
                  <Label htmlFor="address">Endereço Completo</Label>
                  <Textarea 
                    id="address" 
                    value={config.address}
                    onChange={(e) => setConfig({ ...config, address: e.target.value })}
                    placeholder="Rua, número, bairro, cidade, estado" 
                  />
                </div>
                <div>
                  <Label htmlFor="warranty">Garantia Padrão (dias)</Label>
                  <Input 
                    id="warranty" 
                    type="number"
                    value={config.defaultWarranty}
                    onChange={(e) => setConfig({ ...config, defaultWarranty: Number(e.target.value) })}
                    placeholder="90" 
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Garantia padrão para novos orçamentos
                  </p>
                </div>

                <div className="pt-4 border-t">
                  <h4 className="font-semibold mb-3">💳 Pagamento PIX</h4>
                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="pixKeyType">Tipo de Chave PIX</Label>
                      <Select
                        value={config.pixKeyType || 'phone'}
                        onValueChange={(value: any) => setConfig({ ...config, pixKeyType: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cpf">CPF</SelectItem>
                          <SelectItem value="cnpj">CNPJ</SelectItem>
                          <SelectItem value="email">E-mail</SelectItem>
                          <SelectItem value="phone">Telefone</SelectItem>
                          <SelectItem value="random">Chave Aleatória</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="pixKey">Chave PIX</Label>
                      <Input 
                        id="pixKey" 
                        value={config.pixKey || ''}
                        onChange={(e) => setConfig({ ...config, pixKey: e.target.value })}
                        placeholder="Digite sua chave PIX" 
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        Usada para gerar QR Code de pagamento
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="sistema">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Configurações do Sistema</h3>
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Modo Escuro</Label>
                    <p className="text-sm text-muted-foreground">
                      Ativar tema escuro
                    </p>
                  </div>
                  <Switch 
                    checked={settings.darkMode}
                    onCheckedChange={handleDarkModeToggle}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Numeração Automática de OS</Label>
                    <p className="text-sm text-muted-foreground">
                      Gerar números sequenciais automaticamente
                    </p>
                  </div>
                  <Switch 
                    checked={settings.autoNumbering}
                    onCheckedChange={(checked) => setSettings({ ...settings, autoNumbering: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Confirmação de Exclusão</Label>
                    <p className="text-sm text-muted-foreground">
                      Pedir confirmação ao excluir registros
                    </p>
                  </div>
                  <Switch 
                    checked={settings.deleteConfirmation}
                    onCheckedChange={(checked) => setSettings({ ...settings, deleteConfirmation: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Impressão Automática</Label>
                    <p className="text-sm text-muted-foreground">
                      Imprimir OS automaticamente após criação
                    </p>
                  </div>
                  <Switch 
                    checked={settings.autoPrint}
                    onCheckedChange={(checked) => setSettings({ ...settings, autoPrint: checked })}
                  />
                </div>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="mensagens">
            <Card>
              <CardHeader>
                <CardTitle>Templates de Mensagens WhatsApp</CardTitle>
                <CardDescription>
                  Personalize as mensagens enviadas aos clientes. Use variáveis entre chaves para dados dinâmicos.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="serviceReport">Laudo do Serviço</Label>
                  <p className="text-xs text-muted-foreground mb-2">
                    Variáveis: {'{companyName}'}, {'{orderId}'}, {'{clientName}'}, {'{model}'}, {'{service}'}, {'{defect}'}, {'{photoCount}'}, {'{finalPrice}'}, {'{warranty}'}
                  </p>
                  <Textarea
                    id="serviceReport"
                    value={config.messageTemplates?.serviceReport || ''}
                    onChange={(e) => setConfig({ 
                      ...config, 
                      messageTemplates: { 
                        ...config.messageTemplates, 
                        serviceReport: e.target.value 
                      } 
                    })}
                    placeholder="Deixe vazio para usar template padrão..."
                    className="min-h-[200px] font-mono text-sm"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="paymentRequest">Solicitação de Pagamento</Label>
                  <p className="text-xs text-muted-foreground mb-2">
                    Variáveis: {'{companyName}'}, {'{orderId}'}, {'{clientName}'}, {'{model}'}, {'{service}'}, {'{finalPrice}'}, {'{warranty}'}, {'{pixKey}'}, {'{beneficiary}'}
                  </p>
                  <Textarea
                    id="paymentRequest"
                    value={config.messageTemplates?.paymentRequest || ''}
                    onChange={(e) => setConfig({ 
                      ...config, 
                      messageTemplates: { 
                        ...config.messageTemplates, 
                        paymentRequest: e.target.value 
                      } 
                    })}
                    placeholder="Deixe vazio para usar template padrão..."
                    className="min-h-[200px] font-mono text-sm"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="paymentReceipt">Comprovante de Pagamento</Label>
                  <p className="text-xs text-muted-foreground mb-2">
                    Variáveis: {'{companyName}'}, {'{orderId}'}, {'{clientName}'}, {'{model}'}, {'{service}'}, {'{finalPrice}'}, {'{paymentDate}'}, {'{warranty}'}
                  </p>
                  <Textarea
                    id="paymentReceipt"
                    value={config.messageTemplates?.paymentReceipt || ''}
                    onChange={(e) => setConfig({ 
                      ...config, 
                      messageTemplates: { 
                        ...config.messageTemplates, 
                        paymentReceipt: e.target.value 
                      } 
                    })}
                    placeholder="Deixe vazio para usar template padrão..."
                    className="min-h-[200px] font-mono text-sm"
                  />
                </div>

                <Button onClick={handleSaveConfig} className="w-full">
                  <Save className="mr-2 h-4 w-4" />
                  Salvar Templates
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notificacoes">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Preferências de Notificação</h3>
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Notificar Novos Orçamentos</Label>
                    <p className="text-sm text-muted-foreground">
                      Receber alerta quando um novo orçamento for criado
                    </p>
                  </div>
                  <Switch 
                    checked={settings.notifyBudgets}
                    onCheckedChange={(checked) => setSettings({ ...settings, notifyBudgets: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Notificar Serviços Prontos</Label>
                    <p className="text-sm text-muted-foreground">
                      Alerta quando um serviço for concluído
                    </p>
                  </div>
                  <Switch 
                    checked={settings.notifyReady}
                    onCheckedChange={(checked) => setSettings({ ...settings, notifyReady: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Estoque Baixo</Label>
                    <p className="text-sm text-muted-foreground">
                      Avisar quando peças atingirem estoque mínimo
                    </p>
                  </div>
                  <Switch 
                    checked={settings.notifyLowStock}
                    onCheckedChange={(checked) => setSettings({ ...settings, notifyLowStock: checked })}
                  />
                </div>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="backup">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Backup de Dados</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                  <div>
                    <p className="font-medium">Último Backup</p>
                    <p className="text-sm text-muted-foreground">Nunca realizado</p>
                  </div>
                  <Button onClick={handleBackup}>📥 Fazer Backup</Button>
                </div>
                <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                  <div>
                    <p className="font-medium">Restaurar Backup</p>
                    <p className="text-sm text-muted-foreground">
                      Importar dados de backup anterior
                    </p>
                  </div>
                  <Button variant="outline" onClick={handleRestore}>📤 Restaurar</Button>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Backup Automático</Label>
                    <p className="text-sm text-muted-foreground">
                      Realizar backup automático diariamente
                    </p>
                  </div>
                  <Switch 
                    checked={settings.autoBackup}
                    onCheckedChange={(checked) => setSettings({ ...settings, autoBackup: checked })}
                  />
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </PageLayout>
    </>
  );
};

export default Settings;
