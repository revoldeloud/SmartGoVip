import { useState } from 'react';
import { NavLink } from '@/components/NavLink';
import { useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';

interface MenuItem {
  icon: string;
  label: string;
  path: string;
  gradient?: string;
}

const menuItems: MenuItem[] = [
  { icon: '📊', label: 'Dashboard', path: '/', gradient: 'from-cyan-500/20 to-blue-500/20' },
  { icon: '➕', label: 'Novo', path: '/novo', gradient: 'from-green-500/20 to-emerald-500/20' },
  { icon: '📋', label: 'Ordens', path: '/ordens', gradient: 'from-blue-500/20 to-indigo-500/20' },
  { icon: '🧾', label: 'Orçamentos', path: '/orcamentos', gradient: 'from-purple-500/20 to-pink-500/20' },
  { icon: '👥', label: 'Clientes', path: '/clientes', gradient: 'from-orange-500/20 to-amber-500/20' },
  { icon: '📱', label: 'Celulares', path: '/celulares', gradient: 'from-pink-500/20 to-rose-500/20' },
  { icon: '📅', label: 'Agenda', path: '/agenda', gradient: 'from-teal-500/20 to-cyan-500/20' },
  { icon: '📦', label: 'Estoque', path: '/estoque', gradient: 'from-amber-500/20 to-yellow-500/20' },
  { icon: '💰', label: 'Financeiro', path: '/financeiro', gradient: 'from-emerald-500/20 to-green-500/20' },
  { icon: '📈', label: 'Relatórios', path: '/relatorios', gradient: 'from-violet-500/20 to-purple-500/20' },
  { icon: '🔧', label: 'Soluções', path: '/solucoes', gradient: 'from-red-500/20 to-orange-500/20' },
  { icon: '⚙️', label: 'Configurações', path: '/config', gradient: 'from-gray-500/20 to-slate-500/20' },
];

const mobileNavItems = menuItems.slice(0, 5);

export const Sidebar = () => {
  const location = useLocation();
  const [isExpanded, setIsExpanded] = useState(false);

  const toggleSidebar = () => setIsExpanded(!isExpanded);

  return (
    <>
      {/* Desktop Sidebar - always narrow, with toggle button */}
      <aside 
        className={cn(
          "hidden md:flex flex-col w-20 min-h-screen border-r border-white/5 print:hidden transition-all duration-300",
          isExpanded && "w-64"
        )}
        style={{
          background: 'linear-gradient(180deg, hsl(222 47% 8%) 0%, hsl(220 39% 6%) 100%)'
        }}
        onMouseEnter={() => setIsExpanded(true)}
        onMouseLeave={() => setIsExpanded(false)}
      >
        {/* Brand */}
        <div className="p-4 flex items-center gap-3 border-b border-white/10">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center text-white font-bold text-xl shadow-lg flex-shrink-0">
            S
          </div>
          <div className={cn(
            "overflow-hidden transition-all duration-300",
            isExpanded ? "opacity-100 w-auto" : "opacity-0 w-0"
          )}>
            <div className="text-xl font-bold tracking-tight gradient-text whitespace-nowrap">SmartGO</div>
            <div className="text-xs text-muted-foreground">v4.0</div>
          </div>
        </div>

        {/* Menu */}
        <nav className="flex-1 p-3 flex flex-col gap-1 overflow-y-auto scrollbar-hide">
          {menuItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                className={cn(
                  "group flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-300 relative overflow-hidden",
                  isActive 
                    ? "bg-gradient-to-r from-primary/20 to-accent/10 text-primary" 
                    : "text-white/70 hover:text-white hover:bg-white/5"
                )}
                activeClassName="!bg-gradient-to-r !from-primary/20 !to-accent/10 !text-primary"
              >
                {isActive && (
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-gradient-to-b from-cyan-400 to-purple-500 rounded-r-full" />
                )}
                <span className={cn(
                  "w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0 transition-all duration-300",
                  isActive ? "bg-primary/20 shadow-lg" : "bg-white/5 group-hover:bg-white/10"
                )}>
                  {item.icon}
                </span>
                <span className={cn(
                  "text-sm font-medium whitespace-nowrap transition-all duration-300 overflow-hidden",
                  isExpanded ? "opacity-100 w-auto" : "opacity-0 w-0"
                )}>
                  {item.label}
                </span>
              </NavLink>
            );
          })}
        </nav>

        {/* Footer */}
        <div className={cn(
          "p-4 text-center text-xs text-white/40 border-t border-white/10 transition-all duration-300 overflow-hidden",
          isExpanded ? "opacity-100" : "opacity-0"
        )}>
          <div className="flex items-center justify-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="whitespace-nowrap">Online</span>
          </div>
        </div>
      </aside>

      {/* Mobile Bottom Navigation */}
      <div className="mobile-bottom-nav safe-bottom print:hidden">
        <div className="mobile-bottom-nav-inner">
          {mobileNavItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                className={cn(
                  "mobile-nav-item",
                  isActive && "active"
                )}
                activeClassName="active"
              >
                <span className={cn(
                  "w-12 h-12 rounded-2xl flex items-center justify-center text-2xl transition-all duration-300",
                  isActive 
                    ? "bg-gradient-to-br from-cyan-500/30 to-purple-600/30 shadow-lg" 
                    : "bg-white/5"
                )}>
                  {item.icon}
                </span>
                <span className={cn(
                  "text-[10px] font-medium",
                  isActive ? "text-primary" : "text-white/60"
                )}>
                  {item.label}
                </span>
              </NavLink>
            );
          })}
        </div>
      </div>
    </>
  );
};

export const MobileHomeGrid = () => {
  const location = useLocation();

  if (location.pathname !== '/') return null;

  return (
    <div className="md:hidden">
      {/* Mobile Header */}
      <div className="text-center py-8 px-4">
        <div className="w-20 h-20 mx-auto mb-4 rounded-3xl bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center text-white font-bold text-3xl shadow-2xl neon-glow">
          S
        </div>
        <h1 className="text-3xl font-bold gradient-text mb-2">SmartGO</h1>
        <p className="text-muted-foreground text-sm">Sistema de Gestão Inteligente</p>
      </div>

      {/* Icon Grid */}
      <div className="mobile-home-grid px-4 pb-24">
        {menuItems.slice(1).map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className="mobile-home-item"
          >
            <div className={cn(
              "mobile-home-icon bg-gradient-to-br",
              item.gradient
            )}>
              {item.icon}
            </div>
            <span className="text-xs font-medium text-white/80">{item.label}</span>
          </NavLink>
        ))}
      </div>
    </div>
  );
};
