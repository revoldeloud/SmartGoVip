import { ReactNode } from 'react';

interface PageLayoutProps {
  children: ReactNode;
}

export const PageLayout = ({ children }: PageLayoutProps) => {
  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-6 bg-background scrollbar-hide">
      {children}
    </div>
  );
};
