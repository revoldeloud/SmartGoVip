interface HeaderProps {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
}

export const Header = ({ title, subtitle, actions }: HeaderProps) => {
  return (
    <header className="glass-card mx-4 mt-4 p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 print:hidden">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-foreground flex items-center gap-3">
          <span className="w-1.5 h-8 bg-gradient-to-b from-cyan-400 to-purple-500 rounded-full hidden md:block" />
          {title}
        </h1>
        {subtitle && (
          <div className="text-sm text-muted-foreground mt-1 md:ml-5">{subtitle}</div>
        )}
      </div>
      {actions && (
        <div className="flex gap-2 flex-wrap md:flex-nowrap">{actions}</div>
      )}
    </header>
  );
};
