import { useState, useEffect, useRef } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useClients } from '@/hooks/useClients';
import { Client } from '@/types';

interface ClientAutocompleteProps {
  value: string;
  onChange: (value: string, client?: Client) => void;
  onClientSelect?: (client: Client) => void;
  label?: string;
  placeholder?: string;
  required?: boolean;
}

export const ClientAutocomplete = ({
  value,
  onChange,
  onClientSelect,
  label = 'Nome do Cliente',
  placeholder = 'Digite o nome do cliente...',
  required = false,
}: ClientAutocompleteProps) => {
  const { clients } = useClients();
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [filteredClients, setFilteredClients] = useState<Client[]>([]);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (value.length > 0) {
      const filtered = clients.filter((client) =>
        client.name.toLowerCase().includes(value.toLowerCase())
      );
      setFilteredClients(filtered);
      setShowSuggestions(filtered.length > 0);
    } else {
      setFilteredClients([]);
      setShowSuggestions(false);
    }
  }, [value, clients]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectClient = (client: Client) => {
    onChange(client.name, client);
    if (onClientSelect) {
      onClientSelect(client);
    }
    setShowSuggestions(false);
  };

  return (
    <div ref={wrapperRef} className="relative">
      <Label>
        {label}
        {required && <span className="text-destructive ml-1">*</span>}
      </Label>
      <Input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => {
          if (filteredClients.length > 0) {
            setShowSuggestions(true);
          }
        }}
        placeholder={placeholder}
        required={required}
        autoComplete="off"
      />
      {showSuggestions && filteredClients.length > 0 && (
        <div className="absolute z-50 w-full mt-1 bg-background border border-border rounded-md shadow-lg max-h-60 overflow-auto">
          {filteredClients.map((client) => (
            <div
              key={client.id}
              onClick={() => handleSelectClient(client)}
              className="px-4 py-3 cursor-pointer hover:bg-accent transition-colors border-b border-border last:border-b-0"
            >
              <div className="font-semibold text-sm">{client.name}</div>
              <div className="text-xs text-muted-foreground mt-1">
                📱 {client.phone}
                {client.email && ` • ${client.email}`}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
