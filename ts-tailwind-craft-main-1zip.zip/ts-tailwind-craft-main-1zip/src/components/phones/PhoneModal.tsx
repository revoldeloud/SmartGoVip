import { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Phone } from '@/types';
import { toast } from 'sonner';
import { getAllPhoneSpecs, getPhoneSpec } from '@/data/phoneSpecs';
import { Search, Download } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface PhoneModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  phone?: Phone;
  onSave: (phone: Omit<Phone, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onUpdate?: (id: string, phone: Partial<Phone>) => void;
}

export const PhoneModal = ({ open, onOpenChange, phone, onSave, onUpdate }: PhoneModalProps) => {
  const [formData, setFormData] = useState({
    brand: '',
    model: '',
    ram: '',
    storage: '',
    frontPhoto: '',
    backPhoto: '',
  });
  
  const [searchTerm, setSearchTerm] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [allModels] = useState(getAllPhoneSpecs());
  const [loadingImage, setLoadingImage] = useState(false);
  const suggestionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (phone) {
      setFormData({
        brand: phone.brand,
        model: phone.model,
        ram: phone.ram,
        storage: phone.storage,
        frontPhoto: phone.frontPhoto || '',
        backPhoto: phone.backPhoto || '',
      });
      setSearchTerm(`${phone.brand} ${phone.model}`);
    } else {
      setFormData({
        brand: '',
        model: '',
        ram: '',
        storage: '',
        frontPhoto: '',
        backPhoto: '',
      });
      setSearchTerm('');
    }
  }, [phone, open]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (suggestionRef.current && !suggestionRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredModels = allModels.filter(model =>
    model.fullName.toLowerCase().includes(searchTerm.toLowerCase())
  ).slice(0, 8);

  const handleSearchChange = (value: string) => {
    setSearchTerm(value);
    setShowSuggestions(value.length > 0);
  };

  const handleSelectModel = async (selectedModel: { brand: string; model: string; ram: string[]; storage: string[]; imageUrl?: string; fullName: string }) => {
    // Auto-fill brand and model
    const newFormData = {
      ...formData,
      brand: selectedModel.brand,
      model: selectedModel.model,
      ram: selectedModel.ram[0] || '',
      storage: selectedModel.storage[0] || '',
    };

    // Download and convert image to base64 if available
    if (selectedModel.imageUrl) {
      setLoadingImage(true);
      try {
        const response = await fetch(selectedModel.imageUrl);
        const blob = await response.blob();
        const reader = new FileReader();
        reader.onloadend = () => {
          setFormData({
            ...newFormData,
            frontPhoto: reader.result as string
          });
          setLoadingImage(false);
        };
        reader.onerror = () => {
          toast.error('Erro ao carregar imagem');
          setFormData(newFormData);
          setLoadingImage(false);
        };
        reader.readAsDataURL(blob);
      } catch (error) {
        console.error('Error loading image:', error);
        toast.error('Erro ao carregar imagem');
        setFormData(newFormData);
        setLoadingImage(false);
      }
    } else {
      setFormData(newFormData);
    }

    setSearchTerm(selectedModel.fullName);
    setShowSuggestions(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'front' | 'back') => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error('A imagem deve ter no máximo 5MB');
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        if (type === 'front') {
          setFormData({ ...formData, frontPhoto: base64 });
        } else {
          setFormData({ ...formData, backPhoto: base64 });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.brand || !formData.model || !formData.ram || !formData.storage) {
      toast.error('Preencha todos os campos obrigatórios');
      return;
    }

    if (phone && onUpdate) {
      onUpdate(phone.id, formData);
    } else {
      onSave(formData);
    }

    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{phone ? '✏️ Editar Celular' : '📱 Novo Celular'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-4">
            <div className="relative" ref={suggestionRef}>
              <Label>Buscar Modelo *</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  value={searchTerm}
                  onChange={(e) => handleSearchChange(e.target.value)}
                  onFocus={() => searchTerm && setShowSuggestions(true)}
                  placeholder="Digite para buscar: Ex: iPhone 15, Galaxy S24..."
                  className="pl-10"
                />
              </div>
              
              {showSuggestions && filteredModels.length > 0 && (
                <div className="absolute z-[100] w-full mt-1 bg-card border border-border rounded-md shadow-xl max-h-80 overflow-auto">
                  {filteredModels.map((model, index) => (
                    <div
                      key={index}
                      className="px-4 py-3 hover:bg-accent hover:text-accent-foreground cursor-pointer transition-colors border-b border-border last:border-b-0 flex items-center gap-3"
                      onClick={() => handleSelectModel(model)}
                    >
                      {model.imageUrl && (
                        <img 
                          src={model.imageUrl} 
                          alt={model.model}
                          className="w-12 h-12 object-cover rounded"
                        />
                      )}
                      <div className="flex-1">
                        <div className="font-medium text-foreground">{model.brand} {model.model}</div>
                        <div className="text-xs text-muted-foreground">
                          RAM: {model.ram.join(', ')} • Storage: {model.storage.join(', ')}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Marca *</Label>
                <Input
                  value={formData.brand}
                  onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                  placeholder="Ex: Samsung, Apple"
                  required
                />
              </div>

              <div>
                <Label>Modelo *</Label>
                <Input
                  value={formData.model}
                  onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                  placeholder="Ex: Galaxy A52"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>RAM (GB) *</Label>
                <Input
                  value={formData.ram}
                  onChange={(e) => setFormData({ ...formData, ram: e.target.value })}
                  placeholder="Ex: 4GB, 6GB, 8GB"
                  required
                />
              </div>

              <div>
                <Label>Armazenamento *</Label>
                <Input
                  value={formData.storage}
                  onChange={(e) => setFormData({ ...formData, storage: e.target.value })}
                  placeholder="Ex: 64GB, 128GB, 256GB"
                  required
                />
              </div>
            </div>

            {loadingImage && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Download className="h-4 w-4 animate-pulse" />
                <span>Carregando imagem do celular...</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Foto Frontal</Label>
              <Input
                type="file"
                accept="image/*"
                onChange={(e) => handleImageUpload(e, 'front')}
                className="cursor-pointer"
              />
              {formData.frontPhoto && (
                <div className="mt-2 relative">
                  <img
                    src={formData.frontPhoto}
                    alt="Frente"
                    className="w-full h-32 object-cover rounded border"
                  />
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    className="absolute top-1 right-1"
                    onClick={() => setFormData({ ...formData, frontPhoto: '' })}
                  >
                    ❌
                  </Button>
                </div>
              )}
            </div>

            <div>
              <Label>Foto Traseira</Label>
              <Input
                type="file"
                accept="image/*"
                onChange={(e) => handleImageUpload(e, 'back')}
                className="cursor-pointer"
              />
              {formData.backPhoto && (
                <div className="mt-2 relative">
                  <img
                    src={formData.backPhoto}
                    alt="Traseira"
                    className="w-full h-32 object-cover rounded border"
                  />
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    className="absolute top-1 right-1"
                    onClick={() => setFormData({ ...formData, backPhoto: '' })}
                  >
                    ❌
                  </Button>
                </div>
              )}
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit">
              {phone ? '💾 Atualizar' : '➕ Adicionar'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
