import { useMemo } from 'react';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useStock } from '@/hooks/useStock';
import { CheckCircle2, XCircle, AlertTriangle, Package } from 'lucide-react';

interface PartsCheckerProps {
  requiredParts: string[];
}

interface PartAvailability {
  partName: string;
  status: 'available' | 'low_stock' | 'unavailable' | 'not_found';
  quantity?: number;
  minQuantity?: number;
  stockItem?: any;
}

export const PartsChecker = ({ requiredParts }: PartsCheckerProps) => {
  const { stock } = useStock();

  const partsAvailability = useMemo<PartAvailability[]>(() => {
    return requiredParts.map(partName => {
      // Busca fuzzy por nome similar no estoque
      const matchingItem = stock.find(item => {
        const itemNameLower = item.name.toLowerCase();
        const partNameLower = partName.toLowerCase();
        
        // Busca exata ou parcial
        return itemNameLower.includes(partNameLower) || 
               partNameLower.includes(itemNameLower) ||
               // Busca por palavras-chave comuns
               (partNameLower.includes('display') && itemNameLower.includes('tela')) ||
               (partNameLower.includes('tela') && itemNameLower.includes('display')) ||
               (partNameLower.includes('bateria') && itemNameLower.includes('battery')) ||
               (partNameLower.includes('battery') && itemNameLower.includes('bateria'));
      });

      if (!matchingItem) {
        return {
          partName,
          status: 'not_found' as const
        };
      }

      if (matchingItem.quantity === 0) {
        return {
          partName,
          status: 'unavailable' as const,
          quantity: 0,
          minQuantity: matchingItem.minQuantity,
          stockItem: matchingItem
        };
      }

      if (matchingItem.quantity <= matchingItem.minQuantity) {
        return {
          partName,
          status: 'low_stock' as const,
          quantity: matchingItem.quantity,
          minQuantity: matchingItem.minQuantity,
          stockItem: matchingItem
        };
      }

      return {
        partName,
        status: 'available' as const,
        quantity: matchingItem.quantity,
        minQuantity: matchingItem.minQuantity,
        stockItem: matchingItem
      };
    });
  }, [requiredParts, stock]);

  const availableCount = partsAvailability.filter(p => p.status === 'available').length;
  const lowStockCount = partsAvailability.filter(p => p.status === 'low_stock').length;
  const unavailableCount = partsAvailability.filter(p => p.status === 'unavailable').length;
  const notFoundCount = partsAvailability.filter(p => p.status === 'not_found').length;

  const getStatusIcon = (status: PartAvailability['status']) => {
    switch (status) {
      case 'available':
        return <CheckCircle2 className="w-4 h-4 text-green-600 dark:text-green-400" />;
      case 'low_stock':
        return <AlertTriangle className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />;
      case 'unavailable':
        return <XCircle className="w-4 h-4 text-red-600 dark:text-red-400" />;
      case 'not_found':
        return <Package className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: PartAvailability['status'], quantity?: number) => {
    switch (status) {
      case 'available':
        return (
          <Badge className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300">
            ✓ Em estoque ({quantity})
          </Badge>
        );
      case 'low_stock':
        return (
          <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300">
            ⚠ Estoque baixo ({quantity})
          </Badge>
        );
      case 'unavailable':
        return (
          <Badge className="bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300">
            ✗ Indisponível
          </Badge>
        );
      case 'not_found':
        return (
          <Badge variant="outline" className="text-muted-foreground">
            ? Não cadastrado
          </Badge>
        );
    }
  };

  const getSummaryAlert = () => {
    if (unavailableCount > 0) {
      return (
        <Alert className="bg-red-50 dark:bg-red-900/10 border-red-200 dark:border-red-800">
          <XCircle className="h-4 w-4 text-red-600 dark:text-red-400" />
          <AlertDescription className="text-red-800 dark:text-red-300">
            <strong>{unavailableCount} peça(s) indisponível(is)</strong> no estoque. 
            É necessário solicitar/comprar peças antes do reparo.
          </AlertDescription>
        </Alert>
      );
    }

    if (lowStockCount > 0) {
      return (
        <Alert className="bg-yellow-50 dark:bg-yellow-900/10 border-yellow-200 dark:border-yellow-800">
          <AlertTriangle className="h-4 w-4 text-yellow-600 dark:text-yellow-400" />
          <AlertDescription className="text-yellow-800 dark:text-yellow-300">
            <strong>{lowStockCount} peça(s) com estoque baixo</strong>. 
            Considere fazer novo pedido em breve.
          </AlertDescription>
        </Alert>
      );
    }

    if (availableCount === requiredParts.length) {
      return (
        <Alert className="bg-green-50 dark:bg-green-900/10 border-green-200 dark:border-green-800">
          <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
          <AlertDescription className="text-green-800 dark:text-green-300">
            <strong>Todas as peças disponíveis!</strong> Reparo pode ser iniciado imediatamente.
          </AlertDescription>
        </Alert>
      );
    }

    return null;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h4 className="font-semibold flex items-center gap-2">
          <Package className="w-4 h-4" />
          Verificação de Estoque
        </h4>
        <div className="flex gap-2 text-xs">
          {availableCount > 0 && (
            <span className="text-green-600 dark:text-green-400">✓ {availableCount}</span>
          )}
          {lowStockCount > 0 && (
            <span className="text-yellow-600 dark:text-yellow-400">⚠ {lowStockCount}</span>
          )}
          {unavailableCount > 0 && (
            <span className="text-red-600 dark:text-red-400">✗ {unavailableCount}</span>
          )}
          {notFoundCount > 0 && (
            <span className="text-gray-400">? {notFoundCount}</span>
          )}
        </div>
      </div>

      {getSummaryAlert()}

      <div className="space-y-2">
        {partsAvailability.map((part, idx) => (
          <div 
            key={idx}
            className="flex items-center justify-between p-3 bg-muted/30 rounded-lg border border-border/50"
          >
            <div className="flex items-center gap-3 flex-1">
              {getStatusIcon(part.status)}
              <span className="text-sm font-medium">{part.partName}</span>
            </div>
            {getStatusBadge(part.status, part.quantity)}
          </div>
        ))}
      </div>
    </div>
  );
};
