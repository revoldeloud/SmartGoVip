import { useState } from 'react';
import { useDiagnosticHistory, DiagnosticRecord } from '@/hooks/useDiagnosticHistory';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import {
  CheckCircle2,
  XCircle,
  Eye,
  Trash2,
  Search,
  Calendar,
  Smartphone
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export const DiagnosticHistoryList = () => {
  const { history, updateRecord, deleteRecord } = useDiagnosticHistory();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRecord, setSelectedRecord] = useState<DiagnosticRecord | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);

  const filteredHistory = history.filter(record =>
    record.problemTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
    record.phoneModel?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    record.diagnosisResult.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleViewDetails = (record: DiagnosticRecord) => {
    setSelectedRecord(record);
    setDetailsOpen(true);
  };

  const handleToggleResolved = (record: DiagnosticRecord) => {
    updateRecord(record.id, { 
      resolved: !record.resolved,
      resolutionTime: !record.resolved 
        ? Math.round((new Date().getTime() - new Date(record.date).getTime()) / (1000 * 60 * 60)) 
        : record.resolutionTime
    });
    toast.success(
      record.resolved 
        ? 'Marcado como não resolvido' 
        : 'Marcado como resolvido!'
    );
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Deseja realmente excluir este registro?')) {
      deleteRecord(id);
      toast.success('Registro excluído');
    }
  };

  const handleUpdateNotes = () => {
    if (selectedRecord) {
      updateRecord(selectedRecord.id, { 
        technicianNotes: selectedRecord.technicianNotes 
      });
      toast.success('Notas atualizadas');
      setDetailsOpen(false);
    }
  };

  const categoryLabels: Record<string, string> = {
    display: 'Display',
    battery: 'Bateria',
    network: 'Rede',
    camera: 'Câmera',
    software: 'Software',
    charging: 'Carregamento',
    audio: 'Áudio',
    motherboard: 'Placa',
    sensors: 'Sensores',
    hardware: 'Hardware'
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Buscar diagnósticos..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Data</TableHead>
              <TableHead>Problema</TableHead>
              <TableHead>Categoria</TableHead>
              <TableHead>Modelo</TableHead>
              <TableHead>Confiança</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredHistory.length > 0 ? (
              filteredHistory.map((record) => (
                <TableRow key={record.id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">
                        {format(new Date(record.date), 'dd/MM/yy HH:mm', { locale: ptBR })}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <p className="font-medium text-sm">{record.problemTitle}</p>
                      <p className="text-xs text-muted-foreground">{record.diagnosisResult}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">
                      {categoryLabels[record.category] || record.category}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {record.phoneModel ? (
                      <div className="flex items-center gap-2">
                        <Smartphone className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm">{record.phoneModel}</span>
                      </div>
                    ) : (
                      <span className="text-sm text-muted-foreground">-</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant="secondary"
                      className={
                        record.confidence >= 90 
                          ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300'
                          : record.confidence >= 75
                          ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300'
                          : 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300'
                      }
                    >
                      {record.confidence}%
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleToggleResolved(record)}
                      className="gap-2"
                    >
                      {record.resolved ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span className="text-green-600">Resolvido</span>
                        </>
                      ) : (
                        <>
                          <XCircle className="w-4 h-4 text-orange-600" />
                          <span className="text-orange-600">Pendente</span>
                        </>
                      )}
                    </Button>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewDetails(record)}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(record.id)}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                  {searchTerm ? 'Nenhum resultado encontrado' : 'Nenhum diagnóstico registrado'}
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Card>

      {/* Details Dialog */}
      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Detalhes do Diagnóstico</DialogTitle>
            <DialogDescription>
              Informações completas e notas técnicas
            </DialogDescription>
          </DialogHeader>

          {selectedRecord && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground">Data</Label>
                  <p className="font-medium">
                    {format(new Date(selectedRecord.date), "dd 'de' MMMM 'às' HH:mm", { locale: ptBR })}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Status</Label>
                  <p className="font-medium">
                    {selectedRecord.resolved ? (
                      <span className="text-green-600">✓ Resolvido</span>
                    ) : (
                      <span className="text-orange-600">⏳ Pendente</span>
                    )}
                  </p>
                </div>
              </div>

              <Separator />

              <div>
                <Label className="text-muted-foreground">Problema Identificado</Label>
                <p className="font-semibold text-lg">{selectedRecord.problemTitle}</p>
              </div>

              <div>
                <Label className="text-muted-foreground">Diagnóstico</Label>
                <p className="font-medium">{selectedRecord.diagnosisResult}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground">Categoria</Label>
                  <Badge variant="outline">
                    {categoryLabels[selectedRecord.category]}
                  </Badge>
                </div>
                <div>
                  <Label className="text-muted-foreground">Confiança</Label>
                  <Badge>{selectedRecord.confidence}%</Badge>
                </div>
              </div>

              {selectedRecord.phoneModel && (
                <div>
                  <Label className="text-muted-foreground">Modelo do Aparelho</Label>
                  <p className="font-medium">{selectedRecord.phoneModel}</p>
                </div>
              )}

              {selectedRecord.resolutionTime && (
                <div>
                  <Label className="text-muted-foreground">Tempo de Resolução</Label>
                  <p className="font-medium">{selectedRecord.resolutionTime}h</p>
                </div>
              )}

              <Separator />

              <div>
                <Label htmlFor="notes">Notas do Técnico</Label>
                <Textarea
                  id="notes"
                  value={selectedRecord.technicianNotes || ''}
                  onChange={(e) => setSelectedRecord({
                    ...selectedRecord,
                    technicianNotes: e.target.value
                  })}
                  placeholder="Adicione observações sobre o diagnóstico e reparo..."
                  rows={4}
                  className="mt-2"
                />
              </div>

              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={() => setDetailsOpen(false)}>
                  Fechar
                </Button>
                <Button onClick={handleUpdateNotes}>
                  Salvar Notas
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};
