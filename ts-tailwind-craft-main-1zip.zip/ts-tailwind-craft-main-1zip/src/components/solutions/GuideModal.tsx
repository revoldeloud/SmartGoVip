import { IFixitGuide } from '@/types/ifixit';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Clock, Wrench, Package, ExternalLink } from 'lucide-react';

interface GuideModalProps {
  guide: IFixitGuide | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const getDifficultyColor = (difficulty: string): string => {
  switch (difficulty.toLowerCase()) {
    case 'very easy':
    case 'easy':
      return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300';
    case 'moderate':
      return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300';
    case 'difficult':
      return 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300';
    case 'very difficult':
      return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300';
    default:
      return 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300';
  }
};

export const GuideModal = ({ guide, open, onOpenChange }: GuideModalProps) => {
  if (!guide) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="text-xl">{guide.title}</DialogTitle>
        </DialogHeader>
        
        <ScrollArea className="max-h-[calc(90vh-120px)]">
          <div className="space-y-6">
            {/* Header info */}
            <div className="flex flex-wrap gap-3">
              <Badge className={getDifficultyColor(guide.difficulty)}>
                {guide.difficulty}
              </Badge>
              <div className="flex items-center gap-1 text-sm">
                <Clock className="w-4 h-4" />
                {guide.time_required || `${guide.time_required_min}-${guide.time_required_max} min`}
              </div>
            </div>

            {/* Image */}
            {guide.image?.large && (
              <div className="rounded-lg overflow-hidden">
                <img
                  src={guide.image.large}
                  alt={guide.title}
                  className="w-full"
                />
              </div>
            )}

            {/* Introduction */}
            {guide.introduction_rendered && (
              <div>
                <h3 className="font-semibold mb-2">Introdução</h3>
                <div 
                  className="text-sm text-muted-foreground"
                  dangerouslySetInnerHTML={{ __html: guide.introduction_rendered }}
                />
              </div>
            )}

            {/* Tools */}
            {guide.tools && guide.tools.length > 0 && (
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Wrench className="w-4 h-4" />
                  <h3 className="font-semibold">Ferramentas Necessárias</h3>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {guide.tools.map((tool, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-2 p-2 rounded-lg bg-muted text-sm"
                    >
                      {tool.thumbnail && (
                        <img
                          src={tool.thumbnail}
                          alt={tool.name}
                          className="w-8 h-8 object-contain"
                        />
                      )}
                      <span className="flex-1">{tool.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Parts */}
            {guide.parts && guide.parts.length > 0 && (
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Package className="w-4 h-4" />
                  <h3 className="font-semibold">Peças Necessárias</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {guide.parts.map((part, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-2 p-2 rounded-lg bg-muted text-sm"
                    >
                      {part.thumbnail && (
                        <img
                          src={part.thumbnail}
                          alt={part.name}
                          className="w-8 h-8 object-contain"
                        />
                      )}
                      <span className="flex-1">{part.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <Separator />

            {/* Steps */}
            {guide.steps && guide.steps.length > 0 && (
              <div>
                <h3 className="font-semibold mb-4">Passos do Reparo</h3>
                <div className="space-y-6">
                  {guide.steps.map((step, index) => (
                    <div key={step.stepid} className="space-y-3">
                      <div className="flex items-start gap-3">
                        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                          {index + 1}
                        </div>
                        <div className="flex-1">
                          {step.title && (
                            <h4 className="font-medium mb-2">{step.title}</h4>
                          )}
                          
                          {step.media?.data && step.media.data.length > 0 && (
                            <div className="grid grid-cols-2 gap-2 mb-3">
                              {step.media.data.slice(0, 2).map((image, imgIndex) => (
                                <img
                                  key={imgIndex}
                                  src={image.medium || image.standard}
                                  alt={`Passo ${index + 1} - Imagem ${imgIndex + 1}`}
                                  className="rounded-lg w-full"
                                />
                              ))}
                            </div>
                          )}
                          
                          {step.lines && step.lines.length > 0 && (
                            <div className="space-y-2">
                              {step.lines.map((line, lineIndex) => (
                                <div
                                  key={lineIndex}
                                  className="text-sm text-muted-foreground"
                                  dangerouslySetInnerHTML={{ __html: line.text_rendered }}
                                />
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                      
                      {index < guide.steps.length - 1 && (
                        <Separator className="my-4" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Link to full guide */}
            <div className="pt-4">
              <Button asChild variant="outline" className="w-full">
                <a
                  href={guide.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2"
                >
                  <ExternalLink className="w-4 h-4" />
                  Ver guia completo no iFixit
                </a>
              </Button>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};
