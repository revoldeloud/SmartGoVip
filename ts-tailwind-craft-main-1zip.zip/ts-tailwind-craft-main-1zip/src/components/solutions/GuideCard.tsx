import { IFixitGuide } from '@/types/ifixit';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Clock, Wrench, ExternalLink } from 'lucide-react';

interface GuideCardProps {
  guide: IFixitGuide;
  onViewDetails: (guide: IFixitGuide) => void;
}

const getDifficultyColor = (difficulty: string): string => {
  switch (difficulty.toLowerCase()) {
    case 'very easy':
      return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300';
    case 'easy':
      return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300';
    case 'moderate':
      return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300';
    case 'difficult':
      return 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300';
    case 'very difficult':
      return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300';
    default:
      return 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300';
  }
};

export const GuideCard = ({ guide, onViewDetails }: GuideCardProps) => {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <div className="aspect-video relative overflow-hidden bg-muted">
        {guide.image?.standard ? (
          <img
            src={guide.image.standard}
            alt={guide.title}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Wrench className="w-12 h-12 text-muted-foreground" />
          </div>
        )}
      </div>
      
      <CardHeader>
        <div className="flex items-start justify-between gap-2 mb-2">
          <Badge className={getDifficultyColor(guide.difficulty)}>
            {guide.difficulty}
          </Badge>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Clock className="w-3 h-3" />
            {guide.time_required || `${guide.time_required_min}-${guide.time_required_max} min`}
          </div>
        </div>
        <CardTitle className="text-lg leading-tight">{guide.title}</CardTitle>
      </CardHeader>
      
      <CardContent>
        {guide.summary && (
          <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
            {guide.summary}
          </p>
        )}
        
        {guide.tools && guide.tools.length > 0 && (
          <div className="flex items-center gap-2 text-xs text-muted-foreground mb-4">
            <Wrench className="w-3 h-3" />
            <span>{guide.tools.length} ferramentas necessárias</span>
          </div>
        )}
        
        <div className="flex gap-2">
          <Button
            variant="default"
            size="sm"
            className="flex-1"
            onClick={() => onViewDetails(guide)}
          >
            Ver guia completo
          </Button>
          <Button
            variant="outline"
            size="sm"
            asChild
          >
            <a
              href={guide.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1"
            >
              <ExternalLink className="w-3 h-3" />
            </a>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
