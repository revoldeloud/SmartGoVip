import { useState } from 'react';
import { useDiagnosticHistory } from '@/hooks/useDiagnosticHistory';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Card } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import {
  CheckCircle2,
  XCircle,
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  RotateCcw,
  Sparkles
} from 'lucide-react';

interface DiagnosticQuestion {
  id: string;
  question: string;
  answers: {
    text: string;
    nextQuestionId?: string;
    diagnosisId?: string;
  }[];
}

interface Diagnosis {
  id: string;
  problem: string;
  confidence: number;
  recommendedTests: string[];
  nextSteps: string[];
}

interface DiagnosticWizardProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  category: string;
  problemId?: string;
  problemTitle?: string;
  phoneModel?: string;
}

// Árvore de decisão de diagnóstico
const diagnosticTree: Record<string, DiagnosticQuestion[]> = {
  display: [
    {
      id: 'display_1',
      question: 'A tela liga mas apresenta alguma imagem?',
      answers: [
        { text: 'Sim, mostra imagem', nextQuestionId: 'display_2' },
        { text: 'Não, tela totalmente preta', nextQuestionId: 'display_3' },
        { text: 'Tela branca ou com cores estranhas', diagnosisId: 'display_lcd' }
      ]
    },
    {
      id: 'display_2',
      question: 'Qual é o problema visual?',
      answers: [
        { text: 'Manchas ou linhas na tela', diagnosisId: 'display_lcd' },
        { text: 'Toque não funciona', diagnosisId: 'display_touch' },
        { text: 'Brilho fraco ou escurecimento', diagnosisId: 'display_backlight' }
      ]
    },
    {
      id: 'display_3',
      question: 'O aparelho vibra ou emite sons quando ligado?',
      answers: [
        { text: 'Sim, funciona normalmente', diagnosisId: 'display_lcd' },
        { text: 'Não responde', diagnosisId: 'display_power' }
      ]
    }
  ],
  battery: [
    {
      id: 'battery_1',
      question: 'O aparelho carrega normalmente?',
      answers: [
        { text: 'Sim, mas descarrega rápido', nextQuestionId: 'battery_2' },
        { text: 'Não carrega', nextQuestionId: 'battery_3' },
        { text: 'Carrega e descarrega muito rápido', diagnosisId: 'battery_degraded' }
      ]
    },
    {
      id: 'battery_2',
      question: 'O problema começou recentemente?',
      answers: [
        { text: 'Sim, nas últimas semanas', diagnosisId: 'battery_degraded' },
        { text: 'Não, é gradual há meses', diagnosisId: 'battery_old' }
      ]
    },
    {
      id: 'battery_3',
      question: 'O cabo/adaptador está funcionando?',
      answers: [
        { text: 'Sim, testei em outro aparelho', diagnosisId: 'battery_connector' },
        { text: 'Não sei', diagnosisId: 'battery_cable' }
      ]
    }
  ],
  network: [
    {
      id: 'network_1',
      question: 'Qual o tipo de problema de sinal?',
      answers: [
        { text: 'Sem sinal/sem serviço', diagnosisId: 'network_no_signal' },
        { text: 'WiFi não conecta', diagnosisId: 'network_wifi' },
        { text: 'Bluetooth não funciona', diagnosisId: 'network_bluetooth' }
      ]
    }
  ]
};

const diagnoses: Record<string, Diagnosis> = {
  display_lcd: {
    id: 'display_lcd',
    problem: 'LCD/Display Danificado',
    confidence: 95,
    recommendedTests: [
      'Verificar se há danos físicos visíveis no display',
      'Testar resposta ao toque em diferentes áreas',
      'Inspecionar conexão do flat cable do display'
    ],
    nextSteps: [
      'Substituir o display completo',
      'Verificar se a placa mãe está enviando sinal correto',
      'Testar o novo display antes de fechar o aparelho'
    ]
  },
  display_touch: {
    id: 'display_touch',
    problem: 'Touch Screen Defeituoso',
    confidence: 90,
    recommendedTests: [
      'Fazer teste de toque em todas as áreas da tela',
      'Verificar calibração do touch',
      'Inspecionar conexão do digitalizador'
    ],
    nextSteps: [
      'Substituir o digitalizador (touch)',
      'Se for display completo, trocar a unidade inteira',
      'Recalibrar após instalação'
    ]
  },
  display_backlight: {
    id: 'display_backlight',
    problem: 'Problema no Backlight/Iluminação',
    confidence: 85,
    recommendedTests: [
      'Testar em ambiente escuro para ver se aparece imagem fraca',
      'Verificar configurações de brilho',
      'Testar com lanterna na tela para ver se há imagem'
    ],
    nextSteps: [
      'Verificar circuito de backlight na placa',
      'Substituir display se backlight for integrado',
      'Checar se é problema de software ou hardware'
    ]
  },
  display_power: {
    id: 'display_power',
    problem: 'Problema de Alimentação ou Placa',
    confidence: 70,
    recommendedTests: [
      'Medir tensão de alimentação da placa',
      'Verificar se a bateria está boa',
      'Testar botão de power'
    ],
    nextSteps: [
      'Fazer diagnóstico completo da placa mãe',
      'Verificar componentes de alimentação',
      'Possível micro solda necessária'
    ]
  },
  battery_degraded: {
    id: 'battery_degraded',
    problem: 'Bateria Degradada',
    confidence: 95,
    recommendedTests: [
      'Verificar ciclos de carga (se possível)',
      'Medir voltagem da bateria',
      'Observar se a bateria está inchada'
    ],
    nextSteps: [
      'Substituir a bateria',
      'Verificar se há danos causados por bateria inchada',
      'Recalibrar sistema após troca'
    ]
  },
  battery_old: {
    id: 'battery_old',
    problem: 'Bateria no Fim da Vida Útil',
    confidence: 90,
    recommendedTests: [
      'Verificar idade da bateria',
      'Medir capacidade real vs nominal',
      'Testar tempo de uso real'
    ],
    nextSteps: [
      'Substituir a bateria',
      'Orientar cliente sobre cuidados com nova bateria'
    ]
  },
  battery_connector: {
    id: 'battery_connector',
    problem: 'Conector de Carga Danificado',
    confidence: 85,
    recommendedTests: [
      'Inspecionar visualmente o conector',
      'Limpar conector com álcool isopropílico',
      'Testar com diferentes cabos e orientações'
    ],
    nextSteps: [
      'Substituir o conector de carga',
      'Limpar área ao redor do conector',
      'Testar múltiplas vezes após reparo'
    ]
  },
  battery_cable: {
    id: 'battery_cable',
    problem: 'Problema no Cabo/Adaptador',
    confidence: 60,
    recommendedTests: [
      'Testar com cabo e adaptador originais',
      'Verificar saída do adaptador com multímetro',
      'Testar carregamento wireless se disponível'
    ],
    nextSteps: [
      'Substituir cabo e adaptador',
      'Se não resolver, verificar conector de carga',
      'Testar bateria se problema persistir'
    ]
  },
  network_no_signal: {
    id: 'network_no_signal',
    problem: 'Problema no Módulo de Rede/Antena',
    confidence: 80,
    recommendedTests: [
      'Testar com outro chip',
      'Verificar configurações de rede',
      'Resetar configurações de rede'
    ],
    nextSteps: [
      'Verificar antenas internas',
      'Testar módulo de rede na placa',
      'Possível problema em CI de RF'
    ]
  },
  network_wifi: {
    id: 'network_wifi',
    problem: 'Problema no Módulo WiFi',
    confidence: 85,
    recommendedTests: [
      'Resetar configurações de WiFi',
      'Testar em diferentes redes',
      'Verificar se detecta redes'
    ],
    nextSteps: [
      'Verificar chip WiFi na placa',
      'Testar antenas WiFi',
      'Possível necessidade de reballing ou troca de CI'
    ]
  },
  network_bluetooth: {
    id: 'network_bluetooth',
    problem: 'Problema no Módulo Bluetooth',
    confidence: 80,
    recommendedTests: [
      'Resetar pareamentos Bluetooth',
      'Testar modo avião',
      'Verificar se outros dispositivos detectam o aparelho'
    ],
    nextSteps: [
      'Verificar chip Bluetooth (geralmente integrado ao WiFi)',
      'Testar antenas',
      'Possível problema no firmware'
    ]
  }
};

export const DiagnosticWizard = ({ open, onOpenChange, category, problemId, problemTitle, phoneModel }: DiagnosticWizardProps) => {
  const [currentQuestionId, setCurrentQuestionId] = useState<string>('');
  const [history, setHistory] = useState<string[]>([]);
  const [diagnosis, setDiagnosis] = useState<Diagnosis | null>(null);
  const { addRecord } = useDiagnosticHistory();

  const questions = diagnosticTree[category] || [];
  const currentQuestion = questions.find(q => q.id === currentQuestionId);

  const progress = diagnosis ? 100 : (history.length / (questions.length + 1)) * 100;

  const handleStart = () => {
    if (questions.length > 0) {
      setCurrentQuestionId(questions[0].id);
      setHistory([]);
      setDiagnosis(null);
    }
  };

  const handleAnswer = (answer: DiagnosticQuestion['answers'][0]) => {
    setHistory([...history, currentQuestionId]);

    if (answer.diagnosisId) {
      const diagnosisResult = diagnoses[answer.diagnosisId];
      setDiagnosis(diagnosisResult);
      
      // Salvar no histórico
      addRecord({
        problemId: problemId || answer.diagnosisId,
        problemTitle: problemTitle || diagnosisResult.problem,
        category: category,
        phoneModel: phoneModel,
        diagnosisResult: diagnosisResult.problem,
        confidence: diagnosisResult.confidence,
        resolved: false,
      });
      
      toast.success('Diagnóstico salvo no histórico');
    } else if (answer.nextQuestionId) {
      setCurrentQuestionId(answer.nextQuestionId);
    }
  };

  const handleBack = () => {
    if (history.length > 0) {
      const previousId = history[history.length - 1];
      setHistory(history.slice(0, -1));
      setCurrentQuestionId(previousId);
      setDiagnosis(null);
    }
  };

  const handleReset = () => {
    setCurrentQuestionId('');
    setHistory([]);
    setDiagnosis(null);
  };

  const handleClose = () => {
    handleReset();
    onOpenChange(false);
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 90) return 'text-green-600 dark:text-green-400';
    if (confidence >= 75) return 'text-yellow-600 dark:text-yellow-400';
    return 'text-orange-600 dark:text-orange-400';
  };

  const getConfidenceIcon = (confidence: number) => {
    if (confidence >= 90) return CheckCircle2;
    if (confidence >= 75) return AlertCircle;
    return XCircle;
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            Assistente de Diagnóstico
          </DialogTitle>
          <DialogDescription>
            Siga as perguntas para identificar o problema com precisão
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Progresso</span>
              <span className="font-medium">{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          <Separator />

          {/* Initial State */}
          {!currentQuestionId && !diagnosis && (
            <div className="text-center py-8 space-y-4">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                <Sparkles className="w-8 h-8 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-2">
                  Diagnóstico Inteligente
                </h3>
                <p className="text-muted-foreground mb-4">
                  Vou fazer algumas perguntas para identificar o problema com precisão
                </p>
              </div>
              <Button onClick={handleStart} size="lg">
                <ArrowRight className="w-4 h-4 mr-2" />
                Iniciar Diagnóstico
              </Button>
            </div>
          )}

          {/* Question State */}
          {currentQuestion && !diagnosis && (
            <div className="space-y-6">
              <Card className="p-6 bg-primary/5 border-primary/20">
                <h3 className="font-semibold text-lg mb-4">
                  {currentQuestion.question}
                </h3>
                <div className="grid gap-3">
                  {currentQuestion.answers.map((answer, idx) => (
                    <Button
                      key={idx}
                      variant="outline"
                      className="justify-start h-auto py-4 text-left"
                      onClick={() => handleAnswer(answer)}
                    >
                      <ArrowRight className="w-4 h-4 mr-2 flex-shrink-0" />
                      <span>{answer.text}</span>
                    </Button>
                  ))}
                </div>
              </Card>

              {history.length > 0 && (
                <Button variant="ghost" onClick={handleBack}>
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Voltar
                </Button>
              )}
            </div>
          )}

          {/* Diagnosis Result */}
          {diagnosis && (
            <div className="space-y-6">
              <Card className="p-6 border-2 border-primary/50 bg-primary/5">
                <div className="flex items-start gap-4 mb-4">
                  {(() => {
                    const Icon = getConfidenceIcon(diagnosis.confidence);
                    return <Icon className={`w-8 h-8 flex-shrink-0 ${getConfidenceColor(diagnosis.confidence)}`} />;
                  })()}
                  <div className="flex-1">
                    <h3 className="font-bold text-xl mb-2">
                      Diagnóstico Identificado
                    </h3>
                    <p className="text-lg font-semibold text-primary mb-3">
                      {diagnosis.problem}
                    </p>
                    <Badge className={`${getConfidenceColor(diagnosis.confidence)} bg-background`}>
                      Confiança: {diagnosis.confidence}%
                    </Badge>
                  </div>
                </div>

                <Separator className="my-4" />

                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-primary" />
                      Testes Recomendados
                    </h4>
                    <ul className="space-y-2">
                      {diagnosis.recommendedTests.map((test, idx) => (
                        <li key={idx} className="text-sm flex items-start gap-2">
                          <span className="text-muted-foreground mt-1">•</span>
                          <span>{test}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <Separator />

                  <div>
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <ArrowRight className="w-4 h-4 text-primary" />
                      Próximos Passos
                    </h4>
                    <ol className="space-y-2">
                      {diagnosis.nextSteps.map((step, idx) => (
                        <li key={idx} className="text-sm flex items-start gap-2">
                          <span className="font-medium text-primary">{idx + 1}.</span>
                          <span>{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                </div>
              </Card>

              <div className="flex gap-2">
                <Button variant="outline" onClick={handleReset} className="flex-1">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Fazer Novo Diagnóstico
                </Button>
                <Button onClick={handleClose} className="flex-1">
                  Concluir
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
