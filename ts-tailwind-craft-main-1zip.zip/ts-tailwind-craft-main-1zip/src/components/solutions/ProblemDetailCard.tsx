import { useState } from 'react';
import { PhoneProblem } from '@/types';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { PartsChecker } from './PartsChecker';
import { DiagnosticWizard } from './DiagnosticWizard';
import { useBudgetCreation } from '@/hooks/useBudgetCreation';
import { useStock } from '@/hooks/useStock';
import {
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  Clock,
  DollarSign,
  Wrench,
  PackageSearch,
  Activity,
  TrendingUp,
  AlertCircle,
  Zap,
  FileText,
  Sparkles
} from 'lucide-react';

interface ProblemDetailCardProps {
  problem: PhoneProblem;
  phoneModel?: string;
}

const severityConfig = {
  low: { color: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300', label: 'Baixa' },
  medium: { color: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300', label: 'Média' },
  high: { color: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300', label: 'Alta' },
  critical: { color: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300', label: 'Crítica' }
};

const difficultyConfig = {
  easy: { color: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300', label: 'Fácil' },
  moderate: { color: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300', label: 'Moderado' },
  difficult: { color: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300', label: 'Difícil' },
  expert: { color: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300', label: 'Expert' }
};

export const ProblemDetailCard = ({ problem, phoneModel }: ProblemDetailCardProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [wizardOpen, setWizardOpen] = useState(false);
  const { createBudgetFromProblem } = useBudgetCreation();
  const { stock } = useStock();

  // Calcular custo total das peças do estoque
  const totalPartsCost = problem.requiredParts?.reduce((total, partName) => {
    const matchingItem = stock.find(item => {
      const itemNameLower = item.name.toLowerCase();
      const partNameLower = partName.toLowerCase();
      return itemNameLower.includes(partNameLower) || partNameLower.includes(itemNameLower);
    });
    return total + (matchingItem?.cost || 0);
  }, 0) || 0;

  const handleCreateBudget = () => {
    createBudgetFromProblem({ problem, phoneModel });
  };

  return (
    <Card className="p-6 hover:shadow-lg transition-shadow">
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <div className="space-y-4">
          {/* Header */}
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <h3 className="text-lg font-semibold mb-2">{problem.title}</h3>
              <p className="text-sm text-muted-foreground">{problem.summary}</p>
            </div>
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm">
                <ChevronDown className={`w-5 h-5 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
              </Button>
            </CollapsibleTrigger>
          </div>

          {/* Quick Info Badges */}
          <div className="flex flex-wrap gap-2">
            <Badge className={severityConfig[problem.severity].color}>
              <AlertTriangle className="w-3 h-3 mr-1" />
              {severityConfig[problem.severity].label}
            </Badge>
            <Badge className={difficultyConfig[problem.difficulty].color}>
              {difficultyConfig[problem.difficulty].label}
            </Badge>
            <Badge variant="outline">
              <TrendingUp className="w-3 h-3 mr-1" />
              {problem.frequency}% frequência
            </Badge>
            <Badge variant="outline">
              <Clock className="w-3 h-3 mr-1" />
              {problem.estimatedTime}
            </Badge>
            <Badge variant="outline">
              <DollarSign className="w-3 h-3 mr-1" />
              R$ {problem.estimatedCost.min}-{problem.estimatedCost.max}
            </Badge>
          </div>

          {/* Quick Symptoms */}
          <div>
            <p className="text-sm font-medium mb-2">Sintomas principais:</p>
            <div className="flex flex-wrap gap-1">
              {problem.symptoms.slice(0, 3).map((symptom, idx) => (
                <Badge key={idx} variant="secondary" className="text-xs">
                  {symptom}
                </Badge>
              ))}
              {problem.symptoms.length > 3 && (
                <Badge variant="secondary" className="text-xs">
                  +{problem.symptoms.length - 3} mais
                </Badge>
              )}
            </div>
          </div>

          {/* Collapsible Detailed Content */}
          <CollapsibleContent className="space-y-6 pt-4">
            <Separator />

            {/* Detailed Symptoms */}
            <div>
              <h4 className="font-semibold flex items-center gap-2 mb-3">
                <Activity className="w-4 h-4" />
                Sintomas Detalhados
              </h4>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {problem.detailedSymptoms.map((symptom, idx) => (
                  <li key={idx} className="text-sm flex items-start gap-2">
                    <span className="text-muted-foreground">•</span>
                    <span>{symptom}</span>
                  </li>
                ))}
              </ul>
            </div>

            <Separator />

            {/* Causes */}
            <div>
              <h4 className="font-semibold flex items-center gap-2 mb-3">
                <AlertCircle className="w-4 h-4" />
                Causas Prováveis
              </h4>
              <div className="space-y-2">
                {problem.causes.slice(0, 5).map((cause, idx) => (
                  <div key={idx} className="flex items-center justify-between text-sm">
                    <span className="flex-1">{cause.cause}</span>
                    <Badge variant="outline" className="ml-2">
                      {cause.probability}%
                    </Badge>
                  </div>
                ))}
              </div>
            </div>

            <Separator />

            {/* Diagnostic Tests */}
            <div>
              <h4 className="font-semibold flex items-center gap-2 mb-3">
                <Zap className="w-4 h-4" />
                Testes de Diagnóstico
              </h4>
              <ul className="space-y-2">
                {problem.diagnosticTests.map((test, idx) => (
                  <li key={idx} className="text-sm flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                    <span>{test}</span>
                  </li>
                ))}
              </ul>
            </div>

            <Separator />

            {/* Quick Solution */}
            <div className="bg-muted/50 rounded-lg p-4">
              <h4 className="font-semibold mb-3">🚀 Solução Rápida</h4>
              <ol className="space-y-2">
                {problem.quickSolution.map((step, idx) => (
                  <li key={idx} className="text-sm flex items-start gap-2">
                    <span className="font-medium text-primary">{idx + 1}.</span>
                    <span>{step}</span>
                  </li>
                ))}
              </ol>
            </div>

            {/* Professional Solution */}
            <div className="bg-primary/5 rounded-lg p-4">
              <h4 className="font-semibold mb-3">🔧 Solução Profissional</h4>
              <ol className="space-y-2">
                {problem.professionalSolution.map((step, idx) => (
                  <li key={idx} className="text-sm flex items-start gap-2">
                    <span className="font-medium text-primary">{idx + 1}.</span>
                    <span>{step}</span>
                  </li>
                ))}
              </ol>
            </div>

            <Separator />

            {/* Required Tools */}
            <div>
              <h4 className="font-semibold flex items-center gap-2 mb-3">
                <Wrench className="w-4 h-4" />
                Ferramentas Necessárias
              </h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {problem.requiredTools.map((tool, idx) => (
                  <Badge key={idx} variant="outline" className="justify-start">
                    {tool}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Required Parts & Stock Check */}
            {problem.requiredParts && problem.requiredParts.length > 0 && (
              <>
                <div>
                  <h4 className="font-semibold flex items-center gap-2 mb-3">
                    <PackageSearch className="w-4 h-4" />
                    Peças Necessárias
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {problem.requiredParts.map((part, idx) => (
                      <Badge key={idx} variant="outline" className="justify-start">
                        {part}
                      </Badge>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Parts Availability Checker */}
                <PartsChecker requiredParts={problem.requiredParts} />
              </>
            )}

            {/* Repair Risks */}
            {problem.repairRisks.length > 0 && (
              <div className="bg-orange-50 dark:bg-orange-900/10 border border-orange-200 dark:border-orange-800 rounded-lg p-4">
                <h4 className="font-semibold text-orange-800 dark:text-orange-300 flex items-center gap-2 mb-3">
                  <AlertTriangle className="w-4 h-4" />
                  Riscos do Reparo
                </h4>
                <ul className="space-y-1">
                  {problem.repairRisks.map((risk, idx) => (
                    <li key={idx} className="text-sm text-orange-700 dark:text-orange-400">
                      ⚠️ {risk}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Warning Notes */}
            {problem.warningNotes && problem.warningNotes.length > 0 && (
              <div className="bg-red-50 dark:bg-red-900/10 border border-red-200 dark:border-red-800 rounded-lg p-4">
                <h4 className="font-semibold text-red-800 dark:text-red-300 mb-3">
                  🚨 ATENÇÃO - Avisos Importantes
                </h4>
                <ul className="space-y-1">
                  {problem.warningNotes.map((note, idx) => (
                    <li key={idx} className="text-sm text-red-700 dark:text-red-400 font-medium">
                      {note}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CollapsibleContent>

          {/* Action Buttons */}
          <div className="flex flex-col gap-2">
            <div className="flex gap-2">
              <CollapsibleTrigger asChild>
                <Button variant="outline" className="flex-1">
                  {isOpen ? 'Fechar detalhes' : 'Ver guia completo de reparo'}
                </Button>
              </CollapsibleTrigger>
              
              <Button 
                onClick={handleCreateBudget}
                className="flex-1 bg-primary hover:bg-primary/90"
              >
                <FileText className="w-4 h-4 mr-2" />
                Criar Orçamento
              </Button>
            </div>
            
            <Button 
              onClick={() => setWizardOpen(true)}
              variant="secondary"
              className="w-full"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Assistente de Diagnóstico
            </Button>
          </div>
        </div>
      </Collapsible>

      <DiagnosticWizard
        open={wizardOpen}
        onOpenChange={setWizardOpen}
        category={problem.category}
        problemId={problem.id}
        problemTitle={problem.title}
        phoneModel={phoneModel}
      />
    </Card>
  );
};
