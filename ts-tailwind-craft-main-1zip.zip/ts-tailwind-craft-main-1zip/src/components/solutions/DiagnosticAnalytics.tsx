import { useDiagnosticHistory } from '@/hooks/useDiagnosticHistory';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import {
  BarChart3,
  TrendingUp,
  CheckCircle2,
  Clock,
  Target,
  Calendar,
  Award,
  Activity
} from 'lucide-react';
import { TrendCharts } from './TrendCharts';

export const DiagnosticAnalytics = () => {
  const { getStatistics, history } = useDiagnosticHistory();
  const stats = getStatistics();

  const categoryLabels: Record<string, string> = {
    display: 'Display/Tela',
    battery: 'Bateria/Energia',
    network: 'Rede/Sinal',
    camera: 'Câmera',
    software: 'Software/Sistema',
    charging: 'Carregamento',
    audio: 'Áudio',
    motherboard: 'Placa Mãe',
    sensors: 'Sensores',
    hardware: 'Hardware Geral'
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Diagnósticos */}
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total</p>
              <p className="text-2xl font-bold">{stats.total}</p>
            </div>
          </div>
        </Card>

        {/* Taxa de Resolução */}
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Resolvidos</p>
              <p className="text-2xl font-bold">{stats.resolved}</p>
              <p className="text-xs text-muted-foreground">
                {stats.resolvedRate.toFixed(1)}% de sucesso
              </p>
            </div>
          </div>
        </Card>

        {/* Confiança Média */}
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
              <Target className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Confiança</p>
              <p className="text-2xl font-bold">{stats.avgConfidence.toFixed(0)}%</p>
              <Progress value={stats.avgConfidence} className="h-1 mt-1" />
            </div>
          </div>
        </Card>

        {/* Últimos 30 dias */}
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-orange-500/10 flex items-center justify-center">
              <Calendar className="w-5 h-5 text-orange-600 dark:text-orange-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Últimos 30 dias</p>
              <p className="text-2xl font-bold">{stats.last30Days}</p>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Problemas Mais Comuns */}
        <Card className="p-6">
          <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-primary" />
            Top 5 Problemas Mais Comuns
          </h3>
          <div className="space-y-4">
            {stats.topProblems.length > 0 ? (
              stats.topProblems.map((item, idx) => (
                <div key={idx} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="w-6 h-6 rounded-full flex items-center justify-center p-0">
                        {idx + 1}
                      </Badge>
                      <span className="text-sm font-medium">{item.problem}</span>
                    </div>
                    <Badge>{item.count}x</Badge>
                  </div>
                  <Progress 
                    value={(item.count / stats.total) * 100} 
                    className="h-2"
                  />
                </div>
              ))
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">
                Nenhum diagnóstico registrado ainda
              </p>
            )}
          </div>
        </Card>

        {/* Categorias Mais Afetadas */}
        <Card className="p-6">
          <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
            <Activity className="w-5 h-5 text-primary" />
            Categorias Mais Afetadas
          </h3>
          <div className="space-y-4">
            {stats.topCategories.length > 0 ? (
              stats.topCategories.slice(0, 5).map((item, idx) => (
                <div key={idx} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">
                      {categoryLabels[item.category] || item.category}
                    </span>
                    <Badge variant="secondary">{item.count}x</Badge>
                  </div>
                  <Progress 
                    value={(item.count / stats.total) * 100} 
                    className="h-2"
                  />
                </div>
              ))
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">
                Nenhum diagnóstico registrado ainda
              </p>
            )}
          </div>
        </Card>
      </div>

      {/* Métricas Adicionais */}
      {stats.avgResolutionTime > 0 && (
        <Card className="p-6">
          <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5 text-primary" />
            Tempo Médio de Resolução
          </h3>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <p className="text-3xl font-bold">
                {stats.avgResolutionTime.toFixed(1)}h
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                Média de tempo para resolver problemas diagnosticados
              </p>
            </div>
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
              <Award className="w-8 h-8 text-primary" />
            </div>
          </div>
        </Card>
      )}

      {stats.total === 0 && (
        <Card className="p-12">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto">
              <BarChart3 className="w-8 h-8 text-muted-foreground" />
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-2">Nenhum Diagnóstico Ainda</h3>
              <p className="text-muted-foreground">
                Comece a usar o Assistente de Diagnóstico para rastrear problemas e ver análises aqui
              </p>
            </div>
          </div>
        </Card>
      )}

      {stats.total > 0 && (
        <div className="space-y-4">
          <Separator />
          <h3 className="font-semibold text-xl flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-primary" />
            Gráficos de Tendências
          </h3>
          <TrendCharts history={history} />
        </div>
      )}
    </div>
  );
};
