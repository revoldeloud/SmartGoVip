import { useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { DiagnosticRecord } from '@/hooks/useDiagnosticHistory';
import { format, subDays, startOfDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface TrendChartsProps {
  history: DiagnosticRecord[];
}

const COLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))', 'hsl(var(--chart-5))'];

export const TrendCharts = ({ history }: TrendChartsProps) => {
  const last30DaysData = useMemo(() => {
    const days = Array.from({ length: 30 }, (_, i) => {
      const date = subDays(new Date(), 29 - i);
      return {
        date: format(startOfDay(date), 'dd/MMM', { locale: ptBR }),
        fullDate: startOfDay(date),
        total: 0,
        resolved: 0,
      };
    });

    history.forEach(record => {
      const recordDate = startOfDay(new Date(record.date));
      const dayData = days.find(d => d.fullDate.getTime() === recordDate.getTime());
      if (dayData) {
        dayData.total++;
        if (record.resolved) dayData.resolved++;
      }
    });

    return days.map(({ date, total, resolved }) => ({ date, total, resolved }));
  }, [history]);

  const categoryDistribution = useMemo(() => {
    const counts: Record<string, number> = {};
    history.forEach(record => {
      counts[record.category] = (counts[record.category] || 0) + 1;
    });
    return Object.entries(counts)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value);
  }, [history]);

  const confidenceDistribution = useMemo(() => {
    const ranges = [
      { name: '0-20%', count: 0 },
      { name: '21-40%', count: 0 },
      { name: '41-60%', count: 0 },
      { name: '61-80%', count: 0 },
      { name: '81-100%', count: 0 },
    ];

    history.forEach(record => {
      const confidence = record.confidence;
      if (confidence <= 20) ranges[0].count++;
      else if (confidence <= 40) ranges[1].count++;
      else if (confidence <= 60) ranges[2].count++;
      else if (confidence <= 80) ranges[3].count++;
      else ranges[4].count++;
    });

    return ranges.filter(r => r.count > 0);
  }, [history]);

  const resolutionTimeData = useMemo(() => {
    const times = history
      .filter(r => r.resolved && r.resolutionTime)
      .map(r => ({
        date: format(new Date(r.date), 'dd/MMM', { locale: ptBR }),
        hours: r.resolutionTime || 0,
        problem: r.problemTitle,
      }))
      .slice(-15);
    return times;
  }, [history]);

  if (history.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Gráficos de Tendências</CardTitle>
          <CardDescription>Não há dados suficientes para gerar gráficos</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card className="md:col-span-2">
        <CardHeader>
          <CardTitle>Diagnósticos nos Últimos 30 Dias</CardTitle>
          <CardDescription>Volume total e taxa de resolução</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={last30DaysData}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis dataKey="date" className="text-xs" />
              <YAxis className="text-xs" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--popover))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '0.5rem',
                }}
              />
              <Legend />
              <Line type="monotone" dataKey="total" stroke="hsl(var(--chart-1))" name="Total" strokeWidth={2} />
              <Line type="monotone" dataKey="resolved" stroke="hsl(var(--chart-2))" name="Resolvidos" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Distribuição por Categoria</CardTitle>
          <CardDescription>Problemas mais frequentes</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={categoryDistribution}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="hsl(var(--chart-1))"
                dataKey="value"
              >
                {categoryDistribution.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--popover))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '0.5rem',
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Confiança dos Diagnósticos</CardTitle>
          <CardDescription>Distribuição por nível de confiança</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={confidenceDistribution}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis dataKey="name" className="text-xs" />
              <YAxis className="text-xs" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--popover))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '0.5rem',
                }}
              />
              <Bar dataKey="count" fill="hsl(var(--chart-3))" name="Diagnósticos" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {resolutionTimeData.length > 0 && (
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Tempo de Resolução</CardTitle>
            <CardDescription>Últimos 15 casos resolvidos (em horas)</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={resolutionTimeData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="date" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--popover))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '0.5rem',
                  }}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="rounded-lg border bg-popover p-3 shadow-md">
                          <p className="text-sm font-medium">{payload[0].payload.problem}</p>
                          <p className="text-sm text-muted-foreground">
                            {payload[0].value} horas
                          </p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="hours" fill="hsl(var(--chart-4))" name="Horas" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
