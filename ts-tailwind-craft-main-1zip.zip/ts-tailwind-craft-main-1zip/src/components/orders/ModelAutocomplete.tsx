import { useState, useEffect, useRef } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { getModels, addModel } from '@/utils/storage';
import { toast } from 'sonner';

interface ModelAutocompleteProps {
  value: string;
  onChange: (value: string) => void;
  required?: boolean;
}

export const ModelAutocomplete = ({ value, onChange, required }: ModelAutocompleteProps) => {
  const [models, setModels] = useState<string[]>([]);
  const [filteredModels, setFilteredModels] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadModels();
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const loadModels = () => {
    setModels(getModels());
  };

  const handleInputChange = (inputValue: string) => {
    onChange(inputValue);
    
    if (inputValue.trim()) {
      const filtered = models.filter(model =>
        model.toLowerCase().includes(inputValue.toLowerCase())
      );
      setFilteredModels(filtered);
      setShowSuggestions(filtered.length > 0);
    } else {
      setFilteredModels([]);
      setShowSuggestions(false);
    }
  };

  const handleSelectModel = (model: string) => {
    onChange(model);
    setShowSuggestions(false);
  };

  const handleSaveModel = () => {
    if (value.trim()) {
      addModel(value.trim());
      loadModels();
      toast.success('Modelo salvo com sucesso!');
    } else {
      toast.error('Digite um modelo para salvar');
    }
  };

  return (
    <div ref={wrapperRef} className="relative">
      <Label>Modelo / Marca {required && '*'}</Label>
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Input
            value={value}
            onChange={(e) => handleInputChange(e.target.value)}
            onFocus={() => {
              if (value.trim() && filteredModels.length > 0) {
                setShowSuggestions(true);
              }
            }}
            placeholder="Ex: iPhone 12, Samsung A52"
            required={required}
          />
          
          {showSuggestions && filteredModels.length > 0 && (
            <div className="absolute z-50 w-full mt-1 bg-background border border-border rounded-md shadow-lg max-h-60 overflow-auto">
              {filteredModels.map((model, index) => (
                <div
                  key={index}
                  className="px-3 py-2 cursor-pointer hover:bg-accent hover:text-accent-foreground transition-colors"
                  onClick={() => handleSelectModel(model)}
                >
                  📱 {model}
                </div>
              ))}
            </div>
          )}
        </div>
        
        <Button
          type="button"
          variant="outline"
          onClick={handleSaveModel}
          className="shrink-0"
        >
          💾 Salvar
        </Button>
      </div>
    </div>
  );
};
