import { useState } from 'react';
import { X, Camera, ZoomIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { toast } from 'sonner';

interface PhotoGalleryProps {
  photos: string[];
  onPhotosChange?: (photos: string[]) => void;
  readOnly?: boolean;
}

export const PhotoGallery = ({ photos, onPhotosChange, readOnly = false }: PhotoGalleryProps) => {
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const maxSize = 5 * 1024 * 1024; // 5MB
    const validFiles = Array.from(files).filter(file => {
      if (file.size > maxSize) {
        toast.error(`${file.name} é muito grande. Máximo: 5MB`);
        return false;
      }
      if (!file.type.startsWith('image/')) {
        toast.error(`${file.name} não é uma imagem válida`);
        return false;
      }
      return true;
    });

    if (validFiles.length === 0) return;

    Promise.all(
      validFiles.map(file => {
        return new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });
      })
    ).then(newPhotos => {
      if (onPhotosChange) {
        onPhotosChange([...photos, ...newPhotos]);
        toast.success(`${newPhotos.length} foto(s) adicionada(s)`);
      }
    }).catch(() => {
      toast.error('Erro ao carregar fotos');
    });

    e.target.value = '';
  };

  const removePhoto = (index: number) => {
    if (onPhotosChange) {
      const updated = photos.filter((_, i) => i !== index);
      onPhotosChange(updated);
      toast.success('Foto removida');
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <label className="text-sm font-semibold">
          📸 Galeria de Fotos {photos.length > 0 && `(${photos.length})`}
        </label>
        {!readOnly && (
          <Button
            type="button"
            size="sm"
            variant="outline"
            onClick={() => document.getElementById('photo-upload')?.click()}
          >
            <Camera className="h-4 w-4 mr-2" />
            Adicionar Fotos
          </Button>
        )}
      </div>

      {!readOnly && (
        <input
          id="photo-upload"
          type="file"
          accept="image/*"
          multiple
          onChange={handleFileSelect}
          className="hidden"
        />
      )}

      {photos.length > 0 ? (
        <div className="grid grid-cols-3 gap-2">
          {photos.map((photo, index) => (
            <div key={index} className="relative group aspect-square rounded-lg overflow-hidden border border-border bg-muted">
              <img
                src={photo}
                alt={`Foto ${index + 1}`}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                <Button
                  type="button"
                  size="icon"
                  variant="secondary"
                  className="h-8 w-8"
                  onClick={() => setSelectedPhoto(photo)}
                >
                  <ZoomIn className="h-4 w-4" />
                </Button>
                {!readOnly && (
                  <Button
                    type="button"
                    size="icon"
                    variant="destructive"
                    className="h-8 w-8"
                    onClick={() => removePhoto(index)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8 px-4 border-2 border-dashed border-border rounded-lg bg-muted/20">
          <Camera className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">
            {readOnly ? 'Nenhuma foto anexada' : 'Clique em "Adicionar Fotos" para anexar imagens'}
          </p>
        </div>
      )}

      <Dialog open={!!selectedPhoto} onOpenChange={() => setSelectedPhoto(null)}>
        <DialogContent className="max-w-4xl p-2">
          <img
            src={selectedPhoto || ''}
            alt="Visualização"
            className="w-full h-auto rounded-lg"
          />
        </DialogContent>
      </Dialog>
    </div>
  );
};
