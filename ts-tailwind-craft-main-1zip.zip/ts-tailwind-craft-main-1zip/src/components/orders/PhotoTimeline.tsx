import { useState } from 'react';
import { Camera, ZoomIn } from 'lucide-react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';

interface PhotoTimelineProps {
  beforePhotos?: string[];
  duringPhotos?: string[];
  afterPhotos?: string[];
}

export const PhotoTimeline = ({ beforePhotos = [], duringPhotos = [], afterPhotos = [] }: PhotoTimelineProps) => {
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);

  const stages = [
    { label: 'ANTES', photos: beforePhotos, color: 'bg-red-500/10 border-red-500/50 text-red-700 dark:text-red-400' },
    { label: 'DURANTE', photos: duringPhotos, color: 'bg-blue-500/10 border-blue-500/50 text-blue-700 dark:text-blue-400' },
    { label: 'DEPOIS', photos: afterPhotos, color: 'bg-green-500/10 border-green-500/50 text-green-700 dark:text-green-400' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Camera className="h-5 w-5 text-muted-foreground" />
        <h3 className="font-semibold">Fotos do Serviço</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {stages.map((stage) => (
          <div key={stage.label} className="space-y-2">
            <Badge variant="outline" className={`w-full justify-center py-1 ${stage.color}`}>
              {stage.label}
            </Badge>
            
            {stage.photos.length > 0 ? (
              <div className="grid grid-cols-2 gap-2">
                {stage.photos.map((photo, index) => (
                  <div
                    key={index}
                    className="relative group aspect-square rounded-lg overflow-hidden border border-border bg-muted cursor-pointer"
                    onClick={() => setSelectedPhoto(photo)}
                  >
                    <img src={photo} alt={`${stage.label} ${index + 1}`} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <ZoomIn className="h-6 w-6 text-white" />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="aspect-square rounded-lg border-2 border-dashed border-border bg-muted/20 flex items-center justify-center">
                <p className="text-xs text-muted-foreground text-center px-2">
                  Sem fotos
                </p>
              </div>
            )}
          </div>
        ))}
      </div>

      <Dialog open={!!selectedPhoto} onOpenChange={() => setSelectedPhoto(null)}>
        <DialogContent className="max-w-4xl p-2">
          <img src={selectedPhoto || ''} alt="Visualização" className="w-full h-auto rounded-lg" />
        </DialogContent>
      </Dialog>
    </div>
  );
};
