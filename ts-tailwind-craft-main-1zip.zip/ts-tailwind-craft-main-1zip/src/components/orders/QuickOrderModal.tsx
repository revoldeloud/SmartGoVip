import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ClientAutocomplete } from '@/components/clients/ClientAutocomplete';
import { ModelAutocomplete } from '@/components/orders/ModelAutocomplete';
import { PhotoGallery } from '@/components/orders/PhotoGallery';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ServiceOrder, Client, EntryType } from '@/types';
import { toast } from 'sonner';

interface QuickOrderModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  type: EntryType;
  onSave: (order: Omit<ServiceOrder, 'id' | 'createdAt' | 'updatedAt'>) => void;
}

export const QuickOrderModal = ({ open, onOpenChange, type, onSave }: QuickOrderModalProps) => {
  const [formData, setFormData] = useState({
    clientName: '',
    phone: '',
    model: '',
    service: 'Troca de tela',
    defect: '',
    partsPrice: 50,
    beforePhotos: [] as string[],
  });

  const handleClientSelect = (client: Client) => {
    setFormData({
      ...formData,
      clientName: client.name,
      phone: client.phone,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.clientName || !formData.phone || !formData.model) {
      toast.error('Preencha os campos obrigatórios');
      return;
    }

    const finalPrice = formData.partsPrice * 2 + 70;

    onSave({
      type,
      status: 'pending',
      clientName: formData.clientName,
      phone: formData.phone,
      model: formData.model,
      service: formData.service,
      defect: formData.defect,
      screenType: 'incell',
      servicePrice: formData.partsPrice + 70,
      partsPrice: formData.partsPrice,
      finalPrice,
      warranty: 90,
      beforePhotos: formData.beforePhotos,
    });

    toast.success(type === 'os' ? 'OS criada com sucesso!' : 'Orçamento criado com sucesso!');
    onOpenChange(false);
    
    // Reset form
    setFormData({
      clientName: '',
      phone: '',
      model: '',
      service: 'Troca de tela',
      defect: '',
      partsPrice: 50,
      beforePhotos: [],
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {type === 'os' ? '⚡ Ordem de Serviço Rápida' : '💰 Orçamento Rápido'}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <ClientAutocomplete
              value={formData.clientName}
              onChange={(value) => setFormData({ ...formData, clientName: value })}
              onClientSelect={handleClientSelect}
              required
            />
          </div>

          <div>
            <Label>Telefone *</Label>
            <Input
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              placeholder="(73) 9xxxx-xxxx"
              required
            />
          </div>

          <div>
            <ModelAutocomplete
              value={formData.model}
              onChange={(value) => setFormData({ ...formData, model: value })}
              required
            />
          </div>

          <div>
            <Label>Serviço</Label>
            <Select
              value={formData.service}
              onValueChange={(value) => setFormData({ ...formData, service: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Troca de tela">📱 Troca de tela</SelectItem>
                <SelectItem value="Troca de bateria">🔋 Troca de bateria</SelectItem>
                <SelectItem value="Troca de conector">🔌 Troca de conector</SelectItem>
                <SelectItem value="Reparo de placa">🔧 Reparo de placa</SelectItem>
                <SelectItem value="Limpeza e manutenção">✨ Limpeza e manutenção</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Defeito Relatado</Label>
            <Input
              value={formData.defect}
              onChange={(e) => setFormData({ ...formData, defect: e.target.value })}
              placeholder="Descreva o problema"
            />
          </div>

          <div>
            <Label>Custo das Peças (R$)</Label>
            <Input
              type="number"
              min="0"
              step="0.01"
              value={formData.partsPrice}
              onChange={(e) =>
                setFormData({ ...formData, partsPrice: Number(e.target.value) })
              }
            />
            <p className="text-xs text-muted-foreground mt-1">
              Valor final será calculado automaticamente (Peças × 2 + R$ 70)
            </p>
          </div>

          {formData.partsPrice > 0 && (
            <div className="bg-primary/10 p-3 rounded-lg">
              <div className="flex justify-between items-center">
                <span className="font-semibold">Valor Total:</span>
                <span className="text-xl font-bold">
                  R$ {(formData.partsPrice * 2 + 70).toFixed(2)}
                </span>
              </div>
            </div>
          )}

          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="bg-red-500/10 text-red-600 px-3 py-1 rounded-md text-sm font-medium border border-red-500/20">
                📸 ANTES - Condição de Entrada
              </span>
              <span className="text-xs text-muted-foreground">(opcional)</span>
            </div>
            <p className="text-xs text-muted-foreground">
              Documente o estado do aparelho no momento da entrada
            </p>
            <PhotoGallery
              photos={formData.beforePhotos}
              onPhotosChange={(photos) => setFormData({ ...formData, beforePhotos: photos })}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit">{type === 'os' ? 'Criar OS' : 'Criar Orçamento'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
