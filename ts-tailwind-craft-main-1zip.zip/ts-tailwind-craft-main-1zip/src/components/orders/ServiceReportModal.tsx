import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ServiceOrder } from '@/types';
import { PhotoTimeline } from './PhotoTimeline';
import { formatCurrency, formatDate } from '@/utils/formatters';
import { sendServiceReport, sendPaymentReceipt } from '@/utils/whatsapp';
import { printReceipt } from '@/utils/print';
import { toast } from 'sonner';
import { CheckCircle2, MessageCircle, Printer, Handshake, Download } from 'lucide-react';
import mercadoPagoQR from '@/assets/mercadopago-qr.jpg';

interface ServiceReportModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  order: ServiceOrder;
  onConfirmPayment: () => void;
}

export const ServiceReportModal = ({ open, onOpenChange, order, onConfirmPayment }: ServiceReportModalProps) => {
  const handleConfirmPayment = () => {
    onConfirmPayment();
    sendPaymentReceipt(order);
    toast.success('Pagamento confirmado! Recibo enviado via WhatsApp.');
    onOpenChange(false);
  };

  const handleDownloadQR = () => {
    const link = document.createElement('a');
    link.href = mercadoPagoQR;
    link.download = `qr-code-os-${order.id}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('QR Code baixado!');
  };

  const handleDownloadPhotos = () => {
    const allPhotos = [
      ...(order.beforePhotos || []).map((p, i) => ({ url: p, name: `ANTES-${i + 1}` })),
      ...(order.duringPhotos || []).map((p, i) => ({ url: p, name: `DURANTE-${i + 1}` })),
      ...(order.afterPhotos || []).map((p, i) => ({ url: p, name: `DEPOIS-${i + 1}` }))
    ];

    if (allPhotos.length === 0) {
      toast.error('Não há fotos para baixar');
      return;
    }

    allPhotos.forEach(({ url, name }) => {
      const link = document.createElement('a');
      link.href = url;
      link.download = `foto-${name}-os-${order.id}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    });
    
    toast.success(`${allPhotos.length} foto(s) baixada(s)!`);
  };

  const pixKey = 'deverestystudio@gmail.com';

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>📋 Relatório de Serviço Completo</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Dados do Serviço */}
          <div className="grid grid-cols-2 gap-4 p-4 bg-muted/50 rounded-lg">
            <div>
              <p className="text-sm text-muted-foreground">Cliente</p>
              <p className="font-semibold">{order.clientName}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Aparelho</p>
              <p className="font-semibold">{order.model}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Serviço</p>
              <p className="font-semibold">{order.service}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Data</p>
              <p className="font-semibold">{formatDate(order.createdAt)}</p>
            </div>
          </div>

          {/* Timeline de Fotos */}
          <PhotoTimeline
            beforePhotos={order.beforePhotos}
            duringPhotos={order.duringPhotos}
            afterPhotos={order.afterPhotos}
          />

          {/* Valor Total */}
          <div className="p-4 bg-muted/50 rounded-lg">
            <p className="text-sm text-muted-foreground">Valor Total do Serviço</p>
            <p className="text-3xl font-bold text-primary">{formatCurrency(order.finalPrice)}</p>
          </div>

          {/* Pagamento Mercado Pago */}
          <div className="border border-border rounded-lg overflow-hidden bg-background">
            <div className="p-8">
              {/* Header com ícone */}
              <div className="flex flex-col items-center gap-4 mb-6">
                <div className="w-16 h-16 rounded-full bg-green-500/10 flex items-center justify-center border-2 border-green-500/20">
                  <Handshake className="w-8 h-8 text-green-600" />
                  <CheckCircle2 className="w-5 h-5 text-green-600 absolute -mt-8 ml-8" />
                </div>
                <div className="text-center">
                  <h3 className="text-xl font-semibold mb-1">Escaneie o código QR para pagar</h3>
                  <p className="text-sm text-muted-foreground">Pagamento via Mercado Pago</p>
                </div>
              </div>

              {/* QR Code */}
              <div className="flex justify-center mb-6">
                <div className="p-4 bg-white rounded-lg shadow-sm">
                  <img 
                    src={mercadoPagoQR} 
                    alt="QR Code Mercado Pago" 
                    className="w-[280px] h-[280px] object-contain"
                  />
                </div>
              </div>

              {/* Informações do PIX */}
              <div className="space-y-3 bg-muted/30 rounded-lg p-4 border border-border">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Banco</p>
                  <p className="font-medium text-sm">Mercado Pago</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Beneficiário</p>
                  <p className="font-medium text-sm">John Macley E.S.Sá</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Chave Pix</p>
                  <p className="font-medium text-sm">{pixKey}</p>
                </div>
              </div>

              {/* Copiar chave PIX */}
              <div className="mt-4">
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    navigator.clipboard.writeText(pixKey);
                    toast.success('Chave PIX copiada para a área de transferência!');
                  }}
                >
                  Copiar Chave PIX
                </Button>
              </div>
            </div>
          </div>

          {/* Alerta para envio manual de anexos */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <p className="text-sm font-medium text-yellow-900 mb-2">
              📲 Importante: Anexos devem ser enviados manualmente
            </p>
            <p className="text-xs text-yellow-800 mb-3">
              Após enviar a mensagem via WhatsApp, você precisará anexar manualmente o QR Code e as fotos do serviço.
            </p>
            <div className="flex gap-2">
              <Button
                onClick={handleDownloadQR}
                size="sm"
                variant="outline"
                className="flex-1 border-yellow-300 hover:bg-yellow-100"
              >
                <Download className="w-4 h-4 mr-2" />
                Baixar QR Code
              </Button>
              <Button
                onClick={handleDownloadPhotos}
                size="sm"
                variant="outline"
                className="flex-1 border-yellow-300 hover:bg-yellow-100"
              >
                <Download className="w-4 h-4 mr-2" />
                Baixar Fotos
              </Button>
            </div>
          </div>

          {/* Ações */}
          <div className="flex flex-wrap gap-2">
            <Button onClick={() => sendServiceReport(order)} className="flex-1">
              <MessageCircle className="h-4 w-4 mr-2" />
              Enviar Relatório via WhatsApp
            </Button>
            
            <Button onClick={handleConfirmPayment} variant="default" className="flex-1">
              <CheckCircle2 className="h-4 w-4 mr-2" />
              Confirmar Pagamento
            </Button>

            <Button onClick={() => printReceipt(order)} variant="outline">
              <Printer className="h-4 w-4 mr-2" />
              Imprimir Recibo
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
