import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { ServiceOrder } from '@/types';
import { formatCurrency, formatDate, getStatusLabel, getStatusColor } from '@/utils/formatters';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { PhotoTimeline } from './PhotoTimeline';
import { sendToWhatsApp } from '@/utils/whatsapp';

interface OrderViewModalProps {
  order: ServiceOrder | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const OrderViewModal = ({ order, open, onOpenChange }: OrderViewModalProps) => {
  if (!order) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Detalhes da {order.type === 'os' ? 'Ordem de Serviço' : 'Orçamento'}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-2xl font-bold">{order.clientName}</h3>
              <p className="text-muted-foreground">📱 {order.phone}</p>
            </div>
            <Badge className={getStatusColor(order.status)}>
              {getStatusLabel(order.status)}
            </Badge>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-semibold text-muted-foreground">Modelo</label>
              <p className="text-lg">{order.model}</p>
            </div>
            <div>
              <label className="text-sm font-semibold text-muted-foreground">Serviço</label>
              <p className="text-lg">{order.service}</p>
            </div>
          </div>

          {order.defect && (
            <div>
              <label className="text-sm font-semibold text-muted-foreground">Defeito Relatado</label>
              <p className="text-base">{order.defect}</p>
            </div>
          )}

          {order.observations && (
            <div>
              <label className="text-sm font-semibold text-muted-foreground">Observações</label>
              <p className="text-base">{order.observations}</p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4 pt-4 border-t">
            <div>
              <label className="text-sm font-semibold text-muted-foreground">Valor do Serviço</label>
              <p className="text-xl font-bold text-primary">{formatCurrency(order.servicePrice)}</p>
            </div>
            <div>
              <label className="text-sm font-semibold text-muted-foreground">Valor das Peças</label>
              <p className="text-xl font-bold text-primary">{formatCurrency(order.partsPrice)}</p>
            </div>
          </div>

          <div className="pt-4 border-t">
            <label className="text-sm font-semibold text-muted-foreground">Valor Total</label>
            <p className="text-3xl font-bold text-primary">{formatCurrency(order.finalPrice)}</p>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-4 border-t text-sm text-muted-foreground">
            <div>
              <label className="font-semibold">Criado em</label>
              <p>{formatDate(order.createdAt)}</p>
            </div>
            <div>
              <label className="font-semibold">Última atualização</label>
              <p>{formatDate(order.updatedAt)}</p>
            </div>
          </div>

          {(order.beforePhotos || order.duringPhotos || order.afterPhotos) && (
            <div className="border-t pt-4">
              <PhotoTimeline
                beforePhotos={order.beforePhotos}
                duringPhotos={order.duringPhotos}
                afterPhotos={order.afterPhotos}
              />
            </div>
          )}
        </div>

        <DialogFooter>
          <Button
            onClick={() => sendToWhatsApp(order)}
            className="w-full bg-green-600 hover:bg-green-700 text-white"
          >
            📱 Enviar pelo WhatsApp
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
