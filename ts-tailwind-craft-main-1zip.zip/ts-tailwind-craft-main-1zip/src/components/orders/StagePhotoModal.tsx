import { useState } from 'react';
import { Camera, X } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface StagePhotoModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  stage: 'before' | 'during' | 'after';
  onSave: (photos: string[]) => void;
}

const STAGE_LABELS = {
  before: '📸 ANTES - Condição Inicial',
  during: '🔧 DURANTE - Em Reparo',
  after: '✅ DEPOIS - Serviço Concluído'
};

const STAGE_COLORS = {
  before: 'bg-red-500/10 border-red-500/30',
  during: 'bg-blue-500/10 border-blue-500/30',
  after: 'bg-green-500/10 border-green-500/30'
};

export const StagePhotoModal = ({ open, onOpenChange, stage, onSave }: StagePhotoModalProps) => {
  const [photos, setPhotos] = useState<string[]>([]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const maxSize = 5 * 1024 * 1024;
    const validFiles = Array.from(files).filter(file => {
      if (file.size > maxSize) {
        toast.error(`${file.name} é muito grande. Máximo: 5MB`);
        return false;
      }
      if (!file.type.startsWith('image/')) {
        toast.error(`${file.name} não é uma imagem válida`);
        return false;
      }
      return true;
    });

    if (validFiles.length === 0) return;

    Promise.all(
      validFiles.map(file => {
        return new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });
      })
    ).then(newPhotos => {
      setPhotos(prev => [...prev, ...newPhotos]);
      toast.success(`${newPhotos.length} foto(s) adicionada(s)`);
    }).catch(() => {
      toast.error('Erro ao carregar fotos');
    });

    e.target.value = '';
  };

  const removePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  const handleSave = () => {
    onSave(photos);
    setPhotos([]);
    onOpenChange(false);
  };

  const handleSkip = () => {
    setPhotos([]);
    onOpenChange(false);
    onSave([]);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{STAGE_LABELS[stage]}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className={`p-4 rounded-lg border ${STAGE_COLORS[stage]}`}>
            <p className="text-sm text-muted-foreground">
              {stage === 'before' && 'Documente o estado inicial do aparelho antes de iniciar o reparo.'}
              {stage === 'during' && 'Registre o processo de reparo e componentes substituídos.'}
              {stage === 'after' && 'Fotografe o resultado final do serviço concluído.'}
            </p>
          </div>

          <Button
            type="button"
            variant="outline"
            className="w-full"
            onClick={() => document.getElementById('stage-photo-upload')?.click()}
          >
            <Camera className="h-4 w-4 mr-2" />
            Adicionar Fotos (Opcional)
          </Button>

          <input
            id="stage-photo-upload"
            type="file"
            accept="image/*"
            multiple
            onChange={handleFileSelect}
            className="hidden"
          />

          {photos.length > 0 && (
            <div className="grid grid-cols-3 gap-2">
              {photos.map((photo, index) => (
                <div key={index} className="relative group aspect-square rounded-lg overflow-hidden border border-border">
                  <img src={photo} alt={`Foto ${index + 1}`} className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => removePhoto(index)}
                    className="absolute top-1 right-1 p-1 bg-destructive text-destructive-foreground rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <DialogFooter>
          <Button type="button" variant="ghost" onClick={handleSkip}>
            Pular
          </Button>
          <Button type="button" onClick={handleSave}>
            {photos.length > 0 ? `Salvar ${photos.length} foto(s)` : 'Continuar sem fotos'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
