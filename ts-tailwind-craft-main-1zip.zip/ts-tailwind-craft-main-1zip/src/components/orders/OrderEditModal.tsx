import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { PhotoTimeline } from './PhotoTimeline';
import { StagePhotoModal } from './StagePhotoModal';
import { ServiceReportModal } from './ServiceReportModal';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ServiceOrder, OrderStatus } from '@/types';

interface OrderEditModalProps {
  order: ServiceOrder | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (id: string, data: Partial<ServiceOrder>) => void;
}

export const OrderEditModal = ({ order, open, onOpenChange, onSave }: OrderEditModalProps) => {
  const [formData, setFormData] = useState({
    clientName: '',
    phone: '',
    email: '',
    address: '',
    model: '',
    service: '',
    defect: '',
    observations: '',
    servicePrice: 0,
    partsPrice: 0,
    finalPrice: 0,
    status: 'pending' as OrderStatus,
    beforePhotos: [] as string[],
    duringPhotos: [] as string[],
    afterPhotos: [] as string[],
  });

  const [previousStatus, setPreviousStatus] = useState<OrderStatus>('pending');
  const [photoModalOpen, setPhotoModalOpen] = useState(false);
  const [photoStage, setPhotoStage] = useState<'before' | 'during' | 'after'>('before');
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [pendingSave, setPendingSave] = useState(false);

  useEffect(() => {
    if (order) {
      setFormData({
        clientName: order.clientName,
        phone: order.phone,
        email: order.email || '',
        address: order.address || '',
        model: order.model,
        service: order.service,
        defect: order.defect || '',
        observations: order.observations || '',
        servicePrice: order.servicePrice,
        partsPrice: order.partsPrice,
        finalPrice: order.finalPrice,
        status: order.status,
        beforePhotos: order.beforePhotos || [],
        duringPhotos: order.duringPhotos || [],
        afterPhotos: order.afterPhotos || [],
      });
      setPreviousStatus(order.status);
    }
  }, [order]);

  const handleStatusChange = (newStatus: OrderStatus) => {
    // Detectar transições de status e pedir fotos
    if (previousStatus === 'pending' && newStatus === 'in_progress') {
      setPhotoStage('during');
      setPhotoModalOpen(true);
    } else if (previousStatus === 'in_progress' && newStatus === 'ready') {
      setPhotoStage('after');
      setPhotoModalOpen(true);
    }
    
    setFormData({ ...formData, status: newStatus });
    setPreviousStatus(newStatus);
  };

  const handlePhotoSave = (photos: string[]) => {
    if (photoStage === 'during') {
      setFormData({ ...formData, duringPhotos: [...formData.duringPhotos, ...photos] });
    } else if (photoStage === 'after') {
      setFormData({ ...formData, afterPhotos: [...formData.afterPhotos, ...photos] });
    }
    
    // Se mudou para "ready", abrir relatório após salvar fotos
    if (formData.status === 'ready' && photoStage === 'after') {
      setPendingSave(true);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (order) {
      const dataToSave = {
        ...formData,
        finalPrice: formData.servicePrice + formData.partsPrice,
      };
      
      onSave(order.id, dataToSave);
      
      // Se mudou para "ready", abrir relatório
      if (formData.status === 'ready' && previousStatus !== 'ready') {
        setReportModalOpen(true);
      } else {
        onOpenChange(false);
      }
    }
  };

  const handleConfirmPayment = () => {
    if (order) {
      onSave(order.id, {
        paymentConfirmed: true,
        paymentDate: new Date().toISOString(),
        status: 'delivered',
      });
    }
  };

  // Salvar e abrir relatório quando pendingSave for true
  useEffect(() => {
    if (pendingSave && order) {
      const dataToSave = {
        ...formData,
        finalPrice: formData.servicePrice + formData.partsPrice,
      };
      onSave(order.id, dataToSave);
      setReportModalOpen(true);
      setPendingSave(false);
    }
  }, [pendingSave, order, formData, onSave]);

  if (!order) return null;

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Editar {order.type === 'os' ? 'Ordem de Serviço' : 'Orçamento'}</DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="clientName">Cliente *</Label>
                <Input
                  id="clientName"
                  value={formData.clientName}
                  onChange={(e) => setFormData({ ...formData, clientName: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="phone">Telefone *</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="model">Modelo *</Label>
                <Input
                  id="model"
                  value={formData.model}
                  onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="service">Serviço *</Label>
                <Input
                  id="service"
                  value={formData.service}
                  onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                  required
                />
              </div>
            </div>

            <div>
              <Label htmlFor="defect">Defeito Relatado</Label>
              <Textarea
                id="defect"
                value={formData.defect}
                onChange={(e) => setFormData({ ...formData, defect: e.target.value })}
                rows={2}
              />
            </div>

            <div>
              <Label htmlFor="observations">Observações</Label>
              <Textarea
                id="observations"
                value={formData.observations}
                onChange={(e) => setFormData({ ...formData, observations: e.target.value })}
                rows={2}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="servicePrice">Valor do Serviço *</Label>
                <Input
                  id="servicePrice"
                  type="number"
                  step="0.01"
                  value={formData.servicePrice}
                  onChange={(e) => setFormData({ ...formData, servicePrice: parseFloat(e.target.value) || 0 })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="partsPrice">Valor das Peças</Label>
                <Input
                  id="partsPrice"
                  type="number"
                  step="0.01"
                  value={formData.partsPrice}
                  onChange={(e) => setFormData({ ...formData, partsPrice: parseFloat(e.target.value) || 0 })}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="status">Status *</Label>
              <Select value={formData.status} onValueChange={handleStatusChange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pendente</SelectItem>
                  <SelectItem value="in_progress">Em Andamento</SelectItem>
                  <SelectItem value="waiting_parts">Aguardando Peças</SelectItem>
                  <SelectItem value="ready">Pronto</SelectItem>
                  <SelectItem value="delivered">Entregue</SelectItem>
                  <SelectItem value="cancelled">Cancelado</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <PhotoTimeline
              beforePhotos={formData.beforePhotos}
              duringPhotos={formData.duringPhotos}
              afterPhotos={formData.afterPhotos}
            />

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancelar
              </Button>
              <Button type="submit">Salvar Alterações</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <StagePhotoModal
        open={photoModalOpen}
        onOpenChange={setPhotoModalOpen}
        stage={photoStage}
        onSave={handlePhotoSave}
      />

      {order && (
        <ServiceReportModal
          open={reportModalOpen}
          onOpenChange={setReportModalOpen}
          order={{ ...order, ...formData }}
          onConfirmPayment={handleConfirmPayment}
        />
      )}
    </>
  );
};
