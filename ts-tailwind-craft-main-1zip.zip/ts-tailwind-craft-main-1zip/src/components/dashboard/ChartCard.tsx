import { Card } from '@/components/ui/card';
import { ReactNode } from 'react';

interface ChartCardProps {
  title: string;
  children: ReactNode;
}

export const ChartCard = ({ title, children }: ChartCardProps) => {
  return (
    <Card className="p-6 transition-all duration-300 hover:shadow-[0_0_30px_rgba(6,182,212,0.1)]">
      <h3 className="text-lg font-semibold mb-4 text-foreground flex items-center gap-2">
        <span className="w-1 h-6 bg-gradient-to-b from-cyan-400 to-purple-500 rounded-full" />
        {title}
      </h3>
      <div className="w-full h-64">{children}</div>
    </Card>
  );
};
