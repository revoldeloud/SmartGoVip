import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface StatCardProps {
  label: string;
  value: string | number;
  icon?: string;
  variant?: 'default' | 'warning' | 'info' | 'success';
}

const variantStyles = {
  default: {
    glow: 'hover:shadow-[0_0_30px_rgba(6,182,212,0.15)]',
    value: 'from-cyan-400 to-blue-500',
    iconBg: 'bg-cyan-500/20',
  },
  warning: {
    glow: 'hover:shadow-[0_0_30px_rgba(245,158,11,0.15)]',
    value: 'from-amber-400 to-orange-500',
    iconBg: 'bg-amber-500/20',
  },
  info: {
    glow: 'hover:shadow-[0_0_30px_rgba(59,130,246,0.15)]',
    value: 'from-blue-400 to-indigo-500',
    iconBg: 'bg-blue-500/20',
  },
  success: {
    glow: 'hover:shadow-[0_0_30px_rgba(16,185,129,0.15)]',
    value: 'from-emerald-400 to-green-500',
    iconBg: 'bg-emerald-500/20',
  },
};

export const StatCard = ({ label, value, icon, variant = 'default' }: StatCardProps) => {
  const styles = variantStyles[variant];
  
  return (
    <Card className={cn(
      "p-5 text-center transition-all duration-300 hover:scale-[1.02]",
      styles.glow
    )}>
      {icon && (
        <div className={cn(
          "w-12 h-12 mx-auto mb-3 rounded-2xl flex items-center justify-center text-2xl",
          styles.iconBg
        )}>
          {icon}
        </div>
      )}
      <div className={cn(
        "text-4xl font-bold bg-gradient-to-r bg-clip-text text-transparent mb-2",
        styles.value
      )}>
        {value}
      </div>
      <div className="text-xs uppercase tracking-widest text-muted-foreground font-medium">
        {label}
      </div>
    </Card>
  );
};
