import { useState, useEffect, useRef } from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { useStock } from '@/hooks/useStock';
import { StockItem } from '@/types';

interface ProductAutocompleteProps {
  value: string;
  onChange: (value: string) => void;
  onProductSelect?: (product: StockItem) => void;
  label?: string;
  placeholder?: string;
  required?: boolean;
}

export const ProductAutocomplete = ({
  value,
  onChange,
  onProductSelect,
  label = 'Produto/Serviço',
  placeholder = 'Digite o nome do produto ou serviço...',
  required = false,
}: ProductAutocompleteProps) => {
  const { stock } = useStock();
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [filteredProducts, setFilteredProducts] = useState<StockItem[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (value.length > 0) {
      const filtered = stock.filter((item) =>
        item.name.toLowerCase().includes(value.toLowerCase())
      );
      setFilteredProducts(filtered);
      setShowSuggestions(filtered.length > 0);
    } else {
      setShowSuggestions(false);
    }
  }, [value, stock]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectProduct = (product: StockItem) => {
    onChange(product.name);
    onProductSelect?.(product);
    setShowSuggestions(false);
  };

  const getCategoryLabel = (category: string) => {
    const labels = {
      tela: '📱 Tela',
      bateria: '🔋 Bateria',
      camera: '📷 Câmera',
      conector: '🔌 Conector',
      outro: '🔧 Outro',
    };
    return labels[category as keyof typeof labels] || category;
  };

  return (
    <div ref={containerRef} className="relative">
      <Label>
        {label} {required && '*'}
      </Label>
      <Input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        onFocus={() => value.length > 0 && setShowSuggestions(true)}
      />
      {showSuggestions && filteredProducts.length > 0 && (
        <div className="absolute z-10 w-full mt-1 bg-background border rounded-md shadow-lg max-h-60 overflow-auto">
          {filteredProducts.map((product) => (
            <button
              key={product.id}
              type="button"
              className="w-full px-4 py-2 text-left hover:bg-muted transition-colors flex justify-between items-center"
              onClick={() => handleSelectProduct(product)}
            >
              <div>
                <p className="font-medium">{product.name}</p>
                <p className="text-sm text-muted-foreground">
                  {getCategoryLabel(product.category)} • Estoque: {product.quantity}
                </p>
              </div>
              <p className="text-sm font-semibold">R$ {product.cost.toFixed(2)}</p>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
