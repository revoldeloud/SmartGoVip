import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { StockItem, StockCategory } from '@/types';

interface StockModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (data: Omit<StockItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  item?: StockItem | null;
}

export const StockModal = ({ open, onOpenChange, onSave, item }: StockModalProps) => {
  const [formData, setFormData] = useState({
    name: '',
    category: 'tela' as StockCategory,
    quantity: 0,
    minQuantity: 5,
    cost: 0,
  });

  useEffect(() => {
    if (item) {
      setFormData({
        name: item.name,
        category: item.category,
        quantity: item.quantity,
        minQuantity: item.minQuantity,
        cost: item.cost,
      });
    } else {
      setFormData({
        name: '',
        category: 'tela',
        quantity: 0,
        minQuantity: 5,
        cost: 0,
      });
    }
  }, [item, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{item ? 'Editar Item' : 'Novo Item no Estoque'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label>Nome do Item *</Label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Ex: Tela iPhone 12"
              required
            />
          </div>

          <div>
            <Label>Categoria</Label>
            <Select
              value={formData.category}
              onValueChange={(value: StockCategory) =>
                setFormData({ ...formData, category: value })
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="tela">📱 Tela</SelectItem>
                <SelectItem value="bateria">🔋 Bateria</SelectItem>
                <SelectItem value="camera">📷 Câmera</SelectItem>
                <SelectItem value="conector">🔌 Conector</SelectItem>
                <SelectItem value="outro">🔧 Outro</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Quantidade *</Label>
              <Input
                type="number"
                min="0"
                value={formData.quantity}
                onChange={(e) =>
                  setFormData({ ...formData, quantity: Number(e.target.value) })
                }
                required
              />
            </div>
            <div>
              <Label>Quantidade Mínima</Label>
              <Input
                type="number"
                min="0"
                value={formData.minQuantity}
                onChange={(e) =>
                  setFormData({ ...formData, minQuantity: Number(e.target.value) })
                }
              />
            </div>
          </div>

          <div>
            <Label>Custo (R$) *</Label>
            <Input
              type="number"
              min="0"
              step="0.01"
              value={formData.cost}
              onChange={(e) =>
                setFormData({ ...formData, cost: Number(e.target.value) })
              }
              required
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit">Salvar</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
