// Database of phone specifications with images
export interface PhoneSpec {
  brand: string;
  model: string;
  ram: string[];
  storage: string[];
  imageUrl?: string;
  releaseYear?: number;
}

export const phoneSpecsDatabase: PhoneSpec[] = [
  // iPhone Models
  {
    brand: 'Apple',
    model: 'iPhone 15 Pro Max',
    ram: ['8GB'],
    storage: ['256GB', '512GB', '1TB'],
    imageUrl: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400',
    releaseYear: 2023
  },
  {
    brand: 'Apple',
    model: 'iPhone 15 Pro',
    ram: ['8GB'],
    storage: ['128GB', '256GB', '512GB', '1TB'],
    imageUrl: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400',
    releaseYear: 2023
  },
  {
    brand: 'Apple',
    model: 'iPhone 15',
    ram: ['6GB'],
    storage: ['128GB', '256GB', '512GB'],
    imageUrl: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400',
    releaseYear: 2023
  },
  {
    brand: 'Apple',
    model: 'iPhone 14 Pro Max',
    ram: ['6GB'],
    storage: ['128GB', '256GB', '512GB', '1TB'],
    imageUrl: 'https://images.unsplash.com/photo-1678685888221-cda773a3dcdb?w=400',
    releaseYear: 2022
  },
  {
    brand: 'Apple',
    model: 'iPhone 14 Pro',
    ram: ['6GB'],
    storage: ['128GB', '256GB', '512GB', '1TB'],
    imageUrl: 'https://images.unsplash.com/photo-1678685888221-cda773a3dcdb?w=400',
    releaseYear: 2022
  },
  {
    brand: 'Apple',
    model: 'iPhone 14',
    ram: ['6GB'],
    storage: ['128GB', '256GB', '512GB'],
    imageUrl: 'https://images.unsplash.com/photo-1678685888221-cda773a3dcdb?w=400',
    releaseYear: 2022
  },
  {
    brand: 'Apple',
    model: 'iPhone 13',
    ram: ['4GB'],
    storage: ['128GB', '256GB', '512GB'],
    imageUrl: 'https://images.unsplash.com/photo-1632633173522-29ef97b1fbc6?w=400',
    releaseYear: 2021
  },
  {
    brand: 'Apple',
    model: 'iPhone 12',
    ram: ['4GB'],
    storage: ['64GB', '128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1605787020600-b9ebd5df1d07?w=400',
    releaseYear: 2020
  },
  {
    brand: 'Apple',
    model: 'iPhone 11',
    ram: ['4GB'],
    storage: ['64GB', '128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1574755393849-623942496936?w=400',
    releaseYear: 2019
  },

  // Samsung Galaxy S Series
  {
    brand: 'Samsung',
    model: 'Galaxy S24 Ultra',
    ram: ['12GB'],
    storage: ['256GB', '512GB', '1TB'],
    imageUrl: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400',
    releaseYear: 2024
  },
  {
    brand: 'Samsung',
    model: 'Galaxy S24 Plus',
    ram: ['12GB'],
    storage: ['256GB', '512GB'],
    imageUrl: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400',
    releaseYear: 2024
  },
  {
    brand: 'Samsung',
    model: 'Galaxy S24',
    ram: ['8GB'],
    storage: ['128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400',
    releaseYear: 2024
  },
  {
    brand: 'Samsung',
    model: 'Galaxy S23 Ultra',
    ram: ['8GB', '12GB'],
    storage: ['256GB', '512GB', '1TB'],
    imageUrl: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400',
    releaseYear: 2023
  },
  {
    brand: 'Samsung',
    model: 'Galaxy S23',
    ram: ['8GB'],
    storage: ['128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400',
    releaseYear: 2023
  },
  {
    brand: 'Samsung',
    model: 'Galaxy S22 Ultra',
    ram: ['8GB', '12GB'],
    storage: ['128GB', '256GB', '512GB', '1TB'],
    imageUrl: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400',
    releaseYear: 2022
  },
  {
    brand: 'Samsung',
    model: 'Galaxy S22',
    ram: ['8GB'],
    storage: ['128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400',
    releaseYear: 2022
  },

  // Samsung Galaxy A Series
  {
    brand: 'Samsung',
    model: 'Galaxy A54',
    ram: ['6GB', '8GB'],
    storage: ['128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },
  {
    brand: 'Samsung',
    model: 'Galaxy A34',
    ram: ['6GB', '8GB'],
    storage: ['128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },
  {
    brand: 'Samsung',
    model: 'Galaxy A24',
    ram: ['4GB', '6GB'],
    storage: ['128GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },
  {
    brand: 'Samsung',
    model: 'Galaxy A14',
    ram: ['4GB', '6GB'],
    storage: ['64GB', '128GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },

  // Xiaomi Redmi
  {
    brand: 'Xiaomi',
    model: 'Redmi Note 13 Pro',
    ram: ['8GB', '12GB'],
    storage: ['256GB', '512GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },
  {
    brand: 'Xiaomi',
    model: 'Redmi Note 13',
    ram: ['6GB', '8GB'],
    storage: ['128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },
  {
    brand: 'Xiaomi',
    model: 'Redmi Note 12 Pro',
    ram: ['8GB'],
    storage: ['128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },
  {
    brand: 'Xiaomi',
    model: 'Redmi Note 12',
    ram: ['4GB', '6GB', '8GB'],
    storage: ['128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },
  {
    brand: 'Xiaomi',
    model: 'Redmi 13C',
    ram: ['4GB', '6GB'],
    storage: ['128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },

  // Xiaomi Poco
  {
    brand: 'Xiaomi',
    model: 'Poco X6 Pro',
    ram: ['8GB', '12GB'],
    storage: ['256GB', '512GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2024
  },
  {
    brand: 'Xiaomi',
    model: 'Poco X5 Pro',
    ram: ['6GB', '8GB'],
    storage: ['128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },
  {
    brand: 'Xiaomi',
    model: 'Poco M6 Pro',
    ram: ['6GB', '8GB'],
    storage: ['128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2024
  },

  // Motorola Moto G
  {
    brand: 'Motorola',
    model: 'Moto G84',
    ram: ['8GB', '12GB'],
    storage: ['128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },
  {
    brand: 'Motorola',
    model: 'Moto G73',
    ram: ['8GB'],
    storage: ['128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },
  {
    brand: 'Motorola',
    model: 'Moto G54',
    ram: ['8GB'],
    storage: ['128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },
  {
    brand: 'Motorola',
    model: 'Moto G24',
    ram: ['4GB', '8GB'],
    storage: ['128GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2024
  },
  {
    brand: 'Motorola',
    model: 'Moto G14',
    ram: ['4GB'],
    storage: ['128GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },

  // Motorola Edge
  {
    brand: 'Motorola',
    model: 'Edge 40 Pro',
    ram: ['12GB'],
    storage: ['256GB', '512GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },
  {
    brand: 'Motorola',
    model: 'Edge 40',
    ram: ['8GB'],
    storage: ['256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },

  // Realme
  {
    brand: 'Realme',
    model: 'Realme 12 Pro+',
    ram: ['8GB', '12GB'],
    storage: ['256GB', '512GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2024
  },
  {
    brand: 'Realme',
    model: 'Realme 12 Pro',
    ram: ['8GB'],
    storage: ['128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2024
  },
  {
    brand: 'Realme',
    model: 'Realme 11 Pro',
    ram: ['8GB', '12GB'],
    storage: ['256GB', '512GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },
  {
    brand: 'Realme',
    model: 'Realme C55',
    ram: ['6GB', '8GB'],
    storage: ['128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },

  // OnePlus
  {
    brand: 'OnePlus',
    model: 'OnePlus 12',
    ram: ['12GB', '16GB'],
    storage: ['256GB', '512GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2024
  },
  {
    brand: 'OnePlus',
    model: 'OnePlus 11',
    ram: ['8GB', '16GB'],
    storage: ['128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },
  {
    brand: 'OnePlus',
    model: 'OnePlus Nord 3',
    ram: ['8GB', '16GB'],
    storage: ['128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },

  // Nokia
  {
    brand: 'Nokia',
    model: 'Nokia G60',
    ram: ['4GB', '6GB'],
    storage: ['64GB', '128GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2022
  },
  {
    brand: 'Nokia',
    model: 'Nokia G42',
    ram: ['4GB', '6GB'],
    storage: ['128GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },

  // Oppo
  {
    brand: 'Oppo',
    model: 'Oppo Reno 11',
    ram: ['8GB', '12GB'],
    storage: ['256GB', '512GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2024
  },
  {
    brand: 'Oppo',
    model: 'Oppo A78',
    ram: ['8GB'],
    storage: ['128GB', '256GB'],
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400',
    releaseYear: 2023
  },
];

// Get all phone models with specs for autocomplete
export const getAllPhoneSpecs = (): Array<PhoneSpec & { fullName: string }> => {
  return phoneSpecsDatabase.map(phone => ({
    ...phone,
    fullName: `${phone.brand} ${phone.model}`
  }));
};

// Get specific phone spec by brand and model
export const getPhoneSpec = (brand: string, model: string): PhoneSpec | undefined => {
  return phoneSpecsDatabase.find(
    phone => phone.brand.toLowerCase() === brand.toLowerCase() && 
             phone.model.toLowerCase() === model.toLowerCase()
  );
};
