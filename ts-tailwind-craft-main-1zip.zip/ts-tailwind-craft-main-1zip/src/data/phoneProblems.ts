import { PhoneProblem } from '@/types';

// Banco de dados massivo de problemas técnicos profissionais
const displayProblems: PhoneProblem[] = [
  {
    id: 'display_001',
    title: 'Tela não liga / Tela preta',
    category: 'display',
    severity: 'critical',
    frequency: 95,
    summary: 'Display completamente apagado mesmo com aparelho ligado. Problema crítico que impede uso do dispositivo.',
    symptoms: ['Aparelho não liga', 'Tela preta mas aparelho faz som', 'Display apagado'],
    detailedSymptoms: [
      'Tela acende e apaga imediatamente',
      'Vibra mas não mostra imagem',
      'Luz de fundo (backlight) quebrada',
      'Apenas metade da tela acende',
      'Tela com brilho extremamente baixo',
      'A tela liga mas apaga ao abrir apps',
      'Display não responde mas touch funciona'
    ],
    causes: [
      { cause: 'Falha no backlight (luz de fundo)', probability: 35 },
      { cause: 'Curto na malha de display', probability: 25 },
      { cause: 'Oxidação na região do conector FPC', probability: 15 },
      { cause: 'Falha no IC de display (driver IC)', probability: 10 },
      { cause: 'Trilha rompida no flex do display', probability: 8 },
      { cause: 'Capacitor em curto na linha PP_VDD_MAIN', probability: 4 },
      { cause: 'Falha na PMIC (power IC)', probability: 2 },
      { cause: 'Solda fria no conector da tela', probability: 1 }
    ],
    diagnosticTests: [
      'Testar brilho com lanterna na tela',
      'Verificar vibração ao ligar',
      'Testar com outra tela compatível',
      'Medir consumo de corrente (amperagem)',
      'Verificar tensão no conector FPC',
      'Inspecionar placa por oxidação',
      'Teste de continuidade nas trilhas do flex'
    ],
    quickSolution: [
      'Carregar o aparelho por pelo menos 30 minutos',
      'Forçar reinicialização (segurar power + volume)',
      'Desconectar bateria e reconectar depois de 30 segundos',
      'Limpar conector FPC com álcool isopropílico 99%',
      'Reassentar o cabo flex do display'
    ],
    professionalSolution: [
      'Testar com display original conhecido como funcional',
      'Limpar conector FPC com isopropílico e escova antiestática',
      'Verificar continuidade das trilhas do flex com multímetro',
      'Medir tensão de alimentação do backlight (geralmente 18-24V)',
      'Diagnosticar IC de backlight com microscópio',
      'Verificar resistores e capacitores da linha de backlight',
      'Refluxo ou substituição do IC de display',
      'Microsolda para reparar trilhas rompidas',
      'Se necessário, substituir PMIC completo'
    ],
    requiredTools: [
      'Chaves de precisão (Pentalobe, Phillips, Torx)',
      'Multímetro digital',
      'Fonte de alimentação ajustável',
      'Microscópio estereoscópico',
      'Estação de solda quente',
      'Álcool isopropílico 99%',
      'Escova antiestática',
      'Pinça de precisão'
    ],
    requiredParts: [
      'Display LCD/OLED compatível',
      'Cabo flex do display',
      'IC de backlight (conforme modelo)',
      'Capacitores SMD',
      'Resistores SMD'
    ],
    repairRisks: [
      'Risco de danificar display original ao testar',
      'Possibilidade de curto na placa ao reconectar',
      'Perda de calibração do display após troca',
      'Risco de dano permanente ao IC durante refluxo'
    ],
    estimatedTime: '30min - 3h',
    estimatedCost: { min: 150, max: 800 },
    difficulty: 'moderate',
    warningNotes: [
      'Displays OLED são extremamente sensíveis a ESD',
      'Sempre desconectar bateria antes de manipular'
    ]
  },
  {
    id: 'display_002',
    title: 'Touch não funciona / Touch screen morto',
    category: 'display',
    severity: 'high',
    frequency: 88,
    summary: 'Tela não responde ao toque. Problema comum que impede interação com o dispositivo.',
    symptoms: ['Tela não responde ao toque', 'Touch travado', 'Alguns pontos não respondem'],
    detailedSymptoms: [
      'Touch completamente morto',
      'Touch funciona apenas em algumas áreas',
      'Touch fantasma (toca sozinho)',
      'Delay extremo no toque',
      'Multi-touch não funciona',
      'Touch funciona após reiniciar mas para depois',
      'Calibração do touch perdida'
    ],
    causes: [
      { cause: 'Digitizer (camada touch) danificado', probability: 40 },
      { cause: 'Cabo flex do touch desconectado', probability: 20 },
      { cause: 'IC controlador de touch com defeito', probability: 15 },
      { cause: 'Película protetora inadequada', probability: 10 },
      { cause: 'Problema de software/firmware', probability: 8 },
      { cause: 'Oxidação no conector FPC do touch', probability: 5 },
      { cause: 'Trilha rompida no circuito do touch', probability: 2 }
    ],
    diagnosticTests: [
      'Teste de calibração do touch',
      'Remover película/protetor temporariamente',
      'Testar em modo seguro (safe mode)',
      'Verificar reconhecimento do touch via ADB',
      'Teste de multitouch com app específico',
      'Inspecionar conector FPC do digitizer'
    ],
    quickSolution: [
      'Remover película/protetor de tela',
      'Limpar tela com pano de microfibra',
      'Reiniciar o aparelho',
      'Calibrar o touch nas configurações',
      'Limpar cache da partição de sistema'
    ],
    professionalSolution: [
      'Reassentar cabo flex do digitizer',
      'Limpar conector FPC com álcool isopropílico',
      'Verificar continuidade das trilhas do touch',
      'Atualizar/reinstalar firmware do touch IC',
      'Substituir apenas o digitizer (se possível)',
      'Substituir display completo com touch integrado',
      'Refluxo no IC controlador de touch',
      'Microsolda em trilhas danificadas'
    ],
    requiredTools: [
      'Kit de abertura (espátulas plásticas)',
      'Chaves de precisão',
      'Multímetro',
      'Microscópio (para inspeção)',
      'Estação de solda (casos avançados)',
      'Álcool isopropílico',
      'Pistola de calor controlada'
    ],
    requiredParts: [
      'Digitizer touch screen',
      'Display completo (se touch integrado)',
      'Cabo flex do touch',
      'IC controlador de touch'
    ],
    repairRisks: [
      'Separação de display pode quebrar LCD',
      'Risco de danificar bordas do frame',
      'Perda de resistência à água após abertura'
    ],
    estimatedTime: '20min - 2h',
    estimatedCost: { min: 120, max: 600 },
    difficulty: 'easy'
  },
  {
    id: 'display_003',
    title: 'Tela trincada / Display quebrado',
    category: 'display',
    severity: 'medium',
    frequency: 92,
    summary: 'Vidro do display fisicamente danificado por impacto ou queda.',
    symptoms: ['Vidro trincado', 'Display com rachaduras', 'Pedaços de vidro soltos'],
    detailedSymptoms: [
      'Trinca pequena em um canto',
      'Rachadura atravessando toda tela',
      'Vidro estilhaçado',
      'Touch funciona mas vidro quebrado',
      'LCD sangrando por baixo da trinca',
      'Tela preta mas vidro trincado visível'
    ],
    causes: [
      { cause: 'Queda do aparelho', probability: 80 },
      { cause: 'Impacto direto na tela', probability: 15 },
      { cause: 'Pressão excessiva no bolso', probability: 3 },
      { cause: 'Defeito de fabricação (raro)', probability: 2 }
    ],
    diagnosticTests: [
      'Verificar se touch ainda funciona',
      'Testar se LCD está vazando',
      'Verificar se apenas vidro ou display completo',
      'Avaliar necessidade de trocar só o vidro ou display inteiro'
    ],
    quickSolution: [
      'Aplicar película temporária para evitar cortes',
      'Evitar usar até trocar o display',
      'Fazer backup imediato dos dados'
    ],
    professionalSolution: [
      'Substituir display completo (recomendado)',
      'Separar vidro e trocar apenas vidro frontal (avançado)',
      'Laminação a vácuo para colar novo vidro',
      'Teste completo após substituição',
      'Calibração do touch se necessário'
    ],
    requiredTools: [
      'Kit de abertura',
      'Chaves específicas do modelo',
      'Pistola de calor / UV',
      'Máquina de laminação (para troca apenas de vidro)',
      'Adesivos de vedação'
    ],
    requiredParts: [
      'Display completo original/AAA',
      'Vidro frontal (se troca individual)',
      'Adesivo OCA ou LOCA',
      'Frame adesivo do display'
    ],
    repairRisks: [
      'Troca apenas de vidro é arriscada e pode danificar LCD',
      'Perda de impermeabilidade',
      'Displays não originais podem ter qualidade inferior'
    ],
    estimatedTime: '30min - 4h',
    estimatedCost: { min: 200, max: 1500 },
    difficulty: 'easy'
  },
  {
    id: 'display_004',
    title: 'Manchas na tela / Display com defeito de imagem',
    category: 'display',
    severity: 'medium',
    frequency: 65,
    summary: 'Display apresenta manchas, listras ou defeitos visuais sem dano físico aparente.',
    symptoms: ['Manchas escuras', 'Listras verticais', 'Pixels mortos'],
    detailedSymptoms: [
      'Mancha amarelada crescendo',
      'Listras coloridas verticais/horizontais',
      'Cluster de pixels mortos',
      'Ghosting (imagem fantasma)',
      'Tela com linhas intermitentes',
      'Imagem desbotada em uma região',
      'Sangramento de LCD (bleeding)'
    ],
    causes: [
      { cause: 'LCD danificado internamente', probability: 50 },
      { cause: 'Pressão excessiva sobre display', probability: 20 },
      { cause: 'Superaquecimento do aparelho', probability: 15 },
      { cause: 'Defeito de fabricação do LCD', probability: 10 },
      { cause: 'Oxidação/infiltração de líquido', probability: 5 }
    ],
    diagnosticTests: [
      'Teste de cores sólidas (vermelho, verde, azul)',
      'Verificar se mancha cresce com o tempo',
      'Testar sob diferentes temperaturas',
      'Verificar histórico de impactos'
    ],
    quickSolution: [
      'Reduzir brilho temporariamente',
      'Evitar pressão na área afetada',
      'Backup de dados urgente'
    ],
    professionalSolution: [
      'Substituir display completo',
      'Verificar e remover fontes de pressão interna',
      'Limpar oxidação se presente',
      'Testar com display conhecido funcional'
    ],
    requiredTools: [
      'Kit de abertura',
      'Chaves de precisão'
    ],
    requiredParts: [
      'Display LCD/OLED novo'
    ],
    repairRisks: [
      'Manchas podem se espalhar antes da troca'
    ],
    estimatedTime: '30min - 1h',
    estimatedCost: { min: 200, max: 1200 },
    difficulty: 'easy'
  },
  {
    id: 'display_005',
    title: 'Toque fantasma / Ghost touch',
    category: 'display',
    severity: 'high',
    frequency: 70,
    summary: 'Display registra toques que não foram realizados pelo usuário.',
    symptoms: ['Tela toca sozinha', 'Apps abrem sem tocar', 'Touch descontrolado'],
    detailedSymptoms: [
      'Toques aleatórios na tela',
      'Teclado digita sozinho',
      'Apps abrem e fecham sem comando',
      'Scroll automático',
      'Touch funciona mas com toques extras',
      'Problema piora com calor/umidade'
    ],
    causes: [
      { cause: 'Digitizer com defeito', probability: 40 },
      { cause: 'Interferência eletromagnética', probability: 25 },
      { cause: 'Umidade/oxidação no touch', probability: 15 },
      { cause: 'Carregador não original causando ruído', probability: 10 },
      { cause: 'Problema no IC controlador de touch', probability: 8 },
      { cause: 'Pressão interna sobre o display', probability: 2 }
    ],
    diagnosticTests: [
      'Testar sem carregador conectado',
      'Testar com outro carregador original',
      'Verificar se piora com aparelho quente',
      'Limpar tela completamente',
      'Teste em modo avião'
    ],
    quickSolution: [
      'Desconectar carregador e testar',
      'Limpar tela com álcool isopropílico',
      'Remover película/case temporariamente',
      'Reiniciar aparelho',
      'Recalibrar touch'
    ],
    professionalSolution: [
      'Trocar display/digitizer',
      'Limpar conector FPC do touch',
      'Verificar aterramento do display',
      'Substituir IC controlador de touch',
      'Verificar fonte de alimentação do touch',
      'Eliminar fontes de interferência eletromagnética'
    ],
    requiredTools: [
      'Kit de abertura',
      'Multímetro',
      'Álcool isopropílico',
      'Chaves de precisão'
    ],
    requiredParts: [
      'Display/digitizer novo',
      'IC controlador de touch (casos avançados)'
    ],
    repairRisks: [
      'Pode ser intermitente e difícil de diagnosticar'
    ],
    estimatedTime: '20min - 2h',
    estimatedCost: { min: 100, max: 600 },
    difficulty: 'moderate'
  }
];

const batteryProblems: PhoneProblem[] = [
  {
    id: 'battery_001',
    title: 'Bateria descarrega muito rápido',
    category: 'battery',
    severity: 'high',
    frequency: 95,
    summary: 'Autonomia da bateria drasticamente reduzida, durando poucas horas.',
    symptoms: ['Bateria dura poucas horas', 'Percentual cai rapidamente', 'Aquece muito ao usar'],
    detailedSymptoms: [
      'Bateria dura menos de 3 horas com uso normal',
      'Percentual cai 10% em poucos minutos',
      'Desliga com 20-30% de bateria ainda',
      'Bateria calibrada errada (pula percentuais)',
      'Consumo alto mesmo em standby',
      'Aquecimento excessivo durante uso',
      'Bateria incha levemente'
    ],
    causes: [
      { cause: 'Bateria viciada/degradada (>500 ciclos)', probability: 45 },
      { cause: 'Apps consumindo bateria em segundo plano', probability: 20 },
      { cause: 'Tela com brilho muito alto', probability: 10 },
      { cause: 'GPS/Bluetooth/WiFi sempre ativos', probability: 8 },
      { cause: 'Sistema operacional com bugs', probability: 7 },
      { cause: 'Bateria de má qualidade (não original)', probability: 5 },
      { cause: 'Curto interno na bateria', probability: 3 },
      { cause: 'Problema na placa lógica (consumo parasitário)', probability: 2 }
    ],
    diagnosticTests: [
      'Verificar health da bateria (apps específicos)',
      'Analisar estatísticas de uso de bateria',
      'Testar em modo avião',
      'Verificar ciclos de carga da bateria',
      'Medir tensão da bateria em repouso (3.7-4.2V)',
      'Teste de consumo em standby overnight'
    ],
    quickSolution: [
      'Verificar apps que mais consomem bateria',
      'Reduzir brilho da tela ao mínimo necessário',
      'Desativar GPS quando não usar',
      'Fechar apps em segundo plano',
      'Ativar modo economia de energia',
      'Desativar sincronização automática',
      'Calibrar bateria (descarregar 0% e carregar 100% sem interrupção)'
    ],
    professionalSolution: [
      'Verificar health: se <80%, substituir bateria',
      'Testar consumo de corrente da placa (amperagem)',
      'Limpar oxidação nos contatos da bateria',
      'Atualizar sistema operacional',
      'Reset de fábrica (backup antes)',
      'Substituir bateria por original de qualidade',
      'Investigar consumo parasitário na placa (avançado)',
      'Verificar IC de gerenciamento de energia (PMIC)'
    ],
    requiredTools: [
      'Chaves de precisão',
      'Espátula plástica',
      'Multímetro',
      'Fonte de alimentação',
      'Amperímetro'
    ],
    requiredParts: [
      'Bateria original ou equivalente AAA',
      'Adesivo dupla face para bateria'
    ],
    repairRisks: [
      'Baterias de lítio podem inflamar se perfuradas',
      'Risco de curto ao desconectar bateria',
      'Baterias não originais podem ter qualidade inferior'
    ],
    estimatedTime: '20min - 1h',
    estimatedCost: { min: 80, max: 350 },
    difficulty: 'easy',
    warningNotes: [
      'NUNCA perfure ou dobre a bateria',
      'Sempre descarregar bateria antes de remover (idealmente <50%)'
    ]
  },
  {
    id: 'battery_002',
    title: 'Não carrega / Carrega muito lento',
    category: 'battery',
    severity: 'critical',
    frequency: 90,
    summary: 'Dispositivo não reconhece carregador ou carregamento é extremamente lento.',
    symptoms: ['Não reconhece carregador', 'Carrega muito devagar', 'Para de carregar aleatoriamente'],
    detailedSymptoms: [
      'Carregador conectado mas não carrega',
      'Carrega 1% por hora (extremamente lento)',
      'Conecta e desconecta repetidamente',
      'Só carrega em ângulos específicos do cabo',
      'Carrega apenas desligado',
      'Ícone de carregamento não aparece',
      'Porta USB solta ou danificada'
    ],
    causes: [
      { cause: 'Conector de carga com defeito/solto', probability: 35 },
      { cause: 'Sujeira/oxidação no conector USB', probability: 25 },
      { cause: 'Cabo ou carregador danificado', probability: 20 },
      { cause: 'IC de carregamento com defeito', probability: 10 },
      { cause: 'Trilha rompida no circuito de carga', probability: 5 },
      { cause: 'Bateria em curto ou danificada', probability: 3 },
      { cause: 'Problema de software', probability: 2 }
    ],
    diagnosticTests: [
      'Testar com múltiplos cabos/carregadores originais',
      'Inspecionar porta USB com lupa/microscópio',
      'Verificar se reconhece quando conectado ao PC',
      'Medir tensão na entrada do conector (5V esperado)',
      'Testar carga wireless (se disponível)',
      'Verificar se carrega em modo recovery/bootloader'
    ],
    quickSolution: [
      'Limpar porta USB com palito/escova macia',
      'Soprar ar comprimido na porta',
      'Testar com cabo e carregador originais novos',
      'Remover sujeira acumulada no conector',
      'Reiniciar o aparelho',
      'Verificar se não há objeto estranho na porta'
    ],
    professionalSolution: [
      'Limpeza profunda do conector com álcool isopropílico',
      'Substituir conector de carga (flex dock)',
      'Verificar continuidade das trilhas de carga',
      'Testar tensão e corrente no IC de carga',
      'Substituir IC de carregamento (U2 em iPhones)',
      'Microsolda em trilhas danificadas',
      'Verificar fusíveis de proteção de carga',
      'Atualizar/reinstalar firmware'
    ],
    requiredTools: [
      'Kit de limpeza',
      'Chaves de precisão',
      'Multímetro',
      'Microscópio',
      'Estação de solda (casos avançados)',
      'Álcool isopropílico',
      'Escova antiestática'
    ],
    requiredParts: [
      'Flex dock / conector de carga',
      'IC de carregamento',
      'Fusíveis SMD (se necessário)'
    ],
    repairRisks: [
      'Limpeza agressiva pode danificar pinos do conector',
      'Troca de conector pode danificar trilhas da placa',
      'Microsolda requer expertise avançada'
    ],
    estimatedTime: '10min - 3h',
    estimatedCost: { min: 50, max: 400 },
    difficulty: 'easy'
  },
  {
    id: 'battery_003',
    title: 'Bateria inchada / Estufada',
    category: 'battery',
    severity: 'critical',
    frequency: 60,
    summary: 'Bateria expandiu fisicamente devido a gases internos. PERIGO DE INCÊNDIO.',
    symptoms: ['Bateria inchada visível', 'Tela levantando', 'Tampa traseira abaulada'],
    detailedSymptoms: [
      'Display começando a se soltar',
      'Tampa traseira levantada',
      'Bateria visivelmente inchada',
      'Aparelho não fecha corretamente',
      'Teclado elevado (notebooks)',
      'Smell de químico vindo da bateria'
    ],
    causes: [
      { cause: 'Bateria antiga/degradada (fim de vida)', probability: 50 },
      { cause: 'Superaquecimento repetido da bateria', probability: 25 },
      { cause: 'Defeito de fabricação da bateria', probability: 15 },
      { cause: 'Uso de carregador não original/inadequado', probability: 8 },
      { cause: 'Curto interno na bateria', probability: 2 }
    ],
    diagnosticTests: [
      'Inspeção visual da bateria (CUIDADO!)',
      'Verificar se display está se soltando',
      'Medir espessura da bateria'
    ],
    quickSolution: [
      'PARAR DE USAR O APARELHO IMEDIATAMENTE',
      'NÃO CARREGAR',
      'NÃO PERFURAR OU PRESSIONAR A BATERIA',
      'Desligar e remover de ambientes quentes',
      'Procurar assistência técnica URGENTE'
    ],
    professionalSolution: [
      'Trabalhar em área ventilada com extintor próximo',
      'Usar EPI (óculos, luvas)',
      'Desconectar bateria com EXTREMO CUIDADO',
      'Não dobrar ou perfurar a bateria',
      'Substituir bateria imediatamente',
      'Descartar bateria velha em local apropriado',
      'Inspecionar display e componentes por danos',
      'Verificar integridade da placa lógica'
    ],
    requiredTools: [
      'EPI de segurança',
      'Chaves de precisão',
      'Espátula plástica resistente',
      'Extintor de incêndio',
      'Recipiente à prova de fogo'
    ],
    requiredParts: [
      'Bateria nova original',
      'Display (se danificado pela expansão)',
      'Adesivos de vedação'
    ],
    repairRisks: [
      'RISCO DE INCÊNDIO ALTO',
      'RISCO DE EXPLOSÃO',
      'Gases tóxicos podem ser liberados',
      'Display pode estar comprometido'
    ],
    estimatedTime: '30min - 1h',
    estimatedCost: { min: 100, max: 400 },
    difficulty: 'moderate',
    warningNotes: [
      '⚠️ PERIGO: Bateria inchada pode pegar fogo ou explodir',
      '⚠️ NÃO TENTE CONSERTAR SEM CONHECIMENTO',
      '⚠️ Descarte em local apropriado para baterias de lítio'
    ]
  }
];

const chargingProblems: PhoneProblem[] = [
  {
    id: 'charging_001',
    title: 'Porta USB danificada / solta',
    category: 'charging',
    severity: 'high',
    frequency: 85,
    summary: 'Conector de carga fisicamente danificado ou com folga excessiva.',
    symptoms: ['Porta USB solta', 'Cabo não encaixa direito', 'Conecta e desconecta sozinho'],
    detailedSymptoms: [
      'Cabo entra mas não trava',
      'Precisa segurar cabo em ângulo específico',
      'Conector muito folgado',
      'Pinos do conector visívelmente tortos',
      'Conector saiu da placa',
      'Só carrega sem mover o aparelho'
    ],
    causes: [
      { cause: 'Uso incorreto ao conectar cabo', probability: 40 },
      { cause: 'Quedas com cabo conectado', probability: 30 },
      { cause: 'Desgaste natural por uso intenso', probability: 20 },
      { cause: 'Solda fria no conector', probability: 8 },
      { cause: 'Qualidade ruim do conector (não original)', probability: 2 }
    ],
    diagnosticTests: [
      'Inspeção visual da porta USB',
      'Verificar folga do conector',
      'Testar com diferentes cabos',
      'Verificar pinos com microscópio',
      'Teste de continuidade dos pinos'
    ],
    quickSolution: [
      'Cuidado ao conectar/desconectar cabo',
      'Limpar porta de sujeira',
      'Usar carga wireless se disponível',
      'Evitar mexer no aparelho enquanto carrega'
    ],
    professionalSolution: [
      'Substituir flex dock completo',
      'Resoldar conector USB na placa',
      'Endireitar pinos tortos (cuidado!)',
      'Reforçar solda do conector',
      'Limpar pads de solda e refazer'
    ],
    requiredTools: [
      'Chaves de precisão',
      'Microscópio',
      'Estação de solda',
      'Ferro de solda fino',
      'Fluxo de solda'
    ],
    requiredParts: [
      'Flex dock / conector USB',
      'Conector USB avulso'
    ],
    repairRisks: [
      'Trilhas da placa podem se soltar durante remoção',
      'Pads de solda podem descolar'
    ],
    estimatedTime: '20min - 1h30',
    estimatedCost: { min: 60, max: 200 },
    difficulty: 'moderate'
  }
];

const cameraProblems: PhoneProblem[] = [
  {
    id: 'camera_001',
    title: 'Câmera não funciona / Tela preta',
    category: 'camera',
    severity: 'high',
    frequency: 80,
    summary: 'App da câmera abre mas exibe tela preta ou não inicia.',
    symptoms: ['Câmera abre mas tela preta', 'App da câmera fecha sozinho', 'Câmera travada'],
    detailedSymptoms: [
      'Tela preta ao abrir câmera',
      'App de câmera crasha imediatamente',
      'Apenas uma câmera funciona (frontal ou traseira)',
      'Câmera funciona em alguns apps mas não em outros',
      'Imagem congelada na câmera',
      'Erro "Não é possível conectar à câmera"'
    ],
    causes: [
      { cause: 'Módulo da câmera com defeito', probability: 35 },
      { cause: 'Cabo flex da câmera desconectado', probability: 25 },
      { cause: 'Problema de software/cache', probability: 20 },
      { cause: 'IC controlador de câmera com defeito', probability: 10 },
      { cause: 'Trilha rompida no circuito da câmera', probability: 5 },
      { cause: 'Permissões de app bloqueadas', probability: 5 }
    ],
    diagnosticTests: [
      'Testar câmera frontal e traseira separadamente',
      'Verificar em diferentes apps de câmera',
      'Limpar cache do app de câmera',
      'Testar em modo seguro',
      'Verificar permissões da câmera',
      'Inspecionar cabo flex da câmera'
    ],
    quickSolution: [
      'Reiniciar o aparelho',
      'Limpar cache do app de câmera',
      'Forçar parada do app de câmera',
      'Verificar permissões nas configurações',
      'Atualizar sistema operacional',
      'Limpar lente da câmera'
    ],
    professionalSolution: [
      'Reconectar cabo flex da câmera',
      'Substituir módulo da câmera defeituoso',
      'Limpar conector da câmera',
      'Verificar tensão de alimentação da câmera',
      'Substituir IC controlador (avançado)',
      'Reinstalar firmware',
      'Verificar trilhas do circuito da câmera'
    ],
    requiredTools: [
      'Chaves de precisão',
      'Espátula plástica',
      'Multímetro',
      'Microscópio (casos avançados)'
    ],
    requiredParts: [
      'Módulo de câmera traseira/frontal',
      'Cabo flex da câmera'
    ],
    repairRisks: [
      'Módulos de câmera são sensíveis a ESD',
      'Reconexão incorreta pode danificar conector'
    ],
    estimatedTime: '20min - 1h30',
    estimatedCost: { min: 80, max: 400 },
    difficulty: 'easy'
  },
  {
    id: 'camera_002',
    title: 'Fotos tremidas / Foco não funciona',
    category: 'camera',
    severity: 'medium',
    frequency: 70,
    summary: 'Sistema de autofoco não opera corretamente, resultando em fotos borradas.',
    symptoms: ['Fotos sempre borradas', 'Foco não ajusta', 'Imagem tremida'],
    detailedSymptoms: [
      'Câmera não foca em nenhuma distância',
      'Foco funciona mas muito lento',
      'Barulho estranho ao tentar focar',
      'Foco funciona às vezes',
      'OIS (estabilização) não funciona',
      'Vídeos tremidos excessivamente'
    ],
    causes: [
      { cause: 'Atuador de autofoco danificado', probability: 40 },
      { cause: 'Lente da câmera suja/embaçada', probability: 25 },
      { cause: 'Sistema OIS com defeito', probability: 15 },
      { cause: 'Software de câmera com bug', probability: 10 },
      { cause: 'Vibração/choque danificou mecanismo', probability: 8 },
      { cause: 'Sensor da câmera desalinhado', probability: 2 }
    ],
    diagnosticTests: [
      'Limpar lente externa',
      'Testar foco em diferentes distâncias',
      'Escutar sons anormais da câmera',
      'Testar OIS em apps específicos',
      'Comparar com câmera frontal'
    ],
    quickSolution: [
      'Limpar lente com pano de microfibra',
      'Remover película da câmera',
      'Tocar na tela para forçar foco manual',
      'Reiniciar app de câmera',
      'Atualizar sistema',
      'Testar em boa iluminação'
    ],
    professionalSolution: [
      'Limpar lente interna da câmera',
      'Substituir módulo de câmera completo',
      'Calibrar autofoco via software',
      'Verificar e limpar lentes internas',
      'Substituir atuador de AF',
      'Recalibrar OIS'
    ],
    requiredTools: [
      'Chaves de precisão',
      'Pano de microfibra',
      'Álcool isopropílico',
      'Kit de limpeza de lentes'
    ],
    requiredParts: [
      'Módulo de câmera',
      'Atuador de autofoco'
    ],
    repairRisks: [
      'Desmontagem pode introduzir poeira nas lentes',
      'Calibração incorreta pode piorar'
    ],
    estimatedTime: '30min - 1h',
    estimatedCost: { min: 100, max: 450 },
    difficulty: 'moderate'
  }
];

const networkProblems: PhoneProblem[] = [
  {
    id: 'network_001',
    title: 'Sem sinal / Sem serviço',
    category: 'network',
    severity: 'critical',
    frequency: 85,
    summary: 'Aparelho não conecta à rede celular, impossibilitando chamadas e dados móveis.',
    symptoms: ['Sem sinal de operadora', 'Sempre em modo avião', 'Não encontra redes'],
    detailedSymptoms: [
      'Exibe "Sem serviço" permanentemente',
      'IMEI nulo ou inválido',
      'Não detecta chip SIM',
      'Sinal aparece e desaparece constantemente',
      'Conecta apenas em 2G',
      'Sinal zero em locais com cobertura',
      'Modo avião não desativa'
    ],
    causes: [
      { cause: 'Antena celular danificada/desconectada', probability: 30 },
      { cause: 'IMEI corrompido/perdido', probability: 25 },
      { cause: 'IC de RF (rádio frequência) com defeito', probability: 20 },
      { cause: 'Cabo coaxial da antena rompido', probability: 10 },
      { cause: 'Problema no slot do chip SIM', probability: 8 },
      { cause: 'Software/baseband corrompido', probability: 5 },
      { cause: 'Trilha rompida no circuito RF', probability: 2 }
    ],
    diagnosticTests: [
      'Verificar IMEI (*#06#)',
      'Testar com chip de outra operadora',
      'Verificar em modo teste de campo (*#*#4636#*#*)',
      'Inspecionar antena e cabo coaxial',
      'Testar reconhecimento do chip SIM',
      'Verificar versão do baseband'
    ],
    quickSolution: [
      'Reinserir chip SIM',
      'Reiniciar o aparelho',
      'Alternar modo avião on/off',
      'Selecionar operadora manualmente',
      'Resetar configurações de rede',
      'Atualizar sistema operacional',
      'Limpar contatos do chip SIM'
    ],
    professionalSolution: [
      'Verificar continuidade da antena com multímetro',
      'Reconectar cabo coaxial da antena',
      'Substituir módulo da antena celular',
      'Refluxo no IC de RF/baseband',
      'Reparar/reescrever IMEI (onde legalmente permitido)',
      'Substituir IC PAM (power amplifier module)',
      'Microsolda em trilhas RF danificadas',
      'Reinstalar firmware/baseband'
    ],
    requiredTools: [
      'Chaves de precisão',
      'Multímetro',
      'Microscópio',
      'Estação de solda quente',
      'Analisador de espectro (avançado)',
      'Software de flash/programação'
    ],
    requiredParts: [
      'Antena celular',
      'Cabo coaxial',
      'IC de RF/baseband',
      'IC PAM',
      'Slot de SIM'
    ],
    repairRisks: [
      'Reparo de RF é extremamente avançado',
      'IMEI corrompido pode ser irrecuperável',
      'Reescrita de IMEI é ilegal em muitos países',
      'Risco de dano permanente ao IC de RF'
    ],
    estimatedTime: '1h - 6h',
    estimatedCost: { min: 150, max: 900 },
    difficulty: 'difficult',
    warningNotes: [
      'Reparo de RF requer experiência avançada',
      'Nunca tente reescrever IMEI sem autorização legal'
    ]
  },
  {
    id: 'network_002',
    title: 'Wi-Fi não conecta / Wi-Fi cinza',
    category: 'network',
    severity: 'high',
    frequency: 75,
    summary: 'Wi-Fi não liga, aparece cinza/desabilitado ou não conecta às redes.',
    symptoms: ['Wi-Fi não liga', 'Botão Wi-Fi cinza', 'Não encontra redes Wi-Fi'],
    detailedSymptoms: [
      'Botão Wi-Fi não responde',
      'Wi-Fi desativa sozinho',
      'Encontra redes mas não conecta',
      'Conecta mas sem internet',
      'Endereço MAC do Wi-Fi "não disponível"',
      'Wi-Fi muito lento',
      'Desconecta constantemente'
    ],
    causes: [
      { cause: 'IC de Wi-Fi com defeito', probability: 40 },
      { cause: 'Solda fria no chip Wi-Fi', probability: 25 },
      { cause: 'Antena Wi-Fi danificada', probability: 15 },
      { cause: 'Firmware Wi-Fi corrompido', probability: 10 },
      { cause: 'Superaquecimento danificou chip', probability: 8 },
      { cause: 'Oxidação na região do Wi-Fi IC', probability: 2 }
    ],
    diagnosticTests: [
      'Verificar endereço MAC do Wi-Fi',
      'Testar em diferentes redes',
      'Verificar se esquenta na região do IC Wi-Fi',
      'Teste com router em diferentes canais',
      'Verificar logs de sistema'
    ],
    quickSolution: [
      'Reiniciar aparelho e router',
      'Esquecer rede e reconectar',
      'Resetar configurações de rede',
      'Atualizar sistema operacional',
      'Desativar economia de energia do Wi-Fi',
      'Mudar canal do router (2.4GHz ou 5GHz)'
    ],
    professionalSolution: [
      'Refluxo no IC de Wi-Fi (BGA)',
      'Reball do chip Wi-Fi',
      'Substituir IC Wi-Fi completo',
      'Verificar antena Wi-Fi e cabo coaxial',
      'Limpar oxidação ao redor do chip',
      'Aplicar thermal pad se superaquecimento',
      'Reinstalar firmware Wi-Fi via JTAG (avançado)'
    ],
    requiredTools: [
      'Estação de solda BGA',
      'Microscópio',
      'Thermal camera (opcional)',
      'Multímetro',
      'Flux e pasta de solda'
    ],
    requiredParts: [
      'IC de Wi-Fi/Bluetooth',
      'Antena Wi-Fi',
      'Thermal pad'
    ],
    repairRisks: [
      'Refluxo pode danificar ICs adjacentes',
      'Reball mal feito pode piorar o problema',
      'IC de Wi-Fi pode estar soldado sob outros componentes'
    ],
    estimatedTime: '2h - 5h',
    estimatedCost: { min: 200, max: 800 },
    difficulty: 'difficult',
    warningNotes: [
      'Reparo de IC Wi-Fi requer equipamento BGA profissional'
    ]
  },
  {
    id: 'network_003',
    title: 'Bluetooth não funciona / Não pareia',
    category: 'network',
    severity: 'medium',
    frequency: 60,
    summary: 'Bluetooth não liga, não encontra dispositivos ou não consegue parear.',
    symptoms: ['Bluetooth não liga', 'Não encontra dispositivos', 'Pareamento falha'],
    detailedSymptoms: [
      'Botão Bluetooth não responde',
      'Bluetooth liga mas não detecta nada',
      'Pareia mas não conecta',
      'Áudio Bluetooth com falhas',
      'Desconecta sozinho frequentemente',
      'Nome do dispositivo não aparece'
    ],
    causes: [
      { cause: 'IC de Bluetooth com defeito (geralmente compartilhado com Wi-Fi)', probability: 45 },
      { cause: 'Software/driver corrompido', probability: 25 },
      { cause: 'Antena Bluetooth danificada', probability: 15 },
      { cause: 'Interferência de outros dispositivos', probability: 10 },
      { cause: 'Cache Bluetooth corrompido', probability: 5 }
    ],
    diagnosticTests: [
      'Verificar endereço MAC Bluetooth',
      'Testar com diferentes dispositivos BT',
      'Limpar cache Bluetooth',
      'Testar em modo seguro'
    ],
    quickSolution: [
      'Reiniciar Bluetooth',
      'Esquecer dispositivos pareados',
      'Limpar cache do serviço Bluetooth',
      'Resetar configurações de rede',
      'Atualizar sistema'
    ],
    professionalSolution: [
      'Refluxo no IC Wi-Fi/Bluetooth',
      'Substituir IC combinado Wi-Fi/BT',
      'Verificar antena Bluetooth',
      'Reinstalar firmware Bluetooth'
    ],
    requiredTools: [
      'Estação de solda BGA',
      'Microscópio',
      'Multímetro'
    ],
    requiredParts: [
      'IC Wi-Fi/Bluetooth combinado',
      'Antena'
    ],
    repairRisks: [
      'Mesmo IC geralmente controla Wi-Fi e Bluetooth'
    ],
    estimatedTime: '2h - 5h',
    estimatedCost: { min: 200, max: 800 },
    difficulty: 'difficult'
  },
  {
    id: 'network_004',
    title: 'GPS não funciona / Localização imprecisa',
    category: 'network',
    severity: 'medium',
    frequency: 55,
    summary: 'GPS não consegue obter localização ou posição muito imprecisa.',
    symptoms: ['GPS não fixa posição', 'Localização errada', 'Apps de mapa não funcionam'],
    detailedSymptoms: [
      'GPS procurando eternamente',
      'Posição a quilômetros de distância',
      'GPS funciona apenas com Wi-Fi ativo',
      'Demora muito para fixar posição',
      'Perde sinal GPS constantemente',
      'Precisão acima de 100 metros'
    ],
    causes: [
      { cause: 'Antena GPS danificada/desconectada', probability: 35 },
      { cause: 'Permissões de localização incorretas', probability: 20 },
      { cause: 'Dados A-GPS desatualizados', probability: 15 },
      { cause: 'IC de GPS com defeito', probability: 15 },
      { cause: 'Interferência de case metálico', probability: 10 },
      { cause: 'Software/firmware de GPS corrompido', probability: 5 }
    ],
    diagnosticTests: [
      'Testar em área aberta (céu visível)',
      'Verificar permissões de localização',
      'Testar com apps de teste GPS',
      'Verificar quantidade de satélites detectados',
      'Remover case temporariamente'
    ],
    quickSolution: [
      'Recalibrar bússola (movimento em 8)',
      'Limpar dados A-GPS',
      'Ativar "Alta precisão" em localização',
      'Atualizar dados A-GPS',
      'Verificar permissões de apps',
      'Usar ao ar livre por 5-10 minutos'
    ],
    professionalSolution: [
      'Verificar continuidade da antena GPS',
      'Reconectar antena GPS',
      'Substituir módulo de antena GPS',
      'Refluxo no IC de GPS',
      'Verificar alimentação do chip GPS',
      'Reinstalar firmware GPS'
    ],
    requiredTools: [
      'Chaves de precisão',
      'Multímetro',
      'App de teste GPS'
    ],
    requiredParts: [
      'Antena GPS',
      'IC GPS (se separado)'
    ],
    repairRisks: [
      'Antena GPS geralmente é pequena e frágil'
    ],
    estimatedTime: '30min - 3h',
    estimatedCost: { min: 100, max: 500 },
    difficulty: 'moderate'
  },
  {
    id: 'network_005',
    title: 'Internet móvel não funciona / Dados móveis off',
    category: 'network',
    severity: 'high',
    frequency: 70,
    summary: 'Dados móveis (3G/4G/5G) não funcionam mesmo com plano ativo.',
    symptoms: ['Sem internet móvel', 'Dados móveis não ativam', 'Apenas Wi-Fi funciona'],
    detailedSymptoms: [
      'Ícone de dados móveis não aparece',
      'Conecta à operadora mas sem internet',
      'Internet funciona apenas em Wi-Fi',
      'APN não salva',
      'Velocidade extremamente baixa',
      'Apenas 2G funciona (3G/4G não)'
    ],
    causes: [
      { cause: 'APN configurado incorretamente', probability: 35 },
      { cause: 'Dados móveis desativados nas configurações', probability: 25 },
      { cause: 'Plano de dados esgotado/bloqueado', probability: 20 },
      { cause: 'Problema na operadora', probability: 10 },
      { cause: 'Software corrompido', probability: 8 },
      { cause: 'Hardware (antena/IC RF)', probability: 2 }
    ],
    diagnosticTests: [
      'Verificar se dados móveis estão ativados',
      'Verificar plano de dados com operadora',
      'Testar chip em outro aparelho',
      'Verificar configurações APN',
      'Verificar cobertura 4G na região'
    ],
    quickSolution: [
      'Ativar dados móveis nas configurações',
      'Configurar APN corretamente (buscar no Google)',
      'Resetar configurações de rede',
      'Reinserir chip SIM',
      'Alternar modo avião',
      'Selecionar operadora manualmente',
      'Verificar saldo/plano com operadora'
    ],
    professionalSolution: [
      'Reconfigurar APN via código da operadora',
      'Atualizar perfil de operadora',
      'Verificar IMEI e compatibilidade 4G',
      'Reinstalar firmware',
      'Verificar antena e IC RF (caso hardware)'
    ],
    requiredTools: [
      'Configurações de APN',
      'Contato com operadora'
    ],
    requiredParts: [
      'Normalmente não requer peças'
    ],
    repairRisks: [
      'Geralmente é problema de configuração, não hardware'
    ],
    estimatedTime: '10min - 1h',
    estimatedCost: { min: 0, max: 50 },
    difficulty: 'easy'
  },
  {
    id: 'network_006',
    title: 'Chamadas caem / Não consegue fazer ligações',
    category: 'network',
    severity: 'high',
    frequency: 65,
    summary: 'Chamadas telefônicas falham, caem ou não completam.',
    symptoms: ['Chamadas caem no meio', 'Não completa ligação', 'Não recebe chamadas'],
    detailedSymptoms: [
      'Ligação cai após segundos',
      'Não consegue discar para nenhum número',
      'Recebe mas não consegue fazer chamadas',
      'Áudio muito baixo ou inexistente',
      'Eco ou ruído durante chamada',
      'Chamadas vão direto para caixa postal'
    ],
    causes: [
      { cause: 'Problema na operadora/cobertura', probability: 30 },
      { cause: 'Microfone ou alto-falante defeituoso', probability: 25 },
      { cause: 'Antena celular com problema', probability: 20 },
      { cause: 'Configuração de rede incorreta', probability: 15 },
      { cause: 'Software/firmware corrompido', probability: 8 },
      { cause: 'IC de áudio com defeito', probability: 2 }
    ],
    diagnosticTests: [
      'Testar em diferentes locais (cobertura)',
      'Fazer chamada de teste',
      'Verificar microfone e alto-falante',
      'Testar com outro chip',
      'Gravar áudio para testar microfone'
    ],
    quickSolution: [
      'Reiniciar o aparelho',
      'Alternar modo avião',
      'Verificar não perturbe/bloqueios',
      'Limpar microfone e alto-falante',
      'Resetar configurações de rede',
      'Atualizar sistema'
    ],
    professionalSolution: [
      'Verificar e limpar microfone',
      'Testar e substituir alto-falante auricular',
      'Verificar antena celular',
      'Reinstalar firmware',
      'Verificar IC de áudio',
      'Verificar trilhas de microfone'
    ],
    requiredTools: [
      'Chaves de precisão',
      'Multímetro',
      'Microscópio'
    ],
    requiredParts: [
      'Microfone',
      'Alto-falante auricular',
      'Antena celular'
    ],
    repairRisks: [
      'Problema pode ser da operadora, não do aparelho'
    ],
    estimatedTime: '20min - 2h',
    estimatedCost: { min: 50, max: 400 },
    difficulty: 'moderate'
  },
  {
    id: 'network_007',
    title: 'NFC não funciona',
    category: 'network',
    severity: 'low',
    frequency: 40,
    summary: 'NFC não detecta tags ou não funciona para pagamentos.',
    symptoms: ['NFC não lê tags', 'Pagamento por aproximação falha', 'NFC desativado'],
    detailedSymptoms: [
      'Botão NFC não ativa',
      'NFC ativo mas não detecta nada',
      'Funciona apenas muito próximo',
      'Apps de pagamento não reconhecem NFC',
      'NFC funcionava antes mas parou'
    ],
    causes: [
      { cause: 'Antena NFC danificada/descolada', probability: 45 },
      { cause: 'NFC desativado nas configurações', probability: 25 },
      { cause: 'IC de NFC com defeito', probability: 15 },
      { cause: 'Case metálico interferindo', probability: 10 },
      { cause: 'Software/app de pagamento com problema', probability: 5 }
    ],
    diagnosticTests: [
      'Verificar se NFC está ativado',
      'Testar com diferentes tags NFC',
      'Remover case temporariamente',
      'Testar apps de pagamento',
      'Verificar com outro aparelho a mesma tag'
    ],
    quickSolution: [
      'Ativar NFC nas configurações',
      'Reiniciar aparelho',
      'Remover case metálico',
      'Reconfigurar app de pagamento',
      'Posicionar corretamente (parte traseira)'
    ],
    professionalSolution: [
      'Verificar antena NFC (geralmente adesiva)',
      'Recolar antena NFC',
      'Substituir módulo NFC',
      'Verificar conexão da antena com placa',
      'Substituir IC NFC'
    ],
    requiredTools: [
      'Chaves de precisão',
      'Tag NFC de teste',
      'Adesivo condutor'
    ],
    requiredParts: [
      'Antena NFC',
      'IC NFC'
    ],
    repairRisks: [
      'Antena NFC é delicada e pode rasgar'
    ],
    estimatedTime: '15min - 1h',
    estimatedCost: { min: 30, max: 200 },
    difficulty: 'easy'
  }
];

const audioProblems: PhoneProblem[] = [
  {
    id: 'audio_001',
    title: 'Alto-falante não funciona / Sem som',
    category: 'audio',
    severity: 'high',
    frequency: 80,
    summary: 'Som do alto-falante principal (multimídia) não funciona ou muito baixo.',
    symptoms: ['Sem som no alto-falante', 'Som muito baixo', 'Som chiado/distorcido'],
    detailedSymptoms: [
      'Alto-falante completamente mudo',
      'Som sai apenas do auricular',
      'Volume máximo muito baixo',
      'Som distorcido ou chiado',
      'Som funciona com fone mas não no alto-falante',
      'Som corta intermitente',
      'Som mono (apenas um lado funciona)'
    ],
    causes: [
      { cause: 'Alto-falante queimado/danificado', probability: 45 },
      { cause: 'Sujeira/água no alto-falante', probability: 20 },
      { cause: 'Contato do alto-falante sujo/oxidado', probability: 15 },
      { cause: 'IC de áudio com defeito', probability: 10 },
      { cause: 'Software/volume limitado', probability: 8 },
      { cause: 'Trilha rompida no circuito de áudio', probability: 2 }
    ],
    diagnosticTests: [
      'Testar volume máximo',
      'Tocar música/vídeo',
      'Verificar em modo seguro',
      'Testar com fone (se funciona, problema no alto-falante)',
      'Inspecionar visualmente o alto-falante',
      'Verificar se há líquido/oxidação'
    ],
    quickSolution: [
      'Aumentar volume ao máximo',
      'Desativar "Não perturbe"',
      'Reiniciar aparelho',
      'Limpar grade do alto-falante com escova',
      'Verificar se fone não está conectado',
      'Limpar cache de áudio/mídia',
      'Resetar configurações de som'
    ],
    professionalSolution: [
      'Substituir alto-falante principal',
      'Limpar contatos do alto-falante com álcool isopropílico',
      'Verificar continuidade com multímetro',
      'Limpar oxidação nos contatos',
      'Verificar tensão no conector do alto-falante',
      'Substituir IC de áudio (avançado)',
      'Reparar trilhas rompidas (microsolda)'
    ],
    requiredTools: [
      'Chaves de precisão',
      'Espátula plástica',
      'Multímetro',
      'Álcool isopropílico',
      'Escova antiestática'
    ],
    requiredParts: [
      'Alto-falante principal (speaker)',
      'IC de áudio (casos avançados)'
    ],
    repairRisks: [
      'Alto-falantes são delicados e fáceis de danificar',
      'Contatos podem ser difíceis de limpar sem dano'
    ],
    estimatedTime: '15min - 1h',
    estimatedCost: { min: 40, max: 250 },
    difficulty: 'easy'
  },
  {
    id: 'audio_002',
    title: 'Microfone não funciona / Não escutam',
    category: 'audio',
    severity: 'critical',
    frequency: 75,
    summary: 'Microfone não capta áudio em chamadas, gravações ou comandos de voz.',
    symptoms: ['Não escutam em ligações', 'Gravação sem áudio', 'Assistente de voz não funciona'],
    detailedSymptoms: [
      'Ninguém escuta em ligações',
      'Gravação de áudio sem som',
      'Comandos de voz não funcionam',
      'Áudio muito baixo no microfone',
      'Áudio cortado/intermitente',
      'Ruído/chiado no microfone',
      'Funciona em viva-voz mas não normal'
    ],
    causes: [
      { cause: 'Microfone obstruído (sujeira/película)', probability: 30 },
      { cause: 'Microfone danificado/queimado', probability: 25 },
      { cause: 'Contato do microfone sujo/oxidado', probability: 20 },
      { cause: 'Problema de software/permissões', probability: 15 },
      { cause: 'IC de áudio com defeito', probability: 8 },
      { cause: 'Trilha rompida no circuito do microfone', probability: 2 }
    ],
    diagnosticTests: [
      'Gravar áudio e reproduzir',
      'Testar comando de voz (Google Assistant/Siri)',
      'Fazer chamada teste',
      'Verificar permissões de microfone nos apps',
      'Testar em modo seguro',
      'Inspecionar grade do microfone'
    ],
    quickSolution: [
      'Limpar grade do microfone com escova macia',
      'Remover película protetora do microfone',
      'Soprar ar comprimido no microfone',
      'Reiniciar aparelho',
      'Verificar permissões de microfone',
      'Desativar cancelamento de ruído',
      'Testar sem case/capa'
    ],
    professionalSolution: [
      'Substituir microfone principal',
      'Limpar contatos com álcool isopropílico',
      'Verificar continuidade com multímetro',
      'Limpar oxidação',
      'Verificar tensão no conector',
      'Substituir módulo de microfone completo',
      'Verificar e reparar trilhas (microsolda)',
      'Substituir IC de áudio'
    ],
    requiredTools: [
      'Chaves de precisão',
      'Multímetro',
      'Microscópio',
      'Álcool isopropílico',
      'Escova'
    ],
    requiredParts: [
      'Microfone (MEMS microphone)',
      'Módulo de microfone',
      'IC de áudio'
    ],
    repairRisks: [
      'Microfones MEMS são extremamente sensíveis',
      'Solda pode ser difícil devido ao tamanho'
    ],
    estimatedTime: '20min - 1h30',
    estimatedCost: { min: 50, max: 300 },
    difficulty: 'easy',
    warningNotes: [
      'Sempre verifique permissões de app antes de abrir o aparelho'
    ]
  },
  {
    id: 'audio_003',
    title: 'Alto-falante auricular não funciona',
    category: 'audio',
    severity: 'high',
    frequency: 70,
    summary: 'Alto-falante da orelha (chamadas) não emite som ou muito baixo.',
    symptoms: ['Não escuta em chamadas', 'Som baixo no auricular', 'Auricular mudo'],
    detailedSymptoms: [
      'Não escuta a outra pessoa',
      'Apenas viva-voz funciona',
      'Som do auricular extremamente baixo',
      'Som distorcido no ouvido',
      'Som corta durante chamada',
      'Auricular funciona às vezes'
    ],
    causes: [
      { cause: 'Alto-falante auricular danificado', probability: 40 },
      { cause: 'Sujeira/cera bloqueando grade', probability: 30 },
      { cause: 'Contato sujo/oxidado', probability: 15 },
      { cause: 'Película protetora bloqueando', probability: 10 },
      { cause: 'IC de áudio com defeito', probability: 5 }
    ],
    diagnosticTests: [
      'Fazer chamada de teste',
      'Aumentar volume durante chamada',
      'Inspecionar grade do auricular',
      'Testar em viva-voz (se funciona, problema no auricular)',
      'Limpar e testar novamente'
    ],
    quickSolution: [
      'Limpar grade com escova de dente macia',
      'Remover película protetora da grade',
      'Soprar ar comprimido',
      'Aumentar volume durante chamada',
      'Usar cotonete com álcool (delicadamente)',
      'Ativar "Amplificador de áudio" nas acessibilidades'
    ],
    professionalSolution: [
      'Substituir alto-falante auricular',
      'Limpar profundamente a grade',
      'Limpar contatos com álcool isopropílico',
      'Verificar continuidade',
      'Substituir módulo completo',
      'Verificar IC de áudio'
    ],
    requiredTools: [
      'Chaves de precisão',
      'Escova macia',
      'Multímetro',
      'Álcool isopropílico'
    ],
    requiredParts: [
      'Alto-falante auricular (earpiece speaker)'
    ],
    repairRisks: [
      'Grade pode estar muito entupida e difícil de limpar',
      'Excesso de força pode danificar'
    ],
    estimatedTime: '15min - 1h',
    estimatedCost: { min: 40, max: 200 },
    difficulty: 'easy'
  },
  {
    id: 'audio_004',
    title: 'Entrada de fone não funciona / Jack P2',
    category: 'audio',
    severity: 'medium',
    frequency: 50,
    summary: 'Fone de ouvido não é reconhecido ou áudio sai apenas do alto-falante.',
    symptoms: ['Fone não reconhecido', 'Áudio sai no alto-falante com fone conectado', 'Um lado do fone não funciona'],
    detailedSymptoms: [
      'Fone conectado mas som no alto-falante',
      'Apenas um lado do fone funciona',
      'Áudio corta ao mexer no plug',
      'Fone reconhecido mas sem som',
      'Microfone do fone não funciona',
      'Aparelho trava ao conectar fone'
    ],
    causes: [
      { cause: 'Conector P2 com sujeira/oxidação', probability: 40 },
      { cause: 'Conector P2 danificado/solto', probability: 30 },
      { cause: 'Contato interno quebrado', probability: 15 },
      { cause: 'Problema de software', probability: 10 },
      { cause: 'IC de áudio com defeito', probability: 5 }
    ],
    diagnosticTests: [
      'Testar com múltiplos fones',
      'Conectar e desconectar várias vezes',
      'Girar o plug enquanto conectado',
      'Verificar se aparelho detecta fone',
      'Inspecionar visualmente o conector',
      'Testar fone Bluetooth (para isolar hardware)'
    ],
    quickSolution: [
      'Limpar conector com palito/cotonete',
      'Soprar ar comprimido no conector',
      'Conectar e desconectar várias vezes',
      'Reiniciar aparelho com fone conectado',
      'Limpar cache de áudio',
      'Testar com fone diferente'
    ],
    professionalSolution: [
      'Limpar conector P2 com álcool isopropílico',
      'Substituir conector P2 completo',
      'Soldar contatos internos do jack',
      'Verificar continuidade dos pinos',
      'Substituir IC de áudio (se necessário)',
      'Limpar oxidação profunda'
    ],
    requiredTools: [
      'Chaves de precisão',
      'Estação de solda',
      'Multímetro',
      'Álcool isopropílico',
      'Sugador de solda'
    ],
    requiredParts: [
      'Conector P2 / jack de áudio',
      'Módulo de áudio (se integrado)'
    ],
    repairRisks: [
      'Conector P2 pode estar soldado na placa principal',
      'Muitos aparelhos não têm mais jack P2'
    ],
    estimatedTime: '30min - 2h',
    estimatedCost: { min: 60, max: 300 },
    difficulty: 'moderate',
    warningNotes: [
      'Muitos aparelhos modernos removeram o jack P2 (use adaptador USB-C)'
    ]
  },
  {
    id: 'audio_005',
    title: 'Áudio Bluetooth com falhas / Corta',
    category: 'audio',
    severity: 'medium',
    frequency: 60,
    summary: 'Áudio via Bluetooth apresenta cortes, atraso ou qualidade ruim.',
    symptoms: ['Áudio Bluetooth cortando', 'Atraso no áudio', 'Qualidade ruim'],
    detailedSymptoms: [
      'Áudio Bluetooth corta a cada poucos segundos',
      'Delay perceptível entre vídeo e áudio',
      'Qualidade de som muito baixa/comprimida',
      'Desconecta sozinho frequentemente',
      'Volume Bluetooth muito baixo',
      'Interferência/chiados'
    ],
    causes: [
      { cause: 'Interferência de outros dispositivos', probability: 30 },
      { cause: 'Distância excessiva do dispositivo BT', probability: 25 },
      { cause: 'Codec Bluetooth incompatível', probability: 20 },
      { cause: 'Problema no dispositivo BT (fone/caixa)', probability: 15 },
      { cause: 'IC Bluetooth com defeito', probability: 8 },
      { cause: 'Software/firmware desatualizado', probability: 2 }
    ],
    diagnosticTests: [
      'Testar próximo ao dispositivo BT (< 1 metro)',
      'Testar em ambiente sem interferência',
      'Testar com outro dispositivo Bluetooth',
      'Verificar codec Bluetooth nas configurações de desenvolvedor',
      'Desparear e reparear dispositivo',
      'Verificar nível de bateria do dispositivo BT'
    ],
    quickSolution: [
      'Aproximar dispositivo Bluetooth',
      'Desativar Wi-Fi temporariamente',
      'Desparear e reparear dispositivo',
      'Limpar cache Bluetooth',
      'Mudar codec para SBC (mais estável)',
      'Desativar economia de bateria para Bluetooth',
      'Atualizar firmware do fone BT',
      'Reiniciar ambos os dispositivos'
    ],
    professionalSolution: [
      'Alterar codec Bluetooth (LDAC, aptX, AAC)',
      'Desabilitar varredura de Wi-Fi enquanto usa BT',
      'Refluxo no IC Bluetooth (hardware)',
      'Substituir IC Wi-Fi/Bluetooth',
      'Atualizar firmware Bluetooth via JTAG'
    ],
    requiredTools: [
      'Outro dispositivo BT para teste',
      'Estação de solda BGA (casos extremos)'
    ],
    requiredParts: [
      'IC Wi-Fi/Bluetooth (raramente necessário)'
    ],
    repairRisks: [
      'Geralmente é problema de software/configuração',
      'Hardware raramente é a causa'
    ],
    estimatedTime: '5min - 2h',
    estimatedCost: { min: 0, max: 800 },
    difficulty: 'easy'
  },
  {
    id: 'audio_006',
    title: 'Sem áudio em vídeos / Mudo em apps',
    category: 'audio',
    severity: 'medium',
    frequency: 55,
    summary: 'Áudio não funciona especificamente em vídeos ou certos apps.',
    symptoms: ['Vídeos sem som', 'YouTube mudo', 'Apps sem áudio'],
    detailedSymptoms: [
      'Vídeos do YouTube/Instagram sem som',
      'Música toca mas vídeos não',
      'Alguns apps sem áudio, outros funcionam',
      'Som de sistema funciona mas mídia não',
      'Áudio voltou após reiniciar mas falhou de novo'
    ],
    causes: [
      { cause: 'Volume de mídia no mínimo', probability: 40 },
      { cause: 'App com permissões bloqueadas', probability: 25 },
      { cause: 'Cache do app corrompido', probability: 20 },
      { cause: 'Bug de software', probability: 10 },
      { cause: 'Modo "Não perturbe" ativo', probability: 5 }
    ],
    diagnosticTests: [
      'Verificar todos os volumes (sistema, mídia, alarme)',
      'Testar em apps diferentes',
      'Verificar modo "Não perturbe"',
      'Testar em modo seguro'
    ],
    quickSolution: [
      'Aumentar volume de mídia (botões físicos durante vídeo)',
      'Desativar "Não perturbe"',
      'Limpar cache do app específico',
      'Forçar parada e reabrir app',
      'Atualizar app',
      'Reiniciar aparelho',
      'Verificar se não está em modo silencioso'
    ],
    professionalSolution: [
      'Resetar preferências de app',
      'Limpar cache de todos os apps de mídia',
      'Reinstalar apps problemáticos',
      'Resetar configurações de som',
      'Atualizar sistema operacional'
    ],
    requiredTools: [
      'Configurações do sistema'
    ],
    requiredParts: [
      'Não requer peças'
    ],
    repairRisks: [
      'Quase sempre problema de configuração'
    ],
    estimatedTime: '5min - 20min',
    estimatedCost: { min: 0, max: 0 },
    difficulty: 'easy'
  },
  {
    id: 'audio_007',
    title: 'Vibração não funciona / Motor vibra-call',
    category: 'audio',
    severity: 'low',
    frequency: 45,
    summary: 'Motor de vibração não funciona ou vibração muito fraca.',
    symptoms: ['Não vibra', 'Vibração fraca', 'Barulho mas sem vibração'],
    detailedSymptoms: [
      'Completamente sem vibração',
      'Vibração muito fraca (quase imperceptível)',
      'Faz barulho mas não vibra',
      'Vibra apenas em algumas situações',
      'Vibração irregular/intermitente',
      'Vibração parou após queda/impacto'
    ],
    causes: [
      { cause: 'Motor de vibração queimado', probability: 50 },
      { cause: 'Contato do motor sujo/oxidado', probability: 20 },
      { cause: 'Vibração desativada nas configurações', probability: 15 },
      { cause: 'Motor desconectado (após reparo anterior)', probability: 10 },
      { cause: 'Trilha rompida', probability: 5 }
    ],
    diagnosticTests: [
      'Verificar configurações de vibração',
      'Testar vibração ao digitar teclado',
      'Ligar para o aparelho e verificar vibração',
      'Inspecionar motor visualmente',
      'Ouvir se faz barulho ao tentar vibrar'
    ],
    quickSolution: [
      'Ativar vibração nas configurações',
      'Aumentar intensidade de vibração',
      'Reiniciar aparelho',
      'Verificar modo "Não perturbe"',
      'Desativar economia de bateria (pode limitar vibração)'
    ],
    professionalSolution: [
      'Substituir motor de vibração (vibra-call)',
      'Limpar contatos do motor',
      'Reconectar motor',
      'Verificar continuidade com multímetro',
      'Reparar trilha rompida (raro)'
    ],
    requiredTools: [
      'Chaves de precisão',
      'Multímetro',
      'Álcool isopropílico'
    ],
    requiredParts: [
      'Motor de vibração (vibra-call motor)'
    ],
    repairRisks: [
      'Motor é fácil de substituir',
      'Baixo risco'
    ],
    estimatedTime: '10min - 30min',
    estimatedCost: { min: 20, max: 100 },
    difficulty: 'easy'
  }
];

const softwareProblems: PhoneProblem[] = [
  {
    id: 'software_001',
    title: 'Aparelho lento / Travando',
    category: 'software',
    severity: 'high',
    frequency: 90,
    summary: 'Sistema operacional muito lento, apps travando, interface com lag.',
    symptoms: ['Sistema muito lento', 'Apps travam', 'Interface com lag'],
    detailedSymptoms: [
      'Demora muito para abrir apps',
      'Interface trava ao trocar de app',
      'Teclado aparece com delay',
      'Animações travadas',
      'Apps fecham sozinhos',
      'Reinicializa aleatoriamente',
      'Tela congela'
    ],
    causes: [
      { cause: 'Armazenamento quase cheio (>90%)', probability: 35 },
      { cause: 'Muitos apps em segundo plano', probability: 25 },
      { cause: 'RAM insuficiente', probability: 15 },
      { cause: 'Sistema desatualizado ou com bugs', probability: 10 },
      { cause: 'App problemático consumindo recursos', probability: 8 },
      { cause: 'Cache acumulado', probability: 5 },
      { cause: 'Malware/vírus', probability: 2 }
    ],
    diagnosticTests: [
      'Verificar espaço de armazenamento disponível',
      'Verificar uso de RAM',
      'Identificar apps que mais consomem recursos',
      'Verificar CPU e temperatura',
      'Testar em modo seguro',
      'Verificar presença de malware'
    ],
    quickSolution: [
      'Liberar espaço (deletar fotos/vídeos/apps)',
      'Limpar cache de apps',
      'Fechar apps em segundo plano',
      'Desinstalar apps não usados',
      'Reiniciar aparelho',
      'Desativar animações (configurações de desenvolvedor)',
      'Limpar partição de cache (recovery)',
      'Atualizar sistema operacional'
    ],
    professionalSolution: [
      'Reset de fábrica (backup completo antes)',
      'Reinstalar sistema operacional (flash)',
      'Otimizar sistema com ADB',
      'Remover bloatware',
      'Instalar ROM customizada (usuários avançados)',
      'Verificar e remover malware',
      'Substituir hardware (se RAM/storage físico com defeito)'
    ],
    requiredTools: [
      'Cabo USB',
      'Computador com ADB',
      'Software de backup',
      'Software de flash (quando necessário)'
    ],
    requiredParts: [
      'Geralmente não requer peças'
    ],
    repairRisks: [
      'Reset de fábrica apaga todos os dados',
      'Flash incorreto pode brick o aparelho',
      'Backup incompleto resulta em perda de dados'
    ],
    estimatedTime: '30min - 3h',
    estimatedCost: { min: 0, max: 150 },
    difficulty: 'easy',
    warningNotes: [
      'SEMPRE fazer backup completo antes de reset de fábrica',
      'Flash de ROM requer conhecimento técnico'
    ]
  },
  {
    id: 'software_002',
    title: 'Bootloop / Reiniciando continuamente',
    category: 'software',
    severity: 'critical',
    frequency: 60,
    summary: 'Aparelho fica preso em loop de reinicialização, não inicia sistema.',
    symptoms: ['Reinicia sem parar', 'Trava no logo', 'Não passa da tela inicial'],
    detailedSymptoms: [
      'Liga, mostra logo e reinicia',
      'Loop infinito de reinicialização',
      'Trava na tela do logo da marca',
      'Entra em recovery sozinho',
      'Tela preta mas vibra repetidamente',
      'Bootloader aparece mas sistema não inicia'
    ],
    causes: [
      { cause: 'Atualização de sistema falhou', probability: 30 },
      { cause: 'App ou mod instalado incorretamente', probability: 25 },
      { cause: 'Partição de sistema corrompida', probability: 20 },
      { cause: 'Root/desbloqueio mal feito', probability: 15 },
      { cause: 'Hardware (RAM/eMMC) com defeito', probability: 8 },
      { cause: 'Bateria insuficiente durante atualização', probability: 2 }
    ],
    diagnosticTests: [
      'Tentar entrar em modo recovery',
      'Tentar entrar em modo bootloader/fastboot',
      'Verificar se recovery está acessível',
      'Conectar ao PC e verificar reconhecimento',
      'Verificar se LED ou vibração respondem'
    ],
    quickSolution: [
      'Forçar desligamento (segurar power 30 segundos)',
      'Entrar em recovery e limpar cache',
      'Wipe cache partition (modo recovery)',
      'Remover último app/mod instalado (se possível)',
      'Deixar bateria descarregar completamente e recarregar'
    ],
    professionalSolution: [
      'Entrar em recovery e fazer wipe data/factory reset',
      'Flash de ROM via recovery (TWRP)',
      'Flash de ROM via fastboot/download mode',
      'Reflash de firmware completo via ferramenta oficial',
      'Desbrickear via EDL mode (Qualcomm)',
      'Usar ferramentas específicas (SP Flash Tool, Odin, etc.)',
      'Reparar partições corrompidas via ADB/fastboot',
      'Substituir eMMC/UFS (se hardware defeituoso - avançado)'
    ],
    requiredTools: [
      'Cabo USB original',
      'Computador',
      'Software de flash oficial (Odin, Mi Flash, etc.)',
      'Drivers USB do fabricante',
      'Arquivo de firmware correto',
      'ADB e Fastboot'
    ],
    requiredParts: [
      'Chip eMMC/UFS (casos extremos de hardware)'
    ],
    repairRisks: [
      'Flash incorreto pode brick permanente',
      'Arquivo de firmware errado pode danificar',
      'Desbloquear bootloader apaga dados',
      'Hardware defeituoso pode não ter solução de software'
    ],
    estimatedTime: '1h - 6h',
    estimatedCost: { min: 0, max: 500 },
    difficulty: 'difficult',
    warningNotes: [
      'Sempre usar firmware oficial do modelo exato',
      'Bootloop por hardware pode não ter solução de software'
    ]
  },
  {
    id: 'software_003',
    title: 'Travado no logo / Não passa da tela inicial',
    category: 'software',
    severity: 'critical',
    frequency: 55,
    summary: 'Aparelho liga mas trava na tela do logo, não inicia o sistema.',
    symptoms: ['Trava no logo da marca', 'Tela inicial infinita', 'Não entra no sistema'],
    detailedSymptoms: [
      'Trava no logo da marca (Samsung, Xiaomi, etc.)',
      'Barra de carregamento não avança',
      'Fica na tela inicial por minutos/horas',
      'Tela animada mas não passa dela',
      'Sistema não inicia mesmo após horas'
    ],
    causes: [
      { cause: 'Atualização incompleta/falha', probability: 35 },
      { cause: 'Partição de sistema corrompida', probability: 25 },
      { cause: 'Memória (eMMC/UFS) com defeito', probability: 20 },
      { cause: 'Modificação de sistema mal feita', probability: 15 },
      { cause: 'Bootloader corrompido', probability: 5 }
    ],
    diagnosticTests: [
      'Aguardar pelo menos 15-30 minutos',
      'Tentar entrar em modo recovery',
      'Tentar modo bootloader/fastboot',
      'Conectar ao PC e verificar reconhecimento via ADB',
      'Verificar se aquece excessivamente'
    ],
    quickSolution: [
      'Aguardar 30 minutos (primeira inicialização pode demorar)',
      'Forçar reinicialização',
      'Entrar em recovery e limpar cache',
      'Wipe cache partition'
    ],
    professionalSolution: [
      'Factory reset via recovery',
      'Reflash de firmware completo',
      'Flash via modo download/EDL',
      'Reparar partições via ADB',
      'Substituir chip de memória (eMMC/UFS) - extremamente avançado'
    ],
    requiredTools: [
      'Computador',
      'Software de flash',
      'Firmware correto',
      'Cabo USB'
    ],
    requiredParts: [
      'Chip eMMC/UFS (casos extremos)'
    ],
    repairRisks: [
      'Reset apaga todos os dados',
      'Flash incorreto pode piorar',
      'Hardware defeituoso pode não ter solução'
    ],
    estimatedTime: '1h - 6h',
    estimatedCost: { min: 0, max: 600 },
    difficulty: 'difficult'
  },
  {
    id: 'software_004',
    title: 'Apps fecham sozinhos / Crashando',
    category: 'software',
    severity: 'medium',
    frequency: 75,
    summary: 'Aplicativos fecham inesperadamente ou não abrem.',
    symptoms: ['Apps fecham sozinhos', 'Apps não abrem', 'Erro ao abrir app'],
    detailedSymptoms: [
      'App abre e fecha imediatamente',
      'App trava e pede para fechar',
      'Mensagem "App parou de funcionar"',
      'App não abre de jeito nenhum',
      'Apenas alguns apps crasham',
      'Crashes após atualização de app ou sistema'
    ],
    causes: [
      { cause: 'Cache do app corrompido', probability: 35 },
      { cause: 'App incompatível com versão do Android', probability: 25 },
      { cause: 'Dados do app corrompidos', probability: 20 },
      { cause: 'RAM insuficiente', probability: 10 },
      { cause: 'Bug no app', probability: 8 },
      { cause: 'Sistema operacional com problema', probability: 2 }
    ],
    diagnosticTests: [
      'Verificar se apenas um app ou vários',
      'Testar em modo seguro',
      'Verificar espaço disponível',
      'Verificar uso de RAM',
      'Ver logs de crash (logcat)'
    ],
    quickSolution: [
      'Forçar parada do app',
      'Limpar cache do app',
      'Limpar dados do app (perde configurações)',
      'Desinstalar e reinstalar app',
      'Atualizar app para versão mais recente',
      'Atualizar sistema operacional',
      'Reiniciar aparelho',
      'Liberar espaço de armazenamento'
    ],
    professionalSolution: [
      'Analisar logcat para identificar causa',
      'Downgrade do app (se problema após atualização)',
      'Limpar cache Dalvik (recovery)',
      'Resetar preferências de apps',
      'Factory reset (último recurso)',
      'Instalar ROM mais estável'
    ],
    requiredTools: [
      'ADB (para logcat)',
      'Computador (opcional)'
    ],
    requiredParts: [
      'Não requer peças'
    ],
    repairRisks: [
      'Limpar dados do app perde configurações/login',
      'Desinstalar pode perder dados locais'
    ],
    estimatedTime: '5min - 1h',
    estimatedCost: { min: 0, max: 0 },
    difficulty: 'easy'
  },
  {
    id: 'software_005',
    title: 'Tela de toque não responde / Touch não funciona (software)',
    category: 'software',
    severity: 'high',
    frequency: 50,
    summary: 'Touch funciona intermitentemente, pode ser problema de software.',
    symptoms: ['Touch não responde às vezes', 'Touch funciona após reiniciar', 'Touch trava após tempo de uso'],
    detailedSymptoms: [
      'Touch para de funcionar após alguns minutos de uso',
      'Touch volta ao reiniciar',
      'Touch falha em apps específicos',
      'Touch funciona na tela de bloqueio mas não no sistema',
      'Alguns gestos não funcionam'
    ],
    causes: [
      { cause: 'Bug de software', probability: 40 },
      { cause: 'Driver de touch corrompido', probability: 25 },
      { cause: 'App específico causando conflito', probability: 20 },
      { cause: 'Calibração perdida', probability: 10 },
      { cause: 'Sistema desatualizado', probability: 5 }
    ],
    diagnosticTests: [
      'Reiniciar e verificar se volta',
      'Testar em modo seguro',
      'Verificar se ocorre em apps específicos',
      'Testar após desinstalar apps recentes'
    ],
    quickSolution: [
      'Reiniciar aparelho',
      'Limpar cache de sistema',
      'Recalibrar touch (se disponível)',
      'Atualizar sistema',
      'Desinstalar apps recém instalados',
      'Factory reset'
    ],
    professionalSolution: [
      'Reinstalar firmware',
      'Flash de ROM customizada',
      'Atualizar driver de touch via ADB',
      'Verificar e corrigir permissões de sistema'
    ],
    requiredTools: [
      'Computador',
      'ADB'
    ],
    requiredParts: [
      'Não requer peças'
    ],
    repairRisks: [
      'Se não resolver por software, é problema de hardware'
    ],
    estimatedTime: '10min - 2h',
    estimatedCost: { min: 0, max: 100 },
    difficulty: 'easy'
  },
  {
    id: 'software_006',
    title: 'Bateria descarrega rápido (software)',
    category: 'software',
    severity: 'high',
    frequency: 85,
    summary: 'Consumo excessivo de bateria causado por software, não hardware.',
    symptoms: ['Bateria acaba rápido', 'Apps consumindo muita bateria', 'Sistema consome bateria em standby'],
    detailedSymptoms: [
      'Bateria dura muito menos após atualização',
      'Um app específico consome 50%+ da bateria',
      'Bateria descarrega em standby',
      'Tela não é o maior consumidor (incomum)',
      'Wakelocks impedindo deep sleep'
    ],
    causes: [
      { cause: 'Apps em segundo plano consumindo recursos', probability: 40 },
      { cause: 'Wakelock (apps impedindo modo sleep)', probability: 25 },
      { cause: 'Sincronização constante de apps', probability: 15 },
      { cause: 'Bug em atualização de sistema', probability: 10 },
      { cause: 'Serviços do Google consumindo muito', probability: 8 },
      { cause: 'Malware minerando criptomoeda', probability: 2 }
    ],
    diagnosticTests: [
      'Verificar estatísticas de bateria',
      'Identificar apps que mais consomem',
      'Verificar wakelocks (requer root)',
      'Verificar consumo em standby (overnight)',
      'Testar em modo seguro'
    ],
    quickSolution: [
      'Identificar e fechar/desinstalar app problemático',
      'Desativar sincronização automática',
      'Desativar localização para apps que não precisam',
      'Limpar cache de apps consumidores',
      'Ativar modo economia de energia',
      'Desativar "Atividade física" do Google',
      'Limitar apps em segundo plano',
      'Atualizar todos os apps e sistema'
    ],
    professionalSolution: [
      'Analisar wakelocks via apps específicos (BetterBatteryStats)',
      'Desinstalar e reinstalar Google Play Services',
      'Limpar cache Dalvik',
      'Factory reset',
      'Instalar ROM customizada com melhor gerenciamento de bateria',
      'Usar Greenify ou similar para hibernar apps'
    ],
    requiredTools: [
      'App de análise de bateria',
      'ADB (opcional)'
    ],
    requiredParts: [
      'Não requer peças'
    ],
    repairRisks: [
      'Se nada resolver, é problema físico da bateria'
    ],
    estimatedTime: '15min - 2h',
    estimatedCost: { min: 0, max: 0 },
    difficulty: 'easy'
  },
  {
    id: 'software_007',
    title: 'Problemas após atualização de sistema',
    category: 'software',
    severity: 'high',
    frequency: 65,
    summary: 'Diversos problemas surgiram após atualização do Android/iOS.',
    symptoms: ['Sistema lento após atualizar', 'Bugs após update', 'Recursos pararam de funcionar'],
    detailedSymptoms: [
      'Sistema muito lento após atualização',
      'Bateria piorou após update',
      'Apps crashando após atualizar',
      'Interface com bugs visuais',
      'Recursos que funcionavam agora não funcionam',
      'Sistema instável após update'
    ],
    causes: [
      { cause: 'Cache antigo conflitando com novo sistema', probability: 40 },
      { cause: 'Bug na atualização', probability: 30 },
      { cause: 'Apps incompatíveis com nova versão', probability: 20 },
      { cause: 'Atualização incompleta', probability: 8 },
      { cause: 'Hardware incompatível com nova versão', probability: 2 }
    ],
    diagnosticTests: [
      'Verificar versão do sistema',
      'Verificar se update foi completado',
      'Identificar problemas específicos',
      'Verificar se outros usuários reportam mesmos bugs'
    ],
    quickSolution: [
      'Limpar cache de sistema (recovery)',
      'Reiniciar aparelho',
      'Atualizar todos os apps',
      'Aguardar patch corretivo do fabricante',
      'Limpar cache de apps problemáticos',
      'Desativar recursos novos que causam bugs'
    ],
    professionalSolution: [
      'Wipe cache e dalvik cache',
      'Factory reset (preserva dados se possível)',
      'Downgrade para versão anterior (requer desbloqueio)',
      'Aguardar hotfix oficial',
      'Instalar ROM customizada baseada em versão estável',
      'Reflash do firmware completo'
    ],
    requiredTools: [
      'Modo recovery',
      'Software de flash (para downgrade)',
      'Backup completo'
    ],
    requiredParts: [
      'Não requer peças'
    ],
    repairRisks: [
      'Downgrade pode apagar dados',
      'Pode perder garantia',
      'Alguns aparelhos não permitem downgrade'
    ],
    estimatedTime: '30min - 3h',
    estimatedCost: { min: 0, max: 100 },
    difficulty: 'moderate',
    warningNotes: [
      'Sempre fazer backup antes de mexer em atualizações'
    ]
  }
];

// Export all problems organized by category
export const phoneProblemsDatabase = {
  display: displayProblems,
  battery: batteryProblems,
  charging: chargingProblems,
  camera: cameraProblems,
  network: networkProblems,
  audio: audioProblems,
  software: softwareProblems,
  motherboard: [] as PhoneProblem[],
  sensors: [] as PhoneProblem[],
  hardware: [] as PhoneProblem[]
};

// Helper function to get all problems
export const getAllProblems = (): PhoneProblem[] => {
  return [
    ...displayProblems,
    ...batteryProblems,
    ...chargingProblems,
    ...cameraProblems,
    ...networkProblems,
    ...audioProblems,
    ...softwareProblems
  ];
};

// Helper function to get problems by category
export const getProblemsByCategory = (category: PhoneProblem['category']): PhoneProblem[] => {
  return getAllProblems().filter(problem => problem.category === category);
};

// Helper function to search problems
export const searchProblems = (query: string): PhoneProblem[] => {
  const lowerQuery = query.toLowerCase();
  return getAllProblems().filter(problem =>
    problem.title.toLowerCase().includes(lowerQuery) ||
    problem.summary.toLowerCase().includes(lowerQuery) ||
    problem.symptoms.some(s => s.toLowerCase().includes(lowerQuery))
  );
};
