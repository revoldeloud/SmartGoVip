import { ServiceOrder, Client, StockItem, CalendarEvent, AppConfig, AppSettings, Phone } from '@/types';

const STORAGE_KEYS = {
  ORDERS: 'deveresty_orders',
  CLIENTS: 'deveresty_clients',
  STOCK: 'deveresty_stock',
  EVENTS: 'deveresty_events',
  CONFIG: 'deveresty_config',
  SETTINGS: 'deveresty_settings',
  MODELS: 'deveresty_models',
  PHONES: 'deveresty_phones',
} as const;

// Generic storage functions
export const getFromStorage = <T>(key: string, defaultValue: T): T => {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch {
    return defaultValue;
  }
};

export const saveToStorage = <T>(key: string, value: T): void => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error('Error saving to storage:', error);
  }
};

// Orders
export const getOrders = (): ServiceOrder[] => 
  getFromStorage(STORAGE_KEYS.ORDERS, []);

export const saveOrders = (orders: ServiceOrder[]): void => 
  saveToStorage(STORAGE_KEYS.ORDERS, orders);

// Clients
export const getClients = (): Client[] => 
  getFromStorage(STORAGE_KEYS.CLIENTS, []);

export const saveClients = (clients: Client[]): void => 
  saveToStorage(STORAGE_KEYS.CLIENTS, clients);

// Stock
export const getStock = (): StockItem[] => 
  getFromStorage(STORAGE_KEYS.STOCK, []);

export const saveStock = (stock: StockItem[]): void => 
  saveToStorage(STORAGE_KEYS.STOCK, stock);

// Events
export const getEvents = (): CalendarEvent[] => 
  getFromStorage(STORAGE_KEYS.EVENTS, []);

export const saveEvents = (events: CalendarEvent[]): void => 
  saveToStorage(STORAGE_KEYS.EVENTS, events);

// Config
export const getConfig = (): AppConfig => 
  getFromStorage(STORAGE_KEYS.CONFIG, {
    companyName: 'Deveresty Assistência Técnica',
    whatsapp: '(73) 99148-7945',
    email: 'contato@deveresty.com',
    address: 'Rua Exemplo, 123 - Centro',
    cnpj: '12.345.678/0001-90',
    defaultWarranty: 90,
  });

export const saveConfig = (config: AppConfig): void => 
  saveToStorage(STORAGE_KEYS.CONFIG, config);

// Settings
export const getSettings = (): AppSettings => 
  getFromStorage(STORAGE_KEYS.SETTINGS, {
    darkMode: false,
    autoNumbering: true,
    deleteConfirmation: true,
    autoPrint: false,
    notifyBudgets: true,
    notifyReady: true,
    notifyLowStock: true,
    autoBackup: false,
  });

export const saveSettings = (settings: AppSettings): void => 
  saveToStorage(STORAGE_KEYS.SETTINGS, settings);

// Models
export const getModels = (): string[] => 
  getFromStorage(STORAGE_KEYS.MODELS, []);

export const saveModels = (models: string[]): void => 
  saveToStorage(STORAGE_KEYS.MODELS, models);

export const addModel = (model: string): void => {
  const models = getModels();
  if (!models.includes(model)) {
    saveModels([...models, model]);
  }
};

// Phones
export const getPhones = (): Phone[] => 
  getFromStorage(STORAGE_KEYS.PHONES, []);

export const savePhones = (phones: Phone[]): void => 
  saveToStorage(STORAGE_KEYS.PHONES, phones);

// Utility to generate IDs
export const generateId = (): string => 
  `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
