import { ServiceOrder } from '@/types';
import { formatCurrency, formatDate, getStatusLabel } from './formatters';
import { getConfig } from './storage';

export const printOrder = (order: ServiceOrder) => {
  const config = getConfig();
  
  const printWindow = window.open('', '_blank');
  if (!printWindow) return;

  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="UTF-8">
        <title>${order.type === 'os' ? 'Ordem de Serviço' : 'Orçamento'} - ${order.clientName}</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body {
            font-family: Arial, sans-serif;
            padding: 20mm;
            color: #333;
          }
          .header {
            text-align: center;
            border-bottom: 3px solid #000;
            padding-bottom: 20px;
            margin-bottom: 30px;
          }
          .header h1 { font-size: 28px; margin-bottom: 5px; }
          .header p { font-size: 14px; color: #666; }
          .section {
            margin-bottom: 25px;
          }
          .section-title {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 10px;
            padding-bottom: 5px;
            border-bottom: 1px solid #ddd;
          }
          .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 15px;
          }
          .info-item label {
            font-weight: bold;
            font-size: 12px;
            color: #666;
            display: block;
            margin-bottom: 3px;
          }
          .info-item p {
            font-size: 14px;
          }
          .observations {
            background: #f5f5f5;
            padding: 15px;
            border-radius: 5px;
            margin-top: 10px;
          }
          .total {
            text-align: right;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 2px solid #000;
          }
          .total-label {
            font-size: 18px;
            font-weight: bold;
          }
          .total-value {
            font-size: 32px;
            font-weight: bold;
            color: #000;
            margin-top: 5px;
          }
          .footer {
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            text-align: center;
            font-size: 12px;
            color: #666;
          }
          .signature {
            margin-top: 60px;
            text-align: center;
          }
          .signature-line {
            border-top: 1px solid #000;
            width: 300px;
            margin: 0 auto 10px;
          }
          .status-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            margin-top: 10px;
          }
          @media print {
            body { padding: 0; }
            .no-print { display: none; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>${config.companyName.toUpperCase()}</h1>
          <p>Sistema de Assistência Técnica</p>
          <p style="margin-top: 15px; font-size: 18px; font-weight: bold;">
            ${order.type === 'os' ? 'ORDEM DE SERVIÇO' : 'ORÇAMENTO'}
          </p>
          <span class="status-badge" style="background: #e3f2fd; color: #1565c0;">
            ${getStatusLabel(order.status)}
          </span>
        </div>

        <div class="section">
          <div class="section-title">Dados do Cliente</div>
          <div class="info-grid">
            <div class="info-item">
              <label>Nome</label>
              <p>${order.clientName}</p>
            </div>
            <div class="info-item">
              <label>Telefone</label>
              <p>${order.phone}</p>
            </div>
          </div>
        </div>

        <div class="section">
          <div class="section-title">Informações do Equipamento</div>
          <div class="info-grid">
            <div class="info-item">
              <label>Modelo</label>
              <p>${order.model}</p>
            </div>
            <div class="info-item">
              <label>Serviço</label>
              <p>${order.service}</p>
            </div>
          </div>
          ${order.defect ? `
            <div class="info-item" style="margin-top: 15px;">
              <label>Defeito Relatado</label>
              <p>${order.defect}</p>
            </div>
          ` : ''}
        </div>

        ${order.observations ? `
          <div class="section">
            <div class="section-title">Observações</div>
            <div class="observations">
              ${order.observations}
            </div>
          </div>
        ` : ''}

        <div class="section">
          <div class="section-title">Valores</div>
          <div class="info-grid">
            <div class="info-item">
              <label>Serviço</label>
              <p>${formatCurrency(order.servicePrice)}</p>
            </div>
            <div class="info-item">
              <label>Peças</label>
              <p>${formatCurrency(order.partsPrice)}</p>
            </div>
          </div>
        </div>

        <div class="total">
          <div class="total-label">VALOR TOTAL</div>
          <div class="total-value">${formatCurrency(order.finalPrice)}</div>
        </div>

        <div class="signature">
          <div class="signature-line"></div>
          <p>Assinatura do Cliente</p>
        </div>

        <div class="footer">
          <p>Data de Emissão: ${formatDate(order.createdAt)}</p>
          <p style="margin-top: 5px;">Última Atualização: ${formatDate(order.updatedAt)}</p>
        </div>

        <script>
          window.onload = () => {
            window.print();
            window.onafterprint = () => window.close();
          };
        </script>
      </body>
    </html>
  `;

  printWindow.document.write(html);
  printWindow.document.close();
};

export const printInvoice = (order: ServiceOrder) => {
  const config = getConfig();
  const printWindow = window.open('', '_blank');
  if (!printWindow) return;

  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="UTF-8">
        <title>Nota de Serviço - ${order.clientName}</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body {
            font-family: Arial, sans-serif;
            padding: 15mm;
            color: #333;
          }
          .header {
            display: flex;
            justify-content: space-between;
            border-bottom: 3px solid #000;
            padding-bottom: 20px;
            margin-bottom: 25px;
          }
          .header-left h1 { font-size: 24px; margin-bottom: 5px; }
          .header-left p { font-size: 11px; color: #666; }
          .header-right {
            text-align: right;
          }
          .header-right h2 {
            font-size: 20px;
            margin-bottom: 10px;
          }
          .header-right p {
            font-size: 12px;
            color: #666;
          }
          .section {
            margin-bottom: 20px;
          }
          .section-title {
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 10px;
            padding: 5px 10px;
            background: #f5f5f5;
          }
          .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            font-size: 12px;
          }
          .info-item label {
            font-weight: bold;
            color: #666;
            display: block;
            margin-bottom: 3px;
          }
          .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
          }
          .table th,
          .table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
            font-size: 12px;
          }
          .table th {
            background: #f5f5f5;
            font-weight: bold;
          }
          .table td.right {
            text-align: right;
          }
          .total-section {
            margin-top: 30px;
            text-align: right;
          }
          .total-line {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 8px;
            font-size: 13px;
          }
          .total-line label {
            width: 150px;
            font-weight: bold;
          }
          .total-line span {
            width: 120px;
            text-align: right;
          }
          .total-final {
            margin-top: 15px;
            padding-top: 15px;
            border-top: 2px solid #000;
          }
          .total-final label {
            font-size: 16px;
          }
          .total-final span {
            font-size: 20px;
            font-weight: bold;
          }
          .footer {
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            font-size: 11px;
            color: #666;
            text-align: center;
          }
          .notes {
            background: #f9f9f9;
            padding: 15px;
            margin-top: 20px;
            border-left: 3px solid #000;
          }
          .notes-title {
            font-weight: bold;
            margin-bottom: 8px;
            font-size: 12px;
          }
          .notes-content {
            font-size: 11px;
            line-height: 1.6;
          }
          @media print {
            body { padding: 0; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="header-left">
            <h1>${config.companyName.toUpperCase()}</h1>
            <p>Assistência Técnica Especializada</p>
            <p>${config.whatsapp}</p>
            <p>${config.email}</p>
          </div>
          <div class="header-right">
            <h2>NOTA DE SERVIÇO</h2>
            <p>Nº ${order.id.slice(-8).toUpperCase()}</p>
            <p>Data: ${formatDate(order.createdAt)}</p>
          </div>
        </div>

        <div class="section">
          <div class="section-title">DADOS DO CLIENTE</div>
          <div class="info-grid">
            <div class="info-item">
              <label>Nome:</label>
              <p>${order.clientName}</p>
            </div>
            <div class="info-item">
              <label>Telefone:</label>
              <p>${order.phone}</p>
            </div>
            ${order.email ? `
              <div class="info-item">
                <label>Email:</label>
                <p>${order.email}</p>
              </div>
            ` : ''}
            ${order.address ? `
              <div class="info-item">
                <label>Endereço:</label>
                <p>${order.address}</p>
              </div>
            ` : ''}
          </div>
        </div>

        <div class="section">
          <div class="section-title">SERVIÇOS PRESTADOS</div>
          <table class="table">
            <thead>
              <tr>
                <th>Descrição</th>
                <th style="width: 150px;">Valor</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>
                  <strong>${order.service}</strong><br>
                  <small>Modelo: ${order.model}</small>
                  ${order.defect ? `<br><small>Defeito: ${order.defect}</small>` : ''}
                </td>
                <td class="right">${formatCurrency(order.servicePrice)}</td>
              </tr>
              ${order.partsPrice > 0 ? `
                <tr>
                  <td>Peças e Componentes</td>
                  <td class="right">${formatCurrency(order.partsPrice)}</td>
                </tr>
              ` : ''}
            </tbody>
          </table>
        </div>

        <div class="total-section">
          <div class="total-line">
            <label>Subtotal Serviço:</label>
            <span>${formatCurrency(order.servicePrice)}</span>
          </div>
          <div class="total-line">
            <label>Subtotal Peças:</label>
            <span>${formatCurrency(order.partsPrice)}</span>
          </div>
          <div class="total-line total-final">
            <label>VALOR TOTAL:</label>
            <span>${formatCurrency(order.finalPrice)}</span>
          </div>
        </div>

        ${order.observations ? `
          <div class="notes">
            <div class="notes-title">OBSERVAÇÕES:</div>
            <div class="notes-content">${order.observations}</div>
          </div>
        ` : ''}

        <div class="notes">
          <div class="notes-title">CONDIÇÕES:</div>
          <div class="notes-content">
            • Garantia de ${order.warranty} dias para o serviço executado<br>
            • A garantia não cobre mau uso ou danos físicos<br>
            • Equipamento não retirado em 90 dias será descartado<br>
            • Os dados do aparelho não são de nossa responsabilidade
          </div>
        </div>

        <div class="footer">
          <p>Este documento não tem valor fiscal</p>
          <p style="margin-top: 5px;">Obrigado pela preferência!</p>
        </div>

        <script>
          window.onload = () => {
            window.print();
            window.onafterprint = () => window.close();
          };
        </script>
      </body>
    </html>
  `;

  printWindow.document.write(html);
  printWindow.document.close();
};

export const printReceipt = (order: ServiceOrder) => {
  const config = getConfig();
  
  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Recibo de Pagamento - ${order.id}</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
          font-family: 'Courier New', monospace;
          padding: 20mm;
          font-size: 11pt;
          line-height: 1.4;
        }
        .header {
          text-align: center;
          border-bottom: 2px solid #000;
          padding-bottom: 10px;
          margin-bottom: 20px;
        }
        .title { font-size: 16pt; font-weight: bold; margin-bottom: 5px; }
        .subtitle { font-size: 10pt; color: #555; }
        .section { margin: 15px 0; }
        .label { font-weight: bold; display: inline-block; width: 120px; }
        .value { display: inline-block; }
        .amount {
          background: #f5f5f5;
          border: 2px solid #000;
          padding: 15px;
          margin: 20px 0;
          text-align: center;
        }
        .amount .label { font-size: 12pt; display: block; margin-bottom: 5px; }
        .amount .value { font-size: 20pt; font-weight: bold; display: block; }
        .footer {
          margin-top: 30px;
          padding-top: 15px;
          border-top: 1px solid #000;
          font-size: 9pt;
          text-align: center;
        }
        .signature {
          margin-top: 40px;
          text-align: center;
        }
        .signature-line {
          display: inline-block;
          width: 300px;
          border-top: 1px solid #000;
          margin-top: 50px;
        }
        @media print {
          body { padding: 10mm; }
        }
      </style>
    </head>
    <body>
      <div class="header">
        <div class="title">✅ RECIBO DE PAGAMENTO</div>
        <div class="subtitle">${config.companyName || 'Assistência Técnica'}</div>
        <div class="subtitle">${config.whatsapp ? `📞 ${config.whatsapp}` : ''}</div>
      </div>

      <div class="section">
        <div><span class="label">OS Nº:</span> <span class="value">${order.id}</span></div>
        <div><span class="label">Data:</span> <span class="value">${formatDate(order.paymentDate || new Date().toISOString())}</span></div>
      </div>

      <div class="section">
        <div><span class="label">Cliente:</span> <span class="value">${order.clientName}</span></div>
        <div><span class="label">Telefone:</span> <span class="value">${order.phone}</span></div>
      </div>

      <div class="section">
        <div><span class="label">Aparelho:</span> <span class="value">${order.model}</span></div>
        <div><span class="label">Serviço:</span> <span class="value">${order.service}</span></div>
      </div>

      <div class="amount">
        <div class="label">VALOR PAGO</div>
        <div class="value">${formatCurrency(order.finalPrice)}</div>
      </div>

      <div class="section">
        <div><span class="label">🛡️ Garantia:</span> <span class="value">${order.warranty} dias</span></div>
        <div style="font-size: 9pt; color: #666; margin-top: 5px;">
          Válida a partir da data de entrega do aparelho.
        </div>
      </div>

      ${order.observations ? `
        <div class="section">
          <div class="label">Observações:</div>
          <div style="margin-top: 5px; padding: 10px; background: #f9f9f9; border-left: 3px solid #000;">
            ${order.observations}
          </div>
        </div>
      ` : ''}

      <div class="signature">
        <div class="signature-line"></div>
        <div style="margin-top: 5px;">Assinatura do Cliente</div>
      </div>

      <div class="footer">
        <div>✨ Obrigado pela preferência! ✨</div>
        ${config.address ? `<div style="margin-top: 5px;">${config.address}</div>` : ''}
        ${config.email ? `<div>${config.email}</div>` : ''}
      </div>

      <script>
        window.onload = () => {
          window.print();
          window.onafterprint = () => window.close();
        };
      </script>
    </body>
    </html>
  `;

  const printWindow = window.open('', '_blank');
  if (!printWindow) return;
  
  printWindow.document.write(html);
  printWindow.document.close();
};
