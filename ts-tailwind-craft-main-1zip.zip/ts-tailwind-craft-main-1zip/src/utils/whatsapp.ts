import { ServiceOrder } from '@/types';
import { formatCurrency, formatDate, getStatusLabel } from './formatters';
import { getConfig } from './storage';

export const generateWhatsAppMessage = (order: ServiceOrder): string => {
  const type = order.type === 'os' ? 'ORDEM DE SERVIÇO' : 'ORÇAMENTO';
  
  let message = `*${type}*\n\n`;
  message += `📋 *Detalhes do Atendimento*\n`;
  message += `👤 Cliente: ${order.clientName}\n`;
  message += `📱 Telefone: ${order.phone}\n`;
  message += `📱 Modelo: ${order.model}\n`;
  message += `🔧 Serviço: ${order.service}\n\n`;
  
  if (order.defect) {
    message += `⚠️ *Defeito Relatado:*\n${order.defect}\n\n`;
  }
  
  if (order.observations) {
    message += `📝 *Observações:*\n${order.observations}\n\n`;
  }
  
  message += `💰 *Valores*\n`;
  message += `Serviço: ${formatCurrency(order.servicePrice)}\n`;
  message += `Peças: ${formatCurrency(order.partsPrice)}\n`;
  message += `*Total: ${formatCurrency(order.finalPrice)}*\n\n`;
  
  if (order.type === 'os') {
    message += `📊 Status: ${getStatusLabel(order.status)}\n`;
  }
  
  message += `📅 Data: ${formatDate(order.createdAt)}`;
  
  return message;
};

export const sendToWhatsApp = (order: ServiceOrder, phoneNumber?: string) => {
  const message = generateWhatsAppMessage(order);
  const encodedMessage = encodeURIComponent(message);
  
  // Se um número específico for fornecido, usa ele, senão usa o número do cliente
  const phone = phoneNumber || order.phone.replace(/\D/g, '');
  const whatsappUrl = `https://wa.me/55${phone}?text=${encodedMessage}`;
  
  window.open(whatsappUrl, '_blank');
};

export const sendServiceReport = (order: ServiceOrder) => {
  const config = getConfig();
  const companyName = config.companyName || 'Assistência Técnica';
  const companyWhatsApp = config.whatsapp || '';
  const companyEmail = config.email || '';
  
  const photoCount = 
    (order.beforePhotos?.length || 0) + 
    (order.duringPhotos?.length || 0) + 
    (order.afterPhotos?.length || 0);
  
  // Template padrão caso não haja personalização
  const defaultTemplate = `*🔧 RELATÓRIO DE SERVIÇO COMPLETO*

📋 *OS:* {orderId}
👤 *Cliente:* {clientName}
📱 *Aparelho:* {model}
🔧 *Serviço:* {service}

⚠️ *Defeito Inicial:* {defect}

💰 *VALOR TOTAL: R$ {finalPrice}*

✅ *Serviço concluído e pronto para retirada!*
📅 Data: {createdAt}
🛡️ Garantia: {warranty} dias`;

  const template = config.messageTemplates?.serviceReport || defaultTemplate;
  
  // Substituir variáveis
  let message = template
    .replace(/{companyName}/g, companyName)
    .replace(/{companyWhatsApp}/g, companyWhatsApp)
    .replace(/{companyEmail}/g, companyEmail)
    .replace(/{orderId}/g, order.id)
    .replace(/{clientName}/g, order.clientName)
    .replace(/{model}/g, order.model)
    .replace(/{imei}/g, order.imei || '')
    .replace(/{service}/g, order.service)
    .replace(/{defect}/g, order.defect || '')
    .replace(/{observations}/g, order.observations || '')
    .replace(/{photoCount}/g, photoCount.toString())
    .replace(/{finalPrice}/g, formatCurrency(order.finalPrice))
    .replace(/{createdAt}/g, formatDate(order.createdAt))
    .replace(/{warranty}/g, order.warranty?.toString() || '');

  const encodedMessage = encodeURIComponent(message);
  const phone = order.phone.replace(/\D/g, '');
  const whatsappUrl = `https://wa.me/55${phone}?text=${encodedMessage}`;
  
  window.open(whatsappUrl, '_blank');
};

export const sendPaymentRequest = (order: ServiceOrder) => {
  const config = getConfig();
  const companyName = config.companyName || 'Assistência Técnica';
  const pixKey = 'deverestystudio@gmail.com';
  const beneficiary = 'John Macley E.S.Sá';
  
  const defaultTemplate = `*🔧 RELATÓRIO DE SERVIÇO - PRONTO PARA RETIRADA*

📋 *OS:* {orderId}
👤 *Cliente:* {clientName}
📱 *Aparelho:* {model}
🔧 *Serviço:* {service}

💰 *VALOR TOTAL: R$ {finalPrice}*

✅ *Serviço concluído e pronto para retirada!*

💳 *PAGAMENTO VIA MERCADO PAGO*
*Banco:* Mercado Pago
*Beneficiário:* {beneficiary}
*Chave PIX:* {pixKey}

🛡️ Garantia: {warranty} dias`;

  const template = config.messageTemplates?.paymentRequest || defaultTemplate;
  
  let message = template
    .replace(/{companyName}/g, companyName)
    .replace(/{orderId}/g, order.id)
    .replace(/{clientName}/g, order.clientName)
    .replace(/{model}/g, order.model)
    .replace(/{service}/g, order.service)
    .replace(/{finalPrice}/g, formatCurrency(order.finalPrice))
    .replace(/{warranty}/g, order.warranty?.toString() || '')
    .replace(/{pixKey}/g, pixKey)
    .replace(/{beneficiary}/g, beneficiary);

  const encodedMessage = encodeURIComponent(message);
  const phone = order.phone.replace(/\D/g, '');
  const whatsappUrl = `https://wa.me/55${phone}?text=${encodedMessage}`;
  
  window.open(whatsappUrl, '_blank');
};

export const sendPaymentReceipt = (order: ServiceOrder) => {
  const config = getConfig();
  const companyName = config.companyName || 'Assistência Técnica';
  const companyWhatsApp = config.whatsapp || '';
  const companyEmail = config.email || '';
  
  const defaultTemplate = `*✅ PAGAMENTO CONFIRMADO*

🧾 *Recibo de Pagamento*
📋 OS: {orderId}
👤 Cliente: {clientName}
📱 Aparelho: {model}
🔧 Serviço: {service}

💰 *Valor Pago: R$ {finalPrice}*
📅 Data: {paymentDate}

🛡️ *Garantia: {warranty} dias*
Válida a partir da data de entrega.

✨ Obrigado pela preferência!
Qualquer problema, estamos à disposição.`;

  const template = config.messageTemplates?.paymentReceipt || defaultTemplate;
  
  let message = template
    .replace(/{companyName}/g, companyName)
    .replace(/{companyWhatsApp}/g, companyWhatsApp)
    .replace(/{companyEmail}/g, companyEmail)
    .replace(/{orderId}/g, order.id)
    .replace(/{clientName}/g, order.clientName)
    .replace(/{model}/g, order.model)
    .replace(/{service}/g, order.service)
    .replace(/{finalPrice}/g, formatCurrency(order.finalPrice))
    .replace(/{paymentDate}/g, formatDate(order.paymentDate || new Date().toISOString()))
    .replace(/{warranty}/g, order.warranty?.toString() || '');

  const encodedMessage = encodeURIComponent(message);
  const phone = order.phone.replace(/\D/g, '');
  const whatsappUrl = `https://wa.me/55${phone}?text=${encodedMessage}`;
  
  window.open(whatsappUrl, '_blank');
};
