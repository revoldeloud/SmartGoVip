import { IFixitGuide, IFixitCategory, IFixitCache } from '@/types/ifixit';

const BASE_URL = 'https://www.ifixit.com/api/2.0';
const CACHE_KEY = 'ifixit_cache';
const CACHE_DURATION = 7 * 24 * 60 * 60 * 1000; // 7 dias

// Função auxiliar para obter cache
const getCache = (): IFixitCache => {
  try {
    const cache = localStorage.getItem(CACHE_KEY);
    return cache ? JSON.parse(cache) : {};
  } catch {
    return {};
  }
};

// Função auxiliar para salvar cache
const saveCache = (cache: IFixitCache): void => {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify(cache));
  } catch (error) {
    console.error('Erro ao salvar cache:', error);
  }
};

// Verifica se cache é válido
const isCacheValid = (deviceKey: string): boolean => {
  const cache = getCache();
  const entry = cache[deviceKey];
  
  if (!entry) return false;
  
  const now = Date.now();
  return (now - entry.timestamp) < entry.expiresIn;
};

// Obtém dados do cache
const getCachedGuides = (deviceKey: string): IFixitGuide[] | null => {
  if (!isCacheValid(deviceKey)) return null;
  
  const cache = getCache();
  return cache[deviceKey]?.guides || null;
};

// Salva dados no cache
const cacheGuides = (deviceKey: string, guides: IFixitGuide[]): void => {
  const cache = getCache();
  cache[deviceKey] = {
    guides,
    timestamp: Date.now(),
    expiresIn: CACHE_DURATION
  };
  saveCache(cache);
};

// Normaliza nome do dispositivo para formato da API
const normalizeDeviceName = (brand: string, model: string): string => {
  // Remove caracteres especiais e espaços extras
  const normalized = `${brand} ${model}`
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^\w-]/g, '');
  
  return normalized;
};

// Busca categoria de dispositivo
export const getDeviceCategory = async (brand: string, model: string): Promise<IFixitCategory | null> => {
  const deviceName = normalizeDeviceName(brand, model);
  const cacheKey = `${brand}-${model}`.toLowerCase();
  
  // Verifica cache
  const cachedGuides = getCachedGuides(cacheKey);
  if (cachedGuides) {
    return {
      name: `${brand} ${model}`,
      wiki_id: 0,
      category: deviceName,
      guides: cachedGuides
    };
  }
  
  try {
    const response = await fetch(`${BASE_URL}/categories/${deviceName}`, {
      headers: {
        'Accept': 'application/json'
      }
    });
    
    if (!response.ok) {
      console.warn(`Dispositivo não encontrado: ${deviceName}`);
      return null;
    }
    
    const data: IFixitCategory = await response.json();
    
    // Salva no cache
    if (data.guides && data.guides.length > 0) {
      cacheGuides(cacheKey, data.guides);
    }
    
    return data;
  } catch (error) {
    console.error('Erro ao buscar categoria do dispositivo:', error);
    return null;
  }
};

// Busca guias de reparo para um dispositivo
export const getRepairGuides = async (brand: string, model: string, forceRefresh = false): Promise<IFixitGuide[]> => {
  const cacheKey = `${brand}-${model}`.toLowerCase();
  
  // Verifica cache (se não forçar atualização)
  if (!forceRefresh) {
    const cachedGuides = getCachedGuides(cacheKey);
    if (cachedGuides) {
      return cachedGuides;
    }
  }
  
  // Busca dados da API
  const category = await getDeviceCategory(brand, model);
  
  if (!category || !category.guides) {
    return [];
  }
  
  return category.guides;
};

// Busca detalhes de um guia específico
export const getGuideDetails = async (guideId: number): Promise<IFixitGuide | null> => {
  try {
    const response = await fetch(`${BASE_URL}/guides/${guideId}`, {
      headers: {
        'Accept': 'application/json'
      }
    });
    
    if (!response.ok) {
      console.warn(`Guia não encontrado: ${guideId}`);
      return null;
    }
    
    const data: IFixitGuide = await response.json();
    return data;
  } catch (error) {
    console.error('Erro ao buscar detalhes do guia:', error);
    return null;
  }
};

// Limpa cache de um dispositivo específico ou todo cache
export const clearCache = (deviceKey?: string): void => {
  if (deviceKey) {
    const cache = getCache();
    delete cache[deviceKey];
    saveCache(cache);
  } else {
    localStorage.removeItem(CACHE_KEY);
  }
};

// Busca dispositivos (para autocomplete)
export const searchDevices = async (query: string): Promise<string[]> => {
  try {
    const response = await fetch(`${BASE_URL}/search/${encodeURIComponent(query)}?filter=category`, {
      headers: {
        'Accept': 'application/json'
      }
    });
    
    if (!response.ok) return [];
    
    const data = await response.json();
    
    // Extrai nomes de dispositivos dos resultados
    if (data.results) {
      return data.results
        .filter((result: any) => result.dataType === 'category')
        .map((result: any) => result.title)
        .slice(0, 10); // Limita a 10 resultados
    }
    
    return [];
  } catch (error) {
    console.error('Erro ao buscar dispositivos:', error);
    return [];
  }
};
