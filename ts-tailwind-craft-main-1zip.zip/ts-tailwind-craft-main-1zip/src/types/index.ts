export type OrderStatus = 'pending' | 'in_progress' | 'waiting_parts' | 'ready' | 'delivered' | 'cancelled';
export type EntryType = 'os' | 'budget';
export type EventType = 'consulta' | 'entrega' | 'retirada' | 'orcamento' | 'outro';
export type StockCategory = 'tela' | 'bateria' | 'camera' | 'conector' | 'outro';

export interface Client {
  id: string;
  name: string;
  phone: string;
  email?: string;
  address?: string;
  notes?: string;
  createdAt: string;
}

export interface ServiceOrder {
  id: string;
  type: EntryType;
  status: OrderStatus;
  clientName: string;
  phone: string;
  email?: string;
  address?: string;
  model: string;
  imei?: string;
  service: string;
  defect?: string;
  screenType?: string;
  observations?: string;
  servicePrice: number;
  partsPrice: number;
  finalPrice: number;
  warranty: number;
  deadline?: string;
  beforePhotos?: string[];
  duringPhotos?: string[];
  afterPhotos?: string[];
  paymentConfirmed?: boolean;
  paymentDate?: string;
  createdAt: string;
  updatedAt: string;
}

export interface StockItem {
  id: string;
  name: string;
  category: StockCategory;
  quantity: number;
  minQuantity: number;
  cost: number;
  createdAt: string;
  updatedAt: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  date: string;
  time?: string;
  type: EventType;
  client?: string;
  description?: string;
  createdAt: string;
}

export interface AppConfig {
  companyName: string;
  whatsapp: string;
  email: string;
  address: string;
  cnpj: string;
  defaultWarranty: number;
  pixKey?: string;
  pixKeyType?: 'cpf' | 'cnpj' | 'email' | 'phone' | 'random';
  messageTemplates?: {
    serviceReport?: string;
    paymentRequest?: string;
    paymentReceipt?: string;
  };
}

export interface Phone {
  id: string;
  brand: string;
  model: string;
  ram: string;
  storage: string;
  frontPhoto?: string;
  backPhoto?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AppSettings {
  darkMode: boolean;
  autoNumbering: boolean;
  deleteConfirmation: boolean;
  autoPrint: boolean;
  notifyBudgets: boolean;
  notifyReady: boolean;
  notifyLowStock: boolean;
  autoBackup: boolean;
}

export interface DashboardStats {
  today: number;
  clients: number;
  pending: number;
  in_progress: number;
  ready: number;
  total: number;
  profit: number;
}

export interface PhoneProblem {
  id: string;
  title: string;
  category: 'display' | 'battery' | 'network' | 'camera' | 'software' | 'charging' | 'audio' | 'motherboard' | 'sensors' | 'hardware';
  severity: 'low' | 'medium' | 'high' | 'critical';
  frequency: number;
  summary: string;
  symptoms: string[];
  detailedSymptoms: string[];
  causes: Array<{ cause: string; probability: number }>;
  diagnosticTests: string[];
  quickSolution: string[];
  professionalSolution: string[];
  requiredTools: string[];
  requiredParts?: string[];
  repairRisks: string[];
  estimatedTime: string;
  estimatedCost: { min: number; max: number };
  difficulty: 'easy' | 'moderate' | 'difficult' | 'expert';
  warningNotes?: string[];
}
