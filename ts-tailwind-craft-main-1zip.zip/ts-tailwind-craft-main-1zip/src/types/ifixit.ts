export interface IFixitImage {
  id: number;
  mini: string;
  thumbnail: string;
  standard: string;
  medium: string;
  large: string;
  original: string;
}

export type IFixitDifficulty = 'Very easy' | 'Easy' | 'Moderate' | 'Difficult' | 'Very difficult';

export interface IFixitTool {
  name: string;
  url?: string;
  thumbnail?: string;
}

export interface IFixitPart {
  name: string;
  url?: string;
  thumbnail?: string;
}

export interface IFixitStep {
  guideid: number;
  stepid: number;
  orderby: number;
  title: string;
  lines: Array<{
    text_raw: string;
    text_rendered: string;
  }>;
  media: {
    type: string;
    data: IFixitImage[];
  };
}

export interface IFixitGuide {
  guideid: number;
  title: string;
  subject: string;
  type: string;
  difficulty: IFixitDifficulty;
  time_required: string;
  time_required_min: number;
  time_required_max: number;
  summary: string;
  introduction_raw: string;
  introduction_rendered: string;
  image: IFixitImage;
  thumbnail: string;
  url: string;
  steps: IFixitStep[];
  tools: IFixitTool[];
  parts: IFixitPart[];
  public: boolean;
}

export interface IFixitCategory {
  name: string;
  wiki_id: number;
  category: string;
  guides: IFixitGuide[];
  children?: IFixitCategory[];
}

export interface IFixitSearchResult {
  title: string;
  url: string;
  dataType: string;
  image?: IFixitImage;
}

export interface IFixitCacheEntry {
  guides: IFixitGuide[];
  timestamp: number;
  expiresIn: number;
}

export interface IFixitCache {
  [deviceKey: string]: IFixitCacheEntry;
}
