import { useState, useEffect } from 'react';
import { ServiceOrder } from '@/types';
import { getOrders, saveOrders, generateId } from '@/utils/storage';
import { toast } from 'sonner';

export const useOrders = () => {
  const [orders, setOrders] = useState<ServiceOrder[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = () => {
    try {
      const data = getOrders();
      setOrders(data);
    } catch (error) {
      toast.error('Erro ao carregar ordens');
    } finally {
      setLoading(false);
    }
  };

  const addOrder = (order: Omit<ServiceOrder, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newOrder: ServiceOrder = {
      ...order,
      id: generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    const updated = [newOrder, ...orders];
    setOrders(updated);
    saveOrders(updated);
    toast.success('Ordem criada com sucesso!');
    return newOrder;
  };

  const updateOrder = (id: string, data: Partial<ServiceOrder>) => {
    const updated = orders.map((order) =>
      order.id === id
        ? { ...order, ...data, updatedAt: new Date().toISOString() }
        : order
    );
    setOrders(updated);
    saveOrders(updated);
    toast.success('Ordem atualizada com sucesso!');
  };

  const deleteOrder = (id: string) => {
    const updated = orders.filter((order) => order.id !== id);
    setOrders(updated);
    saveOrders(updated);
    toast.success('Ordem excluída com sucesso!');
  };

  return {
    orders,
    loading,
    addOrder,
    updateOrder,
    deleteOrder,
    refresh: loadOrders,
  };
};
