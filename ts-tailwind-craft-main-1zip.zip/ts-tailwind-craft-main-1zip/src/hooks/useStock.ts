import { useState, useEffect } from 'react';
import { StockItem } from '@/types';
import { getStock, saveStock, generateId } from '@/utils/storage';
import { toast } from 'sonner';

export const useStock = () => {
  const [stock, setStock] = useState<StockItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStock();
  }, []);

  const loadStock = () => {
    try {
      const data = getStock();
      setStock(data);
    } catch (error) {
      toast.error('Erro ao carregar estoque');
    } finally {
      setLoading(false);
    }
  };

  const addItem = (item: Omit<StockItem, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newItem: StockItem = {
      ...item,
      id: generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    const updated = [newItem, ...stock];
    setStock(updated);
    saveStock(updated);
    toast.success('Item adicionado ao estoque!');
    return newItem;
  };

  const updateItem = (id: string, data: Partial<StockItem>) => {
    const updated = stock.map((item) =>
      item.id === id
        ? { ...item, ...data, updatedAt: new Date().toISOString() }
        : item
    );
    setStock(updated);
    saveStock(updated);
    toast.success('Item atualizado com sucesso!');
  };

  const deleteItem = (id: string) => {
    const updated = stock.filter((item) => item.id !== id);
    setStock(updated);
    saveStock(updated);
    toast.success('Item excluído do estoque!');
  };

  const updateQuantity = (id: string, quantity: number) => {
    updateItem(id, { quantity });
  };

  return {
    stock,
    loading,
    addItem,
    updateItem,
    deleteItem,
    updateQuantity,
    refresh: loadStock,
  };
};
