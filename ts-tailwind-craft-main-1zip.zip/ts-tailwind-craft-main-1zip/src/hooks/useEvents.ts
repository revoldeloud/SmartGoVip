import { useState, useEffect } from 'react';
import { CalendarEvent } from '@/types';
import { toast } from 'sonner';

const STORAGE_KEY = 'events_data';

const getEvents = (): CalendarEvent[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error loading events:', error);
    return [];
  }
};

const saveEvents = (events: CalendarEvent[]) => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(events));
  } catch (error) {
    console.error('Error saving events:', error);
  }
};

const generateId = () => {
  return `evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

export const useEvents = () => {
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadEvents();
  }, []);

  const loadEvents = () => {
    try {
      const data = getEvents();
      setEvents(data);
    } catch (error) {
      toast.error('Erro ao carregar eventos');
    } finally {
      setLoading(false);
    }
  };

  const addEvent = (event: Omit<CalendarEvent, 'id' | 'createdAt'>) => {
    const newEvent: CalendarEvent = {
      ...event,
      id: generateId(),
      createdAt: new Date().toISOString(),
    };
    const updated = [newEvent, ...events];
    setEvents(updated);
    saveEvents(updated);
    toast.success('Evento criado com sucesso!');
    return newEvent;
  };

  const updateEvent = (id: string, data: Partial<CalendarEvent>) => {
    const updated = events.map((event) =>
      event.id === id ? { ...event, ...data } : event
    );
    setEvents(updated);
    saveEvents(updated);
    toast.success('Evento atualizado com sucesso!');
  };

  const deleteEvent = (id: string) => {
    const updated = events.filter((event) => event.id !== id);
    setEvents(updated);
    saveEvents(updated);
    toast.success('Evento excluído com sucesso!');
  };

  return {
    events,
    loading,
    addEvent,
    updateEvent,
    deleteEvent,
    refresh: loadEvents,
  };
};
