import { useState, useEffect } from 'react';
import { Client } from '@/types';
import { getClients, saveClients, generateId } from '@/utils/storage';
import { toast } from 'sonner';

export const useClients = () => {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadClients();
  }, []);

  const loadClients = () => {
    try {
      const data = getClients();
      setClients(data);
    } catch (error) {
      toast.error('Erro ao carregar clientes');
    } finally {
      setLoading(false);
    }
  };

  const addClient = (client: Omit<Client, 'id' | 'createdAt'>) => {
    const newClient: Client = {
      ...client,
      id: generateId(),
      createdAt: new Date().toISOString(),
    };
    const updated = [newClient, ...clients];
    setClients(updated);
    saveClients(updated);
    toast.success('Cliente adicionado com sucesso!');
    return newClient;
  };

  const updateClient = (id: string, data: Partial<Client>) => {
    const updated = clients.map((client) =>
      client.id === id ? { ...client, ...data } : client
    );
    setClients(updated);
    saveClients(updated);
    toast.success('Cliente atualizado com sucesso!');
  };

  const deleteClient = (id: string) => {
    const updated = clients.filter((client) => client.id !== id);
    setClients(updated);
    saveClients(updated);
    toast.success('Cliente excluído com sucesso!');
  };

  return {
    clients,
    loading,
    addClient,
    updateClient,
    deleteClient,
    refresh: loadClients,
  };
};
