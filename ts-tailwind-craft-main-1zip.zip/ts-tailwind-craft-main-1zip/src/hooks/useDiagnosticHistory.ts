import { useState, useEffect } from 'react';

export interface DiagnosticRecord {
  id: string;
  problemId: string;
  problemTitle: string;
  category: string;
  phoneModel?: string;
  diagnosisResult: string;
  confidence: number;
  date: string;
  technicianNotes?: string;
  resolved: boolean;
  resolutionTime?: number; // em horas
}

const STORAGE_KEY = 'deveresty_diagnostic_history';

export const useDiagnosticHistory = () => {
  const [history, setHistory] = useState<DiagnosticRecord[]>([]);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = () => {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (data) {
        setHistory(JSON.parse(data));
      }
    } catch (error) {
      console.error('Error loading diagnostic history:', error);
    }
  };

  const saveHistory = (records: DiagnosticRecord[]) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
      setHistory(records);
    } catch (error) {
      console.error('Error saving diagnostic history:', error);
    }
  };

  const addRecord = (record: Omit<DiagnosticRecord, 'id' | 'date'>) => {
    const newRecord: DiagnosticRecord = {
      ...record,
      id: `diag_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      date: new Date().toISOString(),
    };
    saveHistory([newRecord, ...history]);
  };

  const updateRecord = (id: string, updates: Partial<DiagnosticRecord>) => {
    const updated = history.map(record =>
      record.id === id ? { ...record, ...updates } : record
    );
    saveHistory(updated);
  };

  const deleteRecord = (id: string) => {
    saveHistory(history.filter(record => record.id !== id));
  };

  const getStatistics = () => {
    const total = history.length;
    const resolved = history.filter(r => r.resolved).length;
    const resolvedRate = total > 0 ? (resolved / total) * 100 : 0;

    // Problemas mais comuns
    const problemCounts = history.reduce((acc, record) => {
      acc[record.problemTitle] = (acc[record.problemTitle] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const topProblems = Object.entries(problemCounts)
      .map(([problem, count]) => ({ problem, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    // Categorias mais problemáticas
    const categoryCounts = history.reduce((acc, record) => {
      acc[record.category] = (acc[record.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const topCategories = Object.entries(categoryCounts)
      .map(([category, count]) => ({ category, count }))
      .sort((a, b) => b.count - a.count);

    // Confiança média
    const avgConfidence = total > 0
      ? history.reduce((sum, r) => sum + r.confidence, 0) / total
      : 0;

    // Tempo médio de resolução
    const resolvedWithTime = history.filter(r => r.resolved && r.resolutionTime);
    const avgResolutionTime = resolvedWithTime.length > 0
      ? resolvedWithTime.reduce((sum, r) => sum + (r.resolutionTime || 0), 0) / resolvedWithTime.length
      : 0;

    // Diagnósticos por mês
    const last30Days = history.filter(record => {
      const recordDate = new Date(record.date);
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      return recordDate >= thirtyDaysAgo;
    }).length;

    return {
      total,
      resolved,
      resolvedRate,
      topProblems,
      topCategories,
      avgConfidence,
      avgResolutionTime,
      last30Days,
    };
  };

  return {
    history,
    addRecord,
    updateRecord,
    deleteRecord,
    getStatistics,
  };
};
