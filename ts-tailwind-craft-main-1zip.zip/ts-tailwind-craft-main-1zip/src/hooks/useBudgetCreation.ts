import { useNavigate } from 'react-router-dom';
import { PhoneProblem } from '@/types';
import { useStock } from './useStock';

interface BudgetData {
  problem: PhoneProblem;
  phoneModel?: string;
}

export const useBudgetCreation = () => {
  const navigate = useNavigate();
  const { stock } = useStock();

  const createBudgetFromProblem = (data: BudgetData) => {
    const { problem, phoneModel } = data;

    // Calcular custo total das peças baseado no estoque
    let totalPartsCost = 0;
    const availableParts: string[] = [];

    problem.requiredParts?.forEach(partName => {
      const matchingItem = stock.find(item => {
        const itemNameLower = item.name.toLowerCase();
        const partNameLower = partName.toLowerCase();
        return itemNameLower.includes(partNameLower) || partNameLower.includes(itemNameLower);
      });

      if (matchingItem && matchingItem.quantity > 0) {
        totalPartsCost += matchingItem.cost;
        availableParts.push(matchingItem.name);
      }
    });

    // Se não encontrou peças no estoque, usar estimativa do problema
    if (totalPartsCost === 0 && problem.estimatedCost) {
      totalPartsCost = (problem.estimatedCost.min + problem.estimatedCost.max) / 2;
    }

    // Calcular preço de serviço baseado na dificuldade
    let servicePrice = 80; // Base
    switch (problem.difficulty) {
      case 'easy':
        servicePrice = 80;
        break;
      case 'moderate':
        servicePrice = 120;
        break;
      case 'difficult':
        servicePrice = 200;
        break;
      case 'expert':
        servicePrice = 300;
        break;
    }

    // Calcular preço final
    const finalPrice = servicePrice + totalPartsCost;

    // Criar descrição detalhada do serviço
    const serviceDescription = problem.title;
    
    // Criar observações com informações do problema
    const observations = [
      `Problema: ${problem.summary}`,
      `Dificuldade: ${getDifficultyLabel(problem.difficulty)}`,
      `Tempo estimado: ${problem.estimatedTime}`,
      problem.requiredParts?.length ? `Peças necessárias: ${problem.requiredParts.join(', ')}` : '',
      availableParts.length ? `Peças disponíveis no estoque: ${availableParts.join(', ')}` : '',
      problem.warningNotes?.length ? `⚠️ ATENÇÃO: ${problem.warningNotes[0]}` : ''
    ].filter(Boolean).join('\n');

    // Criar objeto de estado para passar para NewOrder
    const budgetState = {
      prefill: {
        type: 'budget',
        model: phoneModel || '',
        service: serviceDescription,
        defect: problem.summary,
        observations: observations,
        servicePrice: servicePrice,
        partsPrice: totalPartsCost,
        finalPrice: finalPrice,
        warranty: 90,
        calcMode: 'manual'
      },
      fromProblem: true,
      problemId: problem.id
    };

    // Navegar para página de novo orçamento com dados pré-preenchidos
    navigate('/novo', { state: budgetState });
  };

  return {
    createBudgetFromProblem
  };
};

const getDifficultyLabel = (difficulty: string): string => {
  const labels: Record<string, string> = {
    easy: 'Fácil',
    moderate: 'Moderado',
    difficult: 'Difícil',
    expert: 'Expert'
  };
  return labels[difficulty] || difficulty;
};
