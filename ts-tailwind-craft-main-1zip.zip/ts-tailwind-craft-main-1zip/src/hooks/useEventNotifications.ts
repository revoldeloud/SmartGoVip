import { toast } from 'sonner';
import { CalendarEvent } from '@/types';

const STORAGE_KEY = 'events_data';
const NOTIFIED_KEY = 'notified_events';

const getNotifiedEvents = (): string[] => {
  try {
    const data = localStorage.getItem(NOTIFIED_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
};

const markAsNotified = (eventId: string) => {
  const notified = getNotifiedEvents();
  if (!notified.includes(eventId)) {
    notified.push(eventId);
    localStorage.setItem(NOTIFIED_KEY, JSON.stringify(notified));
  }
};

const getEvents = (): CalendarEvent[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
};

// Limpar notificações antigas (mais de 24h)
const cleanOldNotifications = () => {
  const notified = getNotifiedEvents();
  const events = getEvents();
  const now = new Date();
  
  const validNotifications = notified.filter(eventId => {
    const event = events.find(e => e.id === eventId);
    if (!event) return false;
    
    const eventDate = new Date(event.date);
    const diff = now.getTime() - eventDate.getTime();
    return diff < 86400000; // 24 horas
  });
  
  localStorage.setItem(NOTIFIED_KEY, JSON.stringify(validNotifications));
};

let notificationsInitialized = false;

export const initEventNotifications = () => {
  if (notificationsInitialized) return;
  notificationsInitialized = true;

  const checkEvents = () => {
    const events = getEvents();
    const notified = getNotifiedEvents();
    const now = new Date();

    events.forEach((event) => {
      if (notified.includes(event.id)) return;

      const eventDateTime = event.time
        ? new Date(`${event.date}T${event.time}`)
        : new Date(event.date);

      const diff = eventDateTime.getTime() - now.getTime();

      if (diff >= 0 && diff <= 120000) {
        const eventTypeIcons: Record<string, string> = {
          consulta: '🔍',
          entrega: '📦',
          retirada: '📤',
          orcamento: '💰',
          outro: '📌',
        };

        const icon = eventTypeIcons[event.type] || '📌';

        toast.success(`${icon} Lembrete: ${event.title}`, {
          description: event.time
            ? `Agendado para ${event.time}${event.client ? ` - Cliente: ${event.client}` : ''}`
            : event.client
              ? `Cliente: ${event.client}`
              : undefined,
          duration: 10000,
        });

        markAsNotified(event.id);
      }
    });
  };

  // Limpar notificações antigas e verificar imediatamente
  cleanOldNotifications();
  checkEvents();

  // Verificar a cada 30 segundos
  setInterval(checkEvents, 30000);
};
