import { useState, useEffect } from 'react';
import { Phone } from '@/types';
import { getPhones, savePhones, generateId } from '@/utils/storage';
import { toast } from 'sonner';

export const usePhones = () => {
  const [phones, setPhones] = useState<Phone[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPhones();
  }, []);

  const loadPhones = () => {
    try {
      const data = getPhones();
      setPhones(data);
    } catch (error) {
      toast.error('Erro ao carregar celulares');
    } finally {
      setLoading(false);
    }
  };

  const addPhone = (phone: Omit<Phone, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newPhone: Phone = {
      ...phone,
      id: generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    const updated = [newPhone, ...phones];
    setPhones(updated);
    savePhones(updated);
    toast.success('Celular adicionado com sucesso!');
    return newPhone;
  };

  const updatePhone = (id: string, data: Partial<Phone>) => {
    const updated = phones.map((phone) =>
      phone.id === id
        ? { ...phone, ...data, updatedAt: new Date().toISOString() }
        : phone
    );
    setPhones(updated);
    savePhones(updated);
    toast.success('Celular atualizado com sucesso!');
  };

  const deletePhone = (id: string) => {
    const updated = phones.filter((phone) => phone.id !== id);
    setPhones(updated);
    savePhones(updated);
    toast.success('Celular excluído com sucesso!');
  };

  return {
    phones,
    loading,
    addPhone,
    updatePhone,
    deletePhone,
    refresh: loadPhones,
  };
};
