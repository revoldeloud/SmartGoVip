import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Sidebar } from "./components/layout/Sidebar";
import { useEffect } from "react";
import { initEventNotifications } from "./hooks/useEventNotifications";
import Dashboard from "./pages/Dashboard";
import NewOrder from "./pages/NewOrder";
import Orders from "./pages/Orders";
import Budgets from "./pages/Budgets";
import Clients from "./pages/Clients";
import Phones from "./pages/Phones";
import CalendarPage from "./pages/Calendar";
import Stock from "./pages/Stock";
import Financial from "./pages/Financial";
import Reports from "./pages/Reports";
import Settings from "./pages/Settings";
import Solutions from "./pages/Solutions";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => {
  useEffect(() => {
    initEventNotifications();
  }, []);
  
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <div className="flex min-h-screen bg-background">
            <Sidebar />
            <main className="flex-1 flex flex-col overflow-hidden pb-20 md:pb-0">
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/novo" element={<NewOrder />} />
                <Route path="/ordens" element={<Orders />} />
                <Route path="/orcamentos" element={<Budgets />} />
                <Route path="/clientes" element={<Clients />} />
                <Route path="/celulares" element={<Phones />} />
                <Route path="/agenda" element={<CalendarPage />} />
                <Route path="/estoque" element={<Stock />} />
                <Route path="/financeiro" element={<Financial />} />
                <Route path="/relatorios" element={<Reports />} />
                <Route path="/solucoes" element={<Solutions />} />
                <Route path="/config" element={<Settings />} />
                {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </main>
          </div>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
