# SmartGO - Sistema de Gestão para Assistência Técnica

## Overview

SmartGO is a comprehensive technical assistance management system designed for phone repair shops. The application provides complete workflow management including service orders, budgets, client management, inventory control, scheduling, and financial tracking. Built as a React single-page application with TypeScript, it features a modern futuristic dark theme with glassmorphism effects and uses local storage for data persistence.

## Recent Changes (November 2024)

- **UI Redesign**: Complete futuristic dark theme overhaul with glassmorphism effects
- **Responsive Layout**: Desktop sidebar with hover expansion + mobile bottom navigation
- **Mobile Home Screen**: Large icon grid (3 columns) for mobile app-like experience
- **Visual Effects**: Gradient accents (cyan/purple), neon glows, smooth animations

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- React 18+ with TypeScript for type safety and modern React patterns
- Vite as the build tool for fast development and optimized production builds (port 5000)
- React Router for client-side routing and navigation

**UI Design System**
- Radix UI primitives for accessible, unstyled components (dialogs, dropdowns, tabs, etc.)
- shadcn/ui components extended with futuristic dark theme
- Glassmorphism effects with backdrop blur and translucent backgrounds
- Dark premium color palette with cyan/purple neon accents
- Responsive design: narrow sidebar on desktop, bottom navigation on mobile

**State Management**
- React hooks (useState, useEffect) for local component state
- Custom hooks for business logic (useOrders, useClients, useStock, etc.)
- TanStack Query (React Query) for server state management and caching
- Local storage as the primary data persistence layer

**Form Handling**
- React Hook Form with Zod resolvers for validation
- Custom autocomplete components for client and product selection
- File upload handling for photo galleries (base64 encoding for local storage)

### Data Storage Solutions

**Local Storage Architecture**
- All data persisted in browser localStorage with JSON serialization
- Separate storage keys for each entity type (orders, clients, stock, events, etc.)
- Utility functions in `src/utils/storage.ts` for centralized storage operations
- No backend database - fully client-side data management

**Data Models**
- ServiceOrder: Service orders and budgets with status tracking
- Client: Customer information and contact details
- StockItem: Inventory management with quantity tracking
- Phone: Device catalog with specifications and images
- CalendarEvent: Scheduling and appointment management
- DiagnosticRecord: Problem diagnosis history tracking

**ID Generation**
- Custom timestamp-based ID generator for unique entity identification
- Format: `{prefix}_{timestamp}_{random}`

### External Dependencies

**APIs & Services**
- iFixit API: Third-party repair guides and step-by-step instructions
  - Base URL: https://www.ifixit.com/api/2.0
  - Caching strategy: 7-day localStorage cache to minimize API calls
  - Provides device-specific repair guides, tools, and parts information

**Third-Party Libraries**
- Chart.js: Data visualization for dashboard analytics
- date-fns: Date manipulation and formatting (pt-BR locale)
- QRCode.react: QR code generation for payment methods
- lucide-react: Icon library
- embla-carousel-react: Image carousel functionality

**Communication Integrations**
- WhatsApp Web API: Direct message sending via URL schemes
  - Service reports, payment requests, and receipts
  - Template-based messaging system
- Print functionality: Browser native print API for invoices and receipts

**Data Sources**
- Phone specifications database: Local JSON data for device specs and images
- Problem database: Comprehensive technical issue catalog with solutions
  - 10+ categories (display, battery, network, camera, etc.)
  - Detailed diagnostic procedures and repair steps
  - Confidence-based problem matching

### Key Architectural Decisions

**Why Local Storage?**
- Zero infrastructure costs and complexity
- Instant setup with no backend requirements
- Suitable for single-user or single-location use cases
- All data remains on the client device for privacy

**Component Organization**
- Feature-based folder structure under `src/components/`
- Shared UI components in `src/components/ui/` (shadcn)
- Page components in `src/pages/`
- Reusable business logic extracted to custom hooks in `src/hooks/`

**Styling Approach**
- Tailwind CSS utility-first approach
- CSS custom properties for theming (HSL color system)
- Dark mode support with class-based theme switching
- Responsive design with mobile-first breakpoints

**Photo Management**
- Base64 encoding for image storage in localStorage
- Three-stage photo timeline (before, during, after)
- 5MB file size limit per image
- Image compression not implemented (potential improvement area)

**Internationalization**
- Brazilian Portuguese (pt-BR) as primary language
- Currency formatting in BRL (R$)
- Date formatting with Brazilian conventions
- Phone number formatting for Brazilian standards

**Print & Export Features**
- Custom print templates for service orders and receipts
- Excel/CSV export functionality for reports
- QR code generation for payment methods (Pix)
- WhatsApp sharing integration

**Notification System**
- Toast notifications via Sonner library
- Event-based notifications for calendar appointments
- localStorage-based notification tracking to prevent duplicates
- 24-hour notification cleanup cycle