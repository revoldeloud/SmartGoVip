-- Remove chatbot tables
DROP TABLE IF EXISTS public.chatbot_messages CASCADE;
DROP TABLE IF EXISTS public.chatbot_analytics CASCADE;
DROP TABLE IF EXISTS public.chatbot_auto_responses CASCADE;
DROP TABLE IF EXISTS public.chatbot_conversations CASCADE;
DROP TABLE IF EXISTS public.chatbot_flows CASCADE;
DROP TABLE IF EXISTS public.chatbot_queue_rules CASCADE;
DROP TABLE IF EXISTS public.chatbot_schedules CASCADE;
DROP TABLE IF EXISTS public.chatbot_settings CASCADE;
DROP TABLE IF EXISTS public.chatbot_templates CASCADE;

-- Remove chatbot enums
DROP TYPE IF EXISTS public.conversation_status CASCADE;
DROP TYPE IF EXISTS public.message_direction CASCADE;
DROP TYPE IF EXISTS public.message_status CASCADE;
DROP TYPE IF EXISTS public.priority_level CASCADE;