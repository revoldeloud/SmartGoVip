-- Habilitar UUID
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enum para tipos de mensagem
CREATE TYPE message_direction AS ENUM ('incoming', 'outgoing');
CREATE TYPE conversation_status AS ENUM ('active', 'waiting', 'resolved', 'archived');
CREATE TYPE message_status AS ENUM ('sent', 'delivered', 'read', 'failed');
CREATE TYPE priority_level AS ENUM ('low', 'medium', 'high', 'urgent');
CREATE TYPE flow_node_type AS ENUM ('message', 'options', 'action', 'condition', 'agent_transfer');

-- Tabela de configurações do chatbot
CREATE TABLE chatbot_settings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  bot_name TEXT NOT NULL DEFAULT 'Assistente Virtual',
  bot_avatar TEXT,
  language TEXT NOT NULL DEFAULT 'pt-BR',
  timezone TEXT NOT NULL DEFAULT 'America/Sao_Paulo',
  operation_mode TEXT NOT NULL DEFAULT 'hybrid', -- manual, automatic, hybrid
  ai_enabled BOOLEAN NOT NULL DEFAULT true,
  ai_model TEXT NOT NULL DEFAULT 'google/gemini-2.5-flash',
  ai_temperature DECIMAL(3,2) DEFAULT 0.7,
  ai_system_prompt TEXT DEFAULT 'Você é um assistente virtual de uma oficina de celulares. Seja educado, prestativo e profissional.',
  sentiment_analysis_enabled BOOLEAN DEFAULT true,
  intent_classification_enabled BOOLEAN DEFAULT true,
  image_analysis_enabled BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Tabela de respostas automáticas
CREATE TABLE chatbot_auto_responses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  trigger_type TEXT NOT NULL, -- greeting, keyword, out_of_hours, feedback
  trigger_value TEXT, -- palavra-chave para busca
  response_text TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  priority INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Tabela de fluxos de conversação
CREATE TABLE chatbot_flows (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  description TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  flow_data JSONB NOT NULL DEFAULT '[]', -- array de nodes e connections
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Tabela de templates de mensagem
CREATE TABLE chatbot_templates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  category TEXT, -- saudação, despedida, informação, etc
  shortcut TEXT, -- atalho para uso rápido (ex: /orcamento)
  content TEXT NOT NULL,
  variables JSONB DEFAULT '[]', -- variáveis dinâmicas disponíveis
  is_active BOOLEAN NOT NULL DEFAULT true,
  usage_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Tabela de horários de atendimento
CREATE TABLE chatbot_schedules (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  day_of_week INTEGER NOT NULL, -- 0-6 (domingo a sábado)
  is_active BOOLEAN NOT NULL DEFAULT true,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  out_of_hours_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(day_of_week)
);

-- Tabela de conversas
CREATE TABLE chatbot_conversations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  phone TEXT NOT NULL,
  client_name TEXT,
  client_email TEXT,
  status conversation_status NOT NULL DEFAULT 'active',
  priority priority_level NOT NULL DEFAULT 'medium',
  assigned_agent TEXT, -- nome do atendente
  tags TEXT[] DEFAULT '{}',
  metadata JSONB DEFAULT '{}',
  last_message_at TIMESTAMPTZ,
  unread_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Tabela de mensagens
CREATE TABLE chatbot_messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID NOT NULL REFERENCES chatbot_conversations(id) ON DELETE CASCADE,
  direction message_direction NOT NULL,
  content TEXT NOT NULL,
  media_url TEXT,
  media_type TEXT, -- image, video, audio, document
  status message_status NOT NULL DEFAULT 'sent',
  is_read BOOLEAN NOT NULL DEFAULT false,
  metadata JSONB DEFAULT '{}',
  ai_generated BOOLEAN DEFAULT false,
  template_id UUID REFERENCES chatbot_templates(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Tabela de regras de fila
CREATE TABLE chatbot_queue_rules (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  conditions JSONB NOT NULL, -- condições para aplicar a regra
  priority priority_level NOT NULL,
  auto_assign_agent TEXT,
  max_wait_time_minutes INTEGER,
  escalation_rules JSONB DEFAULT '{}',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Tabela de analytics
CREATE TABLE chatbot_analytics (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  date DATE NOT NULL,
  metric_name TEXT NOT NULL,
  metric_value DECIMAL(10,2) NOT NULL,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(date, metric_name)
);

-- Inserir configuração padrão
INSERT INTO chatbot_settings (id) VALUES (uuid_generate_v4());

-- Inserir horários padrão (segunda a sexta, 9h às 18h)
INSERT INTO chatbot_schedules (day_of_week, start_time, end_time, out_of_hours_message) VALUES
(1, '09:00', '18:00', 'Olá! Nosso horário de atendimento é de segunda a sexta, das 9h às 18h. Deixe sua mensagem que responderemos assim que possível.'),
(2, '09:00', '18:00', 'Olá! Nosso horário de atendimento é de segunda a sexta, das 9h às 18h. Deixe sua mensagem que responderemos assim que possível.'),
(3, '09:00', '18:00', 'Olá! Nosso horário de atendimento é de segunda a sexta, das 9h às 18h. Deixe sua mensagem que responderemos assim que possível.'),
(4, '09:00', '18:00', 'Olá! Nosso horário de atendimento é de segunda a sexta, das 9h às 18h. Deixe sua mensagem que responderemos assim que possível.'),
(5, '09:00', '18:00', 'Olá! Nosso horário de atendimento é de segunda a sexta, das 9h às 18h. Deixe sua mensagem que responderemos assim que possível.');

-- Inserir algumas respostas automáticas padrão
INSERT INTO chatbot_auto_responses (name, trigger_type, trigger_value, response_text) VALUES
('Saudação Inicial', 'greeting', NULL, 'Olá! 👋 Bem-vindo à nossa assistência técnica de celulares. Como posso ajudá-lo hoje?'),
('Preços', 'keyword', 'preço,valor,quanto custa', 'Nossos preços variam de acordo com o serviço. Você pode me enviar uma foto do problema ou descrever o que está acontecendo com seu celular para eu fazer um orçamento?'),
('Horário', 'keyword', 'horário,horario,quando', 'Nosso atendimento funciona de segunda a sexta, das 9h às 18h. Estou aqui para ajudá-lo!'),
('Localização', 'keyword', 'endereço,endereco,local,onde', 'Você pode encontrar informações sobre nossa localização em nosso site ou menu. Deseja que eu envie o endereço?');

-- Inserir alguns templates padrão
INSERT INTO chatbot_templates (name, category, shortcut, content, variables) VALUES
('Orçamento Aprovado', 'informação', '/aprovado', 'Ótimo! Seu orçamento foi aprovado. O valor total é de {{valor}}. Quando podemos agendar o reparo?', '["valor"]'),
('Serviço Pronto', 'informação', '/pronto', 'Boa notícia! Seu {{modelo}} está pronto para retirada. O valor final ficou em {{valor}}. Aguardamos você!', '["modelo", "valor"]'),
('Solicitar Informações', 'pergunta', '/info', 'Para melhor atendê-lo, preciso de algumas informações:\n- Modelo do celular\n- Descrição do problema\n- Pode enviar fotos?', '[]');

-- Habilitar RLS
ALTER TABLE chatbot_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE chatbot_auto_responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE chatbot_flows ENABLE ROW LEVEL SECURITY;
ALTER TABLE chatbot_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE chatbot_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE chatbot_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE chatbot_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE chatbot_queue_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE chatbot_analytics ENABLE ROW LEVEL SECURITY;

-- Políticas RLS (por enquanto permitindo acesso público para simplificar o desenvolvimento inicial)
CREATE POLICY "Allow public read access" ON chatbot_settings FOR SELECT USING (true);
CREATE POLICY "Allow public write access" ON chatbot_settings FOR ALL USING (true);

CREATE POLICY "Allow public read access" ON chatbot_auto_responses FOR SELECT USING (true);
CREATE POLICY "Allow public write access" ON chatbot_auto_responses FOR ALL USING (true);

CREATE POLICY "Allow public read access" ON chatbot_flows FOR SELECT USING (true);
CREATE POLICY "Allow public write access" ON chatbot_flows FOR ALL USING (true);

CREATE POLICY "Allow public read access" ON chatbot_templates FOR SELECT USING (true);
CREATE POLICY "Allow public write access" ON chatbot_templates FOR ALL USING (true);

CREATE POLICY "Allow public read access" ON chatbot_schedules FOR SELECT USING (true);
CREATE POLICY "Allow public write access" ON chatbot_schedules FOR ALL USING (true);

CREATE POLICY "Allow public read access" ON chatbot_conversations FOR SELECT USING (true);
CREATE POLICY "Allow public write access" ON chatbot_conversations FOR ALL USING (true);

CREATE POLICY "Allow public read access" ON chatbot_messages FOR SELECT USING (true);
CREATE POLICY "Allow public write access" ON chatbot_messages FOR ALL USING (true);

CREATE POLICY "Allow public read access" ON chatbot_queue_rules FOR SELECT USING (true);
CREATE POLICY "Allow public write access" ON chatbot_queue_rules FOR ALL USING (true);

CREATE POLICY "Allow public read access" ON chatbot_analytics FOR SELECT USING (true);
CREATE POLICY "Allow public write access" ON chatbot_analytics FOR ALL USING (true);

-- Trigger para atualizar updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_chatbot_settings_updated_at BEFORE UPDATE ON chatbot_settings FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_chatbot_auto_responses_updated_at BEFORE UPDATE ON chatbot_auto_responses FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_chatbot_flows_updated_at BEFORE UPDATE ON chatbot_flows FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_chatbot_templates_updated_at BEFORE UPDATE ON chatbot_templates FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_chatbot_schedules_updated_at BEFORE UPDATE ON chatbot_schedules FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_chatbot_conversations_updated_at BEFORE UPDATE ON chatbot_conversations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_chatbot_queue_rules_updated_at BEFORE UPDATE ON chatbot_queue_rules FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Habilitar realtime para conversas e mensagens
ALTER PUBLICATION supabase_realtime ADD TABLE chatbot_conversations;
ALTER PUBLICATION supabase_realtime ADD TABLE chatbot_messages;